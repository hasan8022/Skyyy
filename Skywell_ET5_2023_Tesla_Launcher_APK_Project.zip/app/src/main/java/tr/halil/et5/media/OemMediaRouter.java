package tr.halil.et5.media;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.view.KeyEvent;

import java.util.List;

import tr.halil.et5.MediaListener;
import tr.halil.et5.car.VehicleController;

/**
 * Skywell ET5 OEM App Launcher, MediaSession Controller & Steering Wheel Key Receiver.
 * Mirrors B00.java, HY.java, EX.java, C2250o2.java, and C1574hb0.java.
 */
public final class OemMediaRouter {

    public static final String PKG_OEM_RADIO      = "com.skyworth.car.carradio";
    public static final String PKG_OEM_USB_MEDIA  = "com.skyworth.car.localmedia";
    public static final String PKG_OEM_BT_MUSIC   = "com.skyworth.car.carbtmusic";
    public static final String PKG_OEM_PHONE      = "com.skyworth.car.skycommunication";
    public static final String PKG_OEM_SYS_SET    = "com.skyworth.car.systemsettings";
    public static final String PKG_OEM_CAR_SET    = "com.skyworth.car.aisettings";
    public static final String PKG_OEM_HVAC       = "com.coolwell.ai.skyhvac";
    public static final String PKG_OEM_EVS_CAM    = "com.skyworth.car.evs";
    public static final String PKG_OEM_LAUNCHER   = "com.skyworth.car.launcher";
    public static final String PKG_SPOTIFY        = "com.spotify.music";
    public static final String PKG_METROLIST      = "com.metrolist.music";
    public static final String PKG_SMARTTUBE      = "org.smarttube.stable";
    public static final String PKG_NEWPIPE        = "org.schabi.newpipe";

    private final Context context;
    private final VehicleController vehicleController;
    private BroadcastReceiver steeringKeyReceiver;

    public OemMediaRouter(Context context, VehicleController vehicleController) {
        this.context = context.getApplicationContext();
        this.vehicleController = vehicleController;
    }

    public void registerSteeringWheelKeys() {
        if (steeringKeyReceiver != null) return;
        steeringKeyReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                if (intent == null) return;
                int keyDown = intent.getIntExtra("key_event_down", -1);
                if (keyDown >= 0) {
                    handleSteeringKey(keyDown);
                }
            }
        };
        IntentFilter filter = new IntentFilter("com.android.car.action.IVI_KEYEVENT");
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                context.registerReceiver(steeringKeyReceiver, filter, Context.RECEIVER_EXPORTED);
            } else {
                context.registerReceiver(steeringKeyReceiver, filter);
            }
        } catch (Throwable ignored) {
        }
    }

    private void handleSteeringKey(int keyCode) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                dispatchMediaAction("NEXT");
                break;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                dispatchMediaAction("PREV");
                break;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                dispatchMediaAction("PLAY_PAUSE");
                break;
            case KeyEvent.KEYCODE_VOLUME_UP:
                vehicleController.adjustSystemVolume(1);
                break;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                vehicleController.adjustSystemVolume(-1);
                break;
            default:
                break;
        }
    }

    public void dispatchMediaAction(String action) {
        try {
            MediaController mc = getActiveMediaController();
            if (mc != null) {
                if ("NEXT".equals(action)) mc.getTransportControls().skipToNext();
                else if ("PREV".equals(action)) mc.getTransportControls().skipToPrevious();
                else if ("PLAY_PAUSE".equals(action)) {
                    PlaybackState ps = mc.getPlaybackState();
                    if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) {
                        mc.getTransportControls().pause();
                    } else {
                        mc.getTransportControls().play();
                    }
                }
                syncActiveMediaMetadata();
                return;
            }
        } catch (Throwable ignored) {
        }

        try {
            AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                int code = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
                if ("NEXT".equals(action)) code = KeyEvent.KEYCODE_MEDIA_NEXT;
                else if ("PREV".equals(action)) code = KeyEvent.KEYCODE_MEDIA_PREVIOUS;
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
            }
        } catch (Throwable ignored) {
        }
    }

    public MediaController getActiveMediaController() {
        try {
            MediaSessionManager msm = (MediaSessionManager) context.getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (msm == null) return null;
            List<MediaController> controllers;
            try {
                controllers = msm.getActiveSessions(new ComponentName(context, MediaListener.class));
            } catch (SecurityException se) {
                controllers = msm.getActiveSessions(null);
            }
            if (controllers != null && !controllers.isEmpty()) {
                return controllers.get(0);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    public void syncActiveMediaMetadata() {
        try {
            MediaController mc = getActiveMediaController();
            if (mc == null) return;
            MediaMetadata meta = mc.getMetadata();
            PlaybackState ps = mc.getPlaybackState();
            boolean playing = ps != null && ps.getState() == PlaybackState.STATE_PLAYING;
            String title = meta != null ? String.valueOf(meta.getText(MediaMetadata.METADATA_KEY_TITLE)) : "Medya Oynatılıyor";
            String artist = meta != null ? String.valueOf(meta.getText(MediaMetadata.METADATA_KEY_ARTIST)) : mc.getPackageName();
            if ("null".equals(title)) title = "Bilinmeyen Parça";
            if ("null".equals(artist)) artist = "";
            vehicleController.sendMediaInfoToCluster(playing, title, artist);
        } catch (Throwable ignored) {
        }
    }

    public boolean openFmRadio() {
        return launchAnyPackage(PKG_OEM_RADIO, "com.skyworth.car.radio", "com.coocaa.radio");
    }

    public boolean openUsbLocalMusic() {
        return launchAnyPackage(PKG_OEM_USB_MEDIA, "com.skyworth.car.music", "com.coocaa.local.media");
    }

    public boolean openBluetoothMusic() {
        return launchAnyPackage(PKG_OEM_BT_MUSIC, "com.skyworth.car.btmusic");
    }

    public boolean openSpotify() {
        return launchAnyPackage(PKG_SPOTIFY, "com.spotify.lite");
    }

    public boolean openYouTubeMusic() {
        return launchAnyPackage(PKG_METROLIST, "app.revanced.android.apps.youtube.music", "com.google.android.apps.youtube.music");
    }

    public boolean openYouTubeVideo() {
        return launchAnyPackage(PKG_SMARTTUBE, PKG_NEWPIPE, "com.liskovsoft.smarttubetv.beta", "app.revanced.android.youtube");
    }

    public boolean launchAnyPackage(String... pkgs) {
        PackageManager pm = context.getPackageManager();
        for (String pkg : pkgs) {
            try {
                Intent launch = pm.getLaunchIntentForPackage(pkg);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(launch);
                    return true;
                }
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    public void dialPhoneNumber(String number) {
        try {
            if (number == null || number.trim().isEmpty()) {
                launchAnyPackage(PKG_OEM_PHONE);
                return;
            }
            Intent dial = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number.trim(), null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(dial);
        } catch (Throwable ignored) {
        }
    }
}
