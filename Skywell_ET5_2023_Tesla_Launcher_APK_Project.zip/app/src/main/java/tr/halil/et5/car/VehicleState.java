package tr.halil.et5.car;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Complete Real-Time Vehicle State Model for 2023 Skywell ET5 (Skyworth EV6).
 * Mirrors C3204xB0, C2622rh, C1386fl0, C1282el0, O10, and C0913b70 (OBD).
 */
public final class VehicleState {

    // Drive & Powertrain
    public volatile String gear = "P"; // "P", "R", "N", "D"
    public volatile boolean autoHold = false;
    public volatile int speedKmh = 0;
    public volatile int socPercent = 82;
    public volatile int rangeKm = 425;
    public volatile float odometerKm = 18420.0f;
    public volatile float tripKm = 42.6f;
    public volatile float avgConsumptionKwh = 15.8f;
    public volatile float hvVoltage = 376.4f;
    public volatile float hvCurrent = 0.0f;
    public volatile float powerKw = 0.0f;
    public volatile int battery12v = 138; // 13.8V
    public volatile boolean ignitionReady = true;
    public volatile String vin = "LSJWH409XPN002023";
    public volatile int driveMode = 0; // 0=Normal, 1=Eco, 2=Sport
    public volatile int regenPercent = 50; // 0..100

    // Exterior Lights & Signals
    public volatile boolean turnLeft = false;
    public volatile boolean turnRight = false;
    public volatile boolean hazardLights = false;
    public volatile boolean brakeLight = false;
    public volatile boolean lowBeam = false;
    public volatile boolean highBeam = false;
    public volatile boolean fogLight = false;

    // Doors, Hood, Trunk, Windows, Sunroof, Locks
    public final boolean[] doorsOpen = {false, false, false, false}; // FL, FR, RL, RR
    public volatile boolean hoodOpen = false;
    public volatile boolean trunkOpen = false;
    public final boolean[] windowsOpen = {false, false, false, false}; // FL, FR, RL, RR
    public volatile boolean sunroofOpen = false;
    public volatile boolean locked = true;
    public volatile boolean mirrorsFolded = false;

    // Tires (Bar & Temp)
    public final float[] tirePressuresBar = {2.45f, 2.45f, 2.50f, 2.50f};
    public final float[] tireTempsC = {26.0f, 26.0f, 25.0f, 25.0f};

    // Ultrasonic Parking Radar (Meters: 4 Front, 4 Rear, 4 Side)
    public final float[] radarFront = {2.0f, 2.0f, 2.0f, 2.0f};
    public final float[] radarRear = {2.0f, 2.0f, 2.0f, 2.0f};
    public final float[] radarSide = {2.0f, 2.0f, 2.0f, 2.0f};

    // Charging State
    public volatile boolean chargeCableConnected = false;
    public volatile boolean chargingActive = false;
    public volatile int chargeLimitPercent = 80;
    public volatile int chargeRemainingMin = 0;
    public volatile boolean schedChargeEnabled = false;
    public volatile String schedChargeStart = "22:00";
    public volatile String schedChargeEnd = "07:00";

    // HVAC / Climate State
    public volatile boolean hvacPower = false;
    public volatile float hvacTargetTemp = 22.0f;
    public volatile int hvacFanSpeed = 3; // 1..7
    public volatile boolean hvacAc = true;
    public volatile boolean hvacAuto = false;
    public volatile boolean hvacRecirc = false;
    public volatile boolean hvacFrontDefrost = false;
    public volatile boolean hvacRearDefrost = false;
    public volatile boolean hvacEco = false;
    public volatile float cabinTempC = 22.5f;
    public volatile float outsideTempC = 21.0f;

    // Seats & Mirrors
    public volatile int driverSeatHeat = 0;    // 0..3
    public volatile int driverSeatVent = 0;    // 0..3
    public volatile int passengerSeatHeat = 0; // 0..3
    public volatile int passengerSeatVent = 0; // 0..3
    public volatile int seatForeAft = 50;
    public volatile int seatHeight = 50;
    public volatile int seatTilt = 50;
    public volatile int seatFootrest = 0;
    public volatile int mirrorLeftH = 50;
    public volatile int mirrorLeftV = 50;
    public volatile int mirrorRightH = 50;
    public volatile int mirrorRightV = 50;

    // Audio & FM Radio
    public volatile int audioChannel = 0;
    public volatile int masterVolume = 15; // 0..40
    public volatile int balance = 0;       // -15..15
    public volatile int fader = 0;         // -15..15
    public final int[] eqBands = {0, 0, 0, 0, 0}; // -10..10
    public volatile boolean fmRadioPower = false;
    public volatile float fmRadioFreq = 98.4f;

    // Instrument Cluster (CDSManager)
    public volatile int clusterBrightness = 2; // 1..3
    public volatile int clusterTheme = 0;      // 0=Classic, 1=Sport
    public volatile int clusterTone = 0;       // 0..2
    public volatile int clusterVolume = 20;    // 0..40
    public volatile boolean clusterNavDisplay = true;

    // Media Player State
    public volatile String mediaSource = "SPOTIFY";
    public volatile String mediaTitle = "Skywell ET5 Ses Sistemi Hazır";
    public volatile String mediaArtist = "Bluetooth / FM / USB / Spotify";
    public volatile boolean mediaPlaying = false;

    // Connection & Helper Status
    public volatile String helperStatus = "Başlatılıyor...";
    public volatile boolean directCarConnected = false;
    public volatile boolean helperSocketConnected = false;
    public volatile String obdStatus = "Hazır";
    public volatile boolean obdConnected = false;

    // Extended OBD2 Telemetry (C0913b70)
    public volatile float obdSohPercent = 98.8f;
    public volatile float obdCellMaxV = 3.682f;
    public volatile float obdCellMinV = 3.671f;
    public volatile float obdTempMaxC = 27.0f;
    public volatile float obdTempMinC = 25.0f;
    public volatile float obdIsolationKohm = 1000.0f;
    public volatile int obdMotorRpm = 0;
    public volatile float obdMotorTorqueNm = 0.0f;
    public volatile float obdMotorTempC = 34.0f;
    public volatile float obdInverterTempC = 32.0f;
    public volatile float obdObcTempC = 28.0f;
    public volatile float obdDcdcTempC = 30.0f;
    public volatile float obdAcVoltage = 0.0f;
    public volatile float obdAcCurrent = 0.0f;
    public volatile float[] obdCells = new float[0];
    public volatile String lastDtcReport = "Arıza kodu taraması yapılmadı";

    // Dynamic Settings Map (37+ Skywell ET5 Settings)
    public final Map<String, Object> settings = new ConcurrentHashMap<>();

    public VehicleState() {
        // Initialize sensible defaults for all 37+ settings
        settings.put("surus_modu", 0);
        settings.put("direksiyon_modu", 1);
        settings.put("fren_modu", 0);
        settings.put("geri_kazanim", 50);
        settings.put("rolanti", true);
        settings.put("yokus_inis", true);
        settings.put("esc", true);
        settings.put("lka", true);
        settings.put("ldw", true);
        settings.put("aeb", true);
        settings.put("fcw", true);
        settings.put("bsd", true);
        settings.put("tsr", true);
        settings.put("hba", false);
        settings.put("on_radar", true);
        settings.put("yaya_uyari", true);
        settings.put("far_yukseklik", 1);
        settings.put("follow_me", 1);
        settings.put("karsilama_isik", true);
        settings.put("logo_isik", true);
        settings.put("dugme_isik", 3);
        settings.put("ambiyans", 1);
        settings.put("ambiyans_renk", 42);
        settings.put("ambiyans_parlak", 4);
        settings.put("kilit_acma", 0);
        settings.put("ayna_katla", true);
        settings.put("cam_kapat", true);
        settings.put("ayna_indir", true);
        settings.put("kolay_giris", true);
        settings.put("priz_220", false);
        settings.put("kablosuz_sarj", true);
        settings.put("batarya_isitma", false);
        settings.put("uzun_omur", true);
        settings.put("derin_desarj", true);
        settings.put("ses_modu", 0);
        settings.put("ekolayzer", 0);
        settings.put("hiza_duyarli_ses", 1);
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("gear", gear);
            o.put("autoHold", autoHold);
            o.put("speedKmh", speedKmh);
            o.put("socPercent", socPercent);
            o.put("rangeKm", rangeKm);
            o.put("odometerKm", odometerKm);
            o.put("tripKm", tripKm);
            o.put("avgConsumptionKwh", avgConsumptionKwh);
            o.put("hvVoltage", hvVoltage);
            o.put("hvCurrent", hvCurrent);
            o.put("powerKw", powerKw);
            o.put("battery12v", battery12v);
            o.put("ignitionReady", ignitionReady);
            o.put("vin", vin);
            o.put("driveMode", driveMode);
            o.put("regenPercent", regenPercent);

            o.put("turnLeft", turnLeft);
            o.put("turnRight", turnRight);
            o.put("hazardLights", hazardLights);
            o.put("brakeLight", brakeLight);
            o.put("lowBeam", lowBeam);
            o.put("highBeam", highBeam);
            o.put("fogLight", fogLight);

            JSONArray doorsArr = new JSONArray();
            for (boolean b : doorsOpen) doorsArr.put(b);
            o.put("doorsOpen", doorsArr);
            o.put("hoodOpen", hoodOpen);
            o.put("trunkOpen", trunkOpen);

            JSONArray winArr = new JSONArray();
            for (boolean b : windowsOpen) winArr.put(b);
            o.put("windowsOpen", winArr);
            o.put("sunroofOpen", sunroofOpen);
            o.put("locked", locked);
            o.put("mirrorsFolded", mirrorsFolded);

            JSONArray tpArr = new JSONArray();
            for (float f : tirePressuresBar) tpArr.put(Math.round(f * 100f) / 100.0);
            o.put("tirePressuresBar", tpArr);

            JSONArray rfArr = new JSONArray();
            for (float f : radarFront) rfArr.put(Math.round(f * 100f) / 100.0);
            o.put("radarFront", rfArr);
            JSONArray rrArr = new JSONArray();
            for (float f : radarRear) rrArr.put(Math.round(f * 100f) / 100.0);
            o.put("radarRear", rrArr);
            JSONArray rsArr = new JSONArray();
            for (float f : radarSide) rsArr.put(Math.round(f * 100f) / 100.0);
            o.put("radarSide", rsArr);

            o.put("chargeCableConnected", chargeCableConnected);
            o.put("chargingActive", chargingActive);
            o.put("chargeLimitPercent", chargeLimitPercent);
            o.put("chargeRemainingMin", chargeRemainingMin);
            o.put("schedChargeEnabled", schedChargeEnabled);
            o.put("schedChargeStart", schedChargeStart);
            o.put("schedChargeEnd", schedChargeEnd);

            o.put("hvacPower", hvacPower);
            o.put("hvacTargetTemp", hvacTargetTemp);
            o.put("hvacFanSpeed", hvacFanSpeed);
            o.put("hvacAc", hvacAc);
            o.put("hvacAuto", hvacAuto);
            o.put("hvacRecirc", hvacRecirc);
            o.put("hvacFrontDefrost", hvacFrontDefrost);
            o.put("hvacRearDefrost", hvacRearDefrost);
            o.put("hvacEco", hvacEco);
            o.put("cabinTempC", cabinTempC);
            o.put("outsideTempC", outsideTempC);

            o.put("driverSeatHeat", driverSeatHeat);
            o.put("driverSeatVent", driverSeatVent);
            o.put("passengerSeatHeat", passengerSeatHeat);
            o.put("passengerSeatVent", passengerSeatVent);
            o.put("seatForeAft", seatForeAft);
            o.put("seatHeight", seatHeight);
            o.put("seatTilt", seatTilt);
            o.put("seatFootrest", seatFootrest);

            o.put("masterVolume", masterVolume);
            o.put("balance", balance);
            o.put("fader", fader);
            JSONArray eqArr = new JSONArray();
            for (int b : eqBands) eqArr.put(b);
            o.put("eqBands", eqArr);
            o.put("fmRadioPower", fmRadioPower);
            o.put("fmRadioFreq", fmRadioFreq);

            o.put("clusterBrightness", clusterBrightness);
            o.put("clusterTheme", clusterTheme);
            o.put("clusterTone", clusterTone);
            o.put("clusterVolume", clusterVolume);
            o.put("clusterNavDisplay", clusterNavDisplay);

            o.put("mediaSource", mediaSource);
            o.put("mediaTitle", mediaTitle);
            o.put("mediaArtist", mediaArtist);
            o.put("mediaPlaying", mediaPlaying);

            o.put("helperStatus", helperStatus);
            o.put("directCarConnected", directCarConnected);
            o.put("helperSocketConnected", helperSocketConnected);
            o.put("obdStatus", obdStatus);
            o.put("obdConnected", obdConnected);
            o.put("obdSohPercent", obdSohPercent);
            o.put("obdCellMaxV", obdCellMaxV);
            o.put("obdCellMinV", obdCellMinV);
            o.put("obdTempMaxC", obdTempMaxC);
            o.put("obdTempMinC", obdTempMinC);
            o.put("obdIsolationKohm", obdIsolationKohm);
            o.put("obdMotorRpm", obdMotorRpm);
            o.put("obdMotorTorqueNm", obdMotorTorqueNm);
            o.put("obdMotorTempC", obdMotorTempC);
            o.put("obdInverterTempC", obdInverterTempC);
            o.put("obdObcTempC", obdObcTempC);
            o.put("obdDcdcTempC", obdDcdcTempC);
            o.put("obdAcVoltage", obdAcVoltage);
            o.put("obdAcCurrent", obdAcCurrent);
            o.put("lastDtcReport", lastDtcReport);

            JSONObject sObj = new JSONObject();
            for (Map.Entry<String, Object> e : settings.entrySet()) {
                sObj.put(e.getKey(), e.getValue());
            }
            o.put("settings", sObj);
        } catch (Exception ignored) {}
        return o;
    }
}
