package tr.halil.et5.car;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/**
 * Real-Time Vehicle State for 2023 Skywell ET5 (Skyworth EV6).
 * ZERO DEMO DATA: All numeric fields initialize to unknown (-1 / Float.NaN) until
 * live CAN-Bus / AracYardimci (127.0.0.1:8724) or Bluetooth OBD2 data is received.
 */
public final class VehicleState {

    // Connection Status
    public volatile boolean helperConnected = false;
    public volatile boolean canDataReceived = false;
    public volatile boolean obdConnected = false;
    public volatile String obdStatus = "OBD2 Bekleniyor";
    public volatile String lastDtcReport = "";

    // Drive & Powertrain (-1 / Float.NaN = waiting for real vehicle CAN-Bus)
    public volatile String gear = "P"; // "P", "R", "N", "D"
    public volatile boolean autoHold = false;
    public volatile int speedKmh = 0;
    public volatile int socPercent = -1;
    public volatile float socExact = Float.NaN;
    public volatile int rangeKm = -1;
    public volatile float odometerKm = Float.NaN;
    public volatile float totalDischargeKwh = Float.NaN;
    public volatile float avgConsumptionKwh = Float.NaN;
    public volatile float powerKw = Float.NaN;
    public volatile float hvVoltage = Float.NaN;
    public volatile float hvCurrent = Float.NaN;
    public volatile int battery12v = -1;
    public volatile boolean parkingBrake = true;
    public volatile Boolean escEnabled = null;
    public volatile int driveMode = 0; // 0=Normal, 1=Eco, 2=Sport
    public volatile int regenPercent = 50; // 0..100 (energy recovery)
    public volatile int steeringMode = 1; // 0=Konfor, 1=Standart, 2=Spor
    public volatile String vin = "";

    // Optional OBD2 Extended Diagnostics (Float.NaN / -1 until OBD2 adapter connects)
    public volatile int obdMotorRpm = -1;
    public volatile float obdMotorTorqueNm = Float.NaN;
    public volatile float obdCellMaxV = Float.NaN;
    public volatile float obdCellMinV = Float.NaN;
    public volatile float obdTempMaxC = Float.NaN;
    public volatile float obdTempMinC = Float.NaN;
    public volatile int obdIsolationKohm = -1;
    public volatile float obdMotorTempC = Float.NaN;
    public volatile float obdInverterTempC = Float.NaN;
    public volatile float obdObcTempC = Float.NaN;
    public volatile float obdDcdcTempC = Float.NaN;
    public volatile float obdAcVoltage = Float.NaN;
    public volatile float obdAcCurrent = Float.NaN;

    // Exterior Lights & Turn Signals
    public volatile boolean turnLeft = false;
    public volatile boolean turnRight = false;
    public volatile boolean hazardLights = false;
    public volatile boolean brakeLight = false;
    public volatile boolean lowBeam = false;
    public volatile boolean highBeam = false;
    public volatile boolean fogLight = false;
    public volatile int headlightHeight = 0; // 0..3
    public volatile boolean followMeHome = true;

    // Doors, Hood, Trunk, Windows, Sunroof, Locks
    public final boolean[] doorsOpen = {false, false, false, false}; // FL, FR, RL, RR
    public volatile boolean hoodOpen = false;
    public volatile boolean trunkOpen = false;
    public volatile int trunkOpenPercent = 0;
    public final boolean[] windowsOpen = {false, false, false, false}; // FL, FR, RL, RR
    public final int[] windowPercent = {0, 0, 0, 0};
    public volatile boolean sunroofOpen = false;
    public volatile int sunroofPercent = 0;
    public volatile boolean locked = true;
    public volatile boolean mirrorsFolded = false;
    public volatile boolean chargePortOpen = false;

    // Tires (Float.NaN until TPMS broadcasts 0x2141502F)
    public final float[] tirePressuresBar = {Float.NaN, Float.NaN, Float.NaN, Float.NaN};
    public final float[] tireTempsC = {Float.NaN, Float.NaN, Float.NaN, Float.NaN};

    // Ultrasonic Parking Radar (Meters: 4 Front, 4 Rear, 4 Side; Float.NaN when inactive)
    public final float[] radarFront = {Float.NaN, Float.NaN, Float.NaN, Float.NaN};
    public final float[] radarRear = {Float.NaN, Float.NaN, Float.NaN, Float.NaN};
    public final float[] radarSide = {Float.NaN, Float.NaN, Float.NaN, Float.NaN};

    // Charging & V2L Discharge State
    public volatile boolean chargeCableConnected = false;
    public volatile boolean chargingActive = false;
    public volatile int chargeLimitPercent = 80;
    public volatile int chargeRemainingMin = 0;
    public volatile boolean schedChargeEnabled = false;
    public volatile String schedChargeStart = "22:00";
    public volatile String schedChargeEnd = "07:00";
    public volatile boolean v2lDischargeActive = false;
    public volatile int v2lDischargeLimit = 20;

    // HVAC / Climate State (Float.NaN until read from CarPropertyManager or skyhvac ContentProvider)
    public volatile boolean hvacPower = false;
    public volatile float hvacTargetTemp = Float.NaN;
    public volatile int hvacFanSpeed = 0; // 0..7
    public volatile boolean hvacAc = false;
    public volatile boolean hvacAuto = false;
    public volatile boolean hvacRecirc = false;
    public volatile boolean hvacFrontDefrost = false;
    public volatile boolean hvacRearDefrost = false;
    public volatile boolean hvacIonizer = false;
    public volatile float cabinTempC = Float.NaN;
    public volatile float outsideTempC = Float.NaN;

    // Seats & Mirrors (0..3 levels for Heat/Vent; -1 for unknown 4D position)
    public volatile int driverSeatHeat = 0;
    public volatile int driverSeatVent = 0;
    public volatile int passengerSeatHeat = 0;
    public volatile int passengerSeatVent = 0;
    public final int[] seatPos4D = {-1, -1, -1, -1}; // Horizontal, Vertical, Backrest, Tilt
    public final int[] mirrorPos4D = {-1, -1, -1, -1}; // LH, LV, RH, RV
    public volatile boolean welcomeSeat = true;

    // ADAS & Assistance Settings (Synced with com.skyworth.car.aisettings)
    public volatile int cruiseMode = 1; // 0=CC, 1=ACC, 2=ICA
    public volatile boolean lkaEnabled = true;
    public volatile boolean aebEnabled = true;
    public volatile boolean bsdEnabled = true;
    public volatile boolean dowEnabled = true;
    public volatile boolean hmaEnabled = true;
    public volatile boolean tsrEnabled = true;

    // Ambient Light & Instrument Cluster
    public volatile boolean ambientEnabled = true;
    public volatile int ambientColorIndex = 12; // 0..127
    public volatile int ambientBrightness = 80; // 0..100
    public volatile int ambientMode = 0; // 0=Sabit, 1=Sürüş Modu, 2=Müzik Ritmi
    public volatile int clusterTheme = 1; // 0=Klasik, 1=Yol/Navigasyon
    public volatile int clusterBrightness = 70; // 0..100

    // Special Cabin Modes
    public volatile boolean campMode = false;
    public volatile boolean petMode = false;
    public volatile boolean carWashMode = false;

    // Formatting Helpers (Never display fake numbers)
    public String formatSoc() {
        if (socPercent < 0 || socPercent > 100) return "--%";
        return socPercent + "%";
    }

    public String formatRange() {
        if (rangeKm < 0) return "-- km";
        return rangeKm + " km";
    }

    public String formatCabinTemp() {
        if (Float.isNaN(cabinTempC)) return "--.-°C";
        return String.format(Locale.US, "%.1f°C", cabinTempC);
    }

    public String formatOutsideTemp() {
        if (Float.isNaN(outsideTempC)) return "--.-°C";
        return String.format(Locale.US, "%.1f°C", outsideTempC);
    }

    public String formatHvacTargetTemp() {
        if (Float.isNaN(hvacTargetTemp) || hvacTargetTemp <= 0f) return "--.-°C";
        if (hvacTargetTemp <= 16.0f) return "LOW";
        if (hvacTargetTemp >= 32.0f) return "HI";
        return String.format(Locale.US, "%.1f°C", hvacTargetTemp);
    }

    public String formatOdometer() {
        if (Float.isNaN(odometerKm) || odometerKm < 0f) return "-- km";
        return String.format(Locale.US, "%.0f km", odometerKm);
    }

    public String formatConsumption() {
        if (Float.isNaN(avgConsumptionKwh) || avgConsumptionKwh < 0f) return "--.- kWh/100km";
        return String.format(Locale.US, "%.1f kWh/100km", avgConsumptionKwh);
    }

    public String formatPowerKw() {
        if (Float.isNaN(powerKw)) return "-- kW";
        return String.format(Locale.US, "%.1f kW", powerKw);
    }

    public String formatTireBar(int index) {
        if (index < 0 || index >= 4 || Float.isNaN(tirePressuresBar[index]) || tirePressuresBar[index] <= 0f) {
            return "-- bar";
        }
        return String.format(Locale.US, "%.2f bar", tirePressuresBar[index]);
    }

    public String formatTireTemp(int index) {
        if (index < 0 || index >= 4 || Float.isNaN(tireTempsC[index])) {
            return "--°C";
        }
        return String.format(Locale.US, "%.0f°C", tireTempsC[index]);
    }

    public void saveRealCache(Context context) {
        if (!canDataReceived || context == null) return;
        try {
            JSONObject root = new JSONObject();
            root.put("pil", socPercent);
            root.put("menzil", rangeKm);
            if (!Float.isNaN(cabinTempC)) root.put("ic", cabinTempC);
            if (!Float.isNaN(outsideTempC)) root.put("dis", outsideTempC);
            if (!Float.isNaN(odometerKm)) root.put("odo", odometerKm);
            root.put("sHeat", driverSeatHeat);
            root.put("sVent", driverSeatVent);
            root.put("yHeat", passengerSeatHeat);
            root.put("yVent", passengerSeatVent);
            root.put("bagaj", trunkOpen);
            root.put("sarj", chargingActive);

            JSONObject klima = new JSONObject();
            klima.put("acik", hvacPower);
            if (!Float.isNaN(hvacTargetTemp)) klima.put("sicaklik", hvacTargetTemp);
            klima.put("fan", hvacFanSpeed);
            klima.put("ac", hvacAc);
            klima.put("oto", hvacAuto);
            klima.put("ichava", hvacRecirc);
            root.put("klima", klima);

            SharedPreferences sp = context.getSharedPreferences("arac_onbellek", Context.MODE_PRIVATE);
            sp.edit().putString("durum", root.toString()).apply();
        } catch (Throwable ignored) {
        }
    }

    public void loadRealCache(Context context) {
        if (context == null) return;
        try {
            SharedPreferences sp = context.getSharedPreferences("arac_onbellek", Context.MODE_PRIVATE);
            String jsonStr = sp.getString("durum", null);
            if (jsonStr == null || jsonStr.isEmpty()) return;
            JSONObject j = new JSONObject(jsonStr);
            if (j.has("pil")) socPercent = j.optInt("pil", -1);
            if (j.has("menzil")) rangeKm = j.optInt("menzil", -1);
            if (j.has("ic")) cabinTempC = (float) j.optDouble("ic", Float.NaN);
            if (j.has("dis")) outsideTempC = (float) j.optDouble("dis", Float.NaN);
            if (j.has("odo")) odometerKm = (float) j.optDouble("odo", Float.NaN);
            driverSeatHeat = j.optInt("sHeat", 0);
            driverSeatVent = j.optInt("sVent", 0);
            passengerSeatHeat = j.optInt("yHeat", 0);
            passengerSeatVent = j.optInt("yVent", 0);
            trunkOpen = j.optBoolean("bagaj", false);
            chargingActive = j.optBoolean("sarj", false);

            JSONObject klima = j.optJSONObject("klima");
            if (klima != null) {
                hvacPower = klima.optBoolean("acik", false);
                if (klima.has("sicaklik")) {
                    hvacTargetTemp = (float) klima.optDouble("sicaklik", Float.NaN);
                }
                hvacFanSpeed = klima.optInt("fan", 0);
                hvacAc = klima.optBoolean("ac", false);
                hvacAuto = klima.optBoolean("oto", false);
                hvacRecirc = klima.optBoolean("ichava", false);
            }
        } catch (Throwable ignored) {
        }
    }

    public JSONObject toCar3dStateJson() {
        JSONObject o = new JSONObject();
        try {
            JSONArray doors = new JSONArray();
            for (boolean b : doorsOpen) doors.put(b);
            o.put("doors", doors);
            o.put("hood", hoodOpen);
            o.put("trunk", trunkOpen);
            o.put("charge", chargePortOpen || chargingActive || chargeCableConnected);
            o.put("left", turnLeft);
            o.put("right", turnRight);
            o.put("hazard", hazardLights);
            o.put("brake", brakeLight);
        } catch (Throwable ignored) {
        }
        return o;
    }
}
