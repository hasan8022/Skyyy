package tr.halil.et5.camera;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Size;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.nio.ByteBuffer;
import java.util.Collections;

import tr.halil.et5.helper.AdbRootBridge;

/**
 * 2023 Skywell ET5 360° AVM / Reverse Camera Hardware Decoder & Renderer.
 * Implements the exact UYVY 1280x960 half-height plane correction from FE0.java and SurfaceHolderCallbackC2307of.java,
 * and stops com.skyworth.car.evs.EvsStrategyService (OC.java) before opening Camera "0".
 */
@SuppressLint("MissingPermission")
public final class Et5ReverseCameraHelper implements SurfaceHolder.Callback {

    private static final String TAG = "Et5Kamera";
    private final Context context;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private ImageReader imageReader;
    private HandlerThread cameraThread;
    private volatile boolean closed = false;

    public Et5ReverseCameraHelper(Context context) {
        this.context = context.getApplicationContext();
    }

    public void attachToSurfaceView(SurfaceView surfaceView) {
        surfaceView.getHolder().addCallback(this);
    }

    @Override
    public void surfaceCreated(final SurfaceHolder holder) {
        closed = false;
        AdbRootBridge.stopSkyworthEvsService(context);

        cameraThread = new HandlerThread("et5-kamera-thread");
        cameraThread.start();
        final Handler handler = new Handler(cameraThread.getLooper());

        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) return;
            String[] ids = cm.getCameraIdList();
            if (ids == null || ids.length == 0) {
                Log.w(TAG, "Araçta kamera bulunamadı");
                return;
            }
            String camId = "0";
            boolean hasZero = false;
            for (String id : ids) {
                if ("0".equals(id)) {
                    hasZero = true;
                    break;
                }
            }
            if (!hasZero) camId = ids[0];

            boolean uyvyMode = true;
            int width = 1280;
            int height = 960;
            try {
                StreamConfigurationMap map = cm.getCameraCharacteristics(camId)
                        .get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map != null) {
                    Size[] sizes = map.getOutputSizes(35); // ImageFormat.YUV_420_888
                    if (sizes != null && sizes.length > 0) {
                        uyvyMode = false;
                        for (Size s : sizes) {
                            if (s.getWidth() == 1280 && s.getHeight() == 960) {
                                uyvyMode = true;
                                width = 1280;
                                height = 960;
                                break;
                            }
                        }
                        if (!uyvyMode) {
                            width = sizes[0].getWidth();
                            height = sizes[0].getHeight();
                        }
                    }
                }
            } catch (Throwable ignored) {}

            final int w = width;
            final int h = height;
            final int bmpH = uyvyMode ? (h / 2) : h;
            final boolean isUyvy = uyvyMode;
            final Bitmap bitmap = Bitmap.createBitmap(w, bmpH, Bitmap.Config.ARGB_8888);
            final int[] rgbPixels = new int[w * bmpH];
            final byte[] plane0Buf = new byte[w * h];
            final byte[] plane1Buf = new byte[w * bmpH];

            imageReader = ImageReader.newInstance(w, h, 35, 3);
            imageReader.setOnImageAvailableListener(reader -> {
                try (Image img = reader.acquireLatestImage()) {
                    if (img == null || closed) return;
                    if (isUyvy) {
                        decodeSkywellUyvy(img, plane0Buf, plane1Buf, rgbPixels, w, bmpH);
                    } else {
                        decodeStandardYuv420(img, rgbPixels, w, bmpH);
                    }
                    bitmap.setPixels(rgbPixels, 0, w, 0, 0, w, bmpH);
                    Canvas canvas = null;
                    try {
                        canvas = holder.lockHardwareCanvas();
                        if (canvas != null) {
                            float cw = canvas.getWidth();
                            float ch = canvas.getHeight();
                            canvas.drawBitmap(bitmap, null, new RectF(0, 0, cw, ch), (Paint) null);
                        }
                    } finally {
                        if (canvas != null) {
                            try {
                                holder.unlockCanvasAndPost(canvas);
                            } catch (Throwable ignored) {}
                        }
                    }
                } catch (Throwable ignored) {}
            }, handler);

            cm.openCamera(camId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    cameraDevice = camera;
                    try {
                        final CaptureRequest.Builder req = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        req.addTarget(imageReader.getSurface());
                        camera.createCaptureSession(
                            Collections.singletonList(imageReader.getSurface()),
                            new CameraCaptureSession.StateCallback() {
                                @Override
                                public void onConfigured(CameraCaptureSession session) {
                                    captureSession = session;
                                    try {
                                        session.setRepeatingRequest(req.build(), null, handler);
                                    } catch (Throwable ignored) {}
                                }
                                @Override
                                public void onConfigureFailed(CameraCaptureSession session) {}
                            },
                            handler
                        );
                    } catch (Throwable ignored) {}
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    closeCamera();
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    closeCamera();
                }
            }, handler);

        } catch (Throwable t) {
            Log.e(TAG, "Kamera açılamadı: " + t.getMessage());
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        closeCamera();
    }

    public void closeCamera() {
        closed = true;
        try {
            if (captureSession != null) captureSession.close();
        } catch (Throwable ignored) {}
        try {
            if (cameraDevice != null) cameraDevice.close();
        } catch (Throwable ignored) {}
        try {
            if (imageReader != null) imageReader.close();
        } catch (Throwable ignored) {}
        captureSession = null;
        cameraDevice = null;
        imageReader = null;
        if (cameraThread != null) {
            try {
                cameraThread.quitSafely();
            } catch (Throwable ignored) {}
            cameraThread = null;
        }
    }

    /**
     * Exact Skywell ET5 1280x960 UYVY half-height plane decoder (FE0.b).
     */
    public static void decodeSkywellUyvy(Image image, byte[] plane0, byte[] plane1, int[] outArgb, int w, int halfH) {
        ByteBuffer b0 = image.getPlanes()[0].getBuffer().duplicate();
        b0.rewind();
        b0.get(plane0, 0, Math.min(plane0.length, b0.remaining()));

        ByteBuffer b1 = image.getPlanes()[1].getBuffer().duplicate();
        b1.rewind();
        b1.get(plane1, 0, Math.min(plane1.length, b1.remaining()));

        int outIdx = 0;
        for (int y = 0; y < halfH; y++) {
            int yRow = y * w;
            int uvRow = y * 2 * w;
            for (int x = 0; x < w; x += 2) {
                int uvIdx = uvRow + x;
                int v = (plane0[uvIdx] & 0xFF) - 128;
                int u = (plane0[uvIdx + 1] & 0xFF) - 128;
                int rAdd = v * 1436;
                int gSub = (v * 731) + (u * 352);
                int bAdd = u * 1815;
                for (int dx = 0; dx < 2; dx++) {
                    int yVal = (plane1[yRow + x + dx] & 0xFF) << 10;
                    int r = (yVal + rAdd) >> 10;
                    int g = (yVal - gSub) >> 10;
                    int b = (yVal + bAdd) >> 10;
                    if (r < 0) r = 0; else if (r > 255) r = 255;
                    if (g < 0) g = 0; else if (g > 255) g = 255;
                    if (b < 0) b = 0; else if (b > 255) b = 255;
                    outArgb[outIdx++] = 0xFF000000 | (r << 16) | (g << 8) | b;
                }
            }
        }
    }

    /**
     * Standard YUV_420_888 fallback decoder (FE0.c).
     */
    public static void decodeStandardYuv420(Image image, int[] outArgb, int w, int h) {
        Image.Plane pY = image.getPlanes()[0];
        Image.Plane pU = image.getPlanes()[1];
        Image.Plane pV = image.getPlanes()[2];
        ByteBuffer bufY = pY.getBuffer();
        ByteBuffer bufU = pU.getBuffer();
        ByteBuffer bufV = pV.getBuffer();
        int rowStrideY = pY.getRowStride();
        int pixStrideY = pY.getPixelStride();
        int rowStrideUv = pU.getRowStride();
        int pixStrideUv = pU.getPixelStride();

        int outIdx = 0;
        for (int y = 0; y < h; y++) {
            int yOff = y * rowStrideY;
            int uvOff = (y >> 1) * rowStrideUv;
            for (int x = 0; x < w; x++) {
                int yVal = (bufY.get(yOff + x * pixStrideY) & 0xFF) - 16;
                if (yVal < 0) yVal = 0;
                int uvIdx = uvOff + (x >> 1) * pixStrideUv;
                int u = (bufU.get(uvIdx) & 0xFF) - 128;
                int v = (bufV.get(uvIdx) & 0xFF) - 128;
                int y1192 = yVal * 1192;
                int r = (y1192 + v * 1634) >> 10;
                int g = (y1192 - v * 833 - u * 400) >> 10;
                int b = (y1192 + u * 2066) >> 10;
                if (r < 0) r = 0; else if (r > 255) r = 255;
                if (g < 0) g = 0; else if (g > 255) g = 255;
                if (b < 0) b = 0; else if (b > 255) b = 255;
                outArgb[outIdx++] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
    }
}
