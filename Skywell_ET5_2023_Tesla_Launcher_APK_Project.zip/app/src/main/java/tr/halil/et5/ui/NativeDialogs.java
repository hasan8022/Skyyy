package tr.halil.et5.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

import tr.halil.et5.car.VehicleController;
import tr.halil.et5.car.VehicleState;
import tr.halil.et5.helper.AdbRootBridge;
import tr.halil.et5.media.Et5MediaHub;
import tr.halil.et5.media.OemMediaRouter;
import tr.halil.et5.store.Et5AppStore;
import tr.halil.et5.voice.Et5VoiceAssistant;

/**
 * 100% Native Hardware-Accelerated 60 FPS Tesla Modal Sheets for 2023 Skywell ET5:
 *  - Araç Kontrolleri, Şasi, ADAS, Ambiyans & Gösterge Paneli
 *  - Klima, Fan & Koltuk Isıtma/Soğutma Paketi
 *  - Uygulama Merkezi (Gerçek Spotify, Metrolist, SmartTube, NewPipe, OEM Radyo/Kamera + Sessiz APK Kurucu)
 *  - Gerçek Bluetooth Telefon, Rehber ve Arama Kayıtları
 *  - Türkçe Sesli Asistan (SkyVoice)
 */
public final class NativeDialogs {

    private NativeDialogs() {}

    // =========================================================================
    // 1. ARAÇ KONTROLLERİ, ŞASİ, ADAS VE SİSTEM AYARLARI PENCERESİ
    // =========================================================================
    public static void showVehicleControlSheet(Activity activity, VehicleController controller, Runnable onOpenSetupWizard) {
        Dialog dlg = createBaseDialog(activity, 0.90f, 0.88f);
        VehicleState st = controller.getState();

        LinearLayout root = createSheetContainer(activity);
        root.addView(createHeaderRow(activity, "SKYWELL ET5 — ARAÇ KONTROLLERİ & ADAS AYARLARI",
                st.helperConnected ? "● CAN-Bus Köprüsü Aktif (127.0.0.1:8724)" : "▲ Kurulum Bekleniyor (127.0.0.1:8724)",
                st.helperConnected ? "#4ADE80" : "#FBBF24", dlg::dismiss));

        ScrollView scroll = new ScrollView(activity);
        LinearLayout content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Section 1: Hızlı Gövde, Kapı, Bagaj, Cam & Tavan Kontrolleri
        content.addView(createSectionTitle(activity, "GÖVDE, KAPI, BAGAJ, CAM VE SUNROOF KONTROLLERİ"));
        LinearLayout row1 = createButtonRow(activity);
        row1.addView(createActionButton(activity, st.locked ? "🔒 Kapılar Kilitli (Aç)" : "🔓 Kapılar Açık (Kilitle)",
                st.locked ? "#1E293B" : "#2563EB", () -> {
                    controller.setDoorLocks(!st.locked);
                    dlg.dismiss();
                    showVehicleControlSheet(activity, controller, onOpenSetupWizard);
                }));
        row1.addView(createActionButton(activity, st.trunkOpen ? "🚗 Bagaj Açık (Kapat)" : "🚗 Elektrikli Bagajı Aç",
                st.trunkOpen ? "#DC2626" : "#1E293B", () -> {
                    controller.setPowerTrunk(!st.trunkOpen);
                    Toast.makeText(activity, !st.trunkOpen ? "Bagaj komutu gönderildi" : "Bagaj kapatılıyor", Toast.LENGTH_SHORT).show();
                }));
        row1.addView(createActionButton(activity, st.chargePortOpen ? "⚡ Şarj Kapağı Açık" : "⚡ Şarj Kapağını Aç",
                st.chargePortOpen ? "#16A34A" : "#1E293B", () -> {
                    controller.setChargePort(!st.chargePortOpen);
                }));
        row1.addView(createActionButton(activity, st.mirrorsFolded ? "🪞 Aynaları Aç" : "🪞 Aynaları Katla",
                st.mirrorsFolded ? "#2563EB" : "#1E293B", () -> {
                    controller.foldMirrors(!st.mirrorsFolded);
                }));
        content.addView(row1);

        LinearLayout row2 = createButtonRow(activity);
        row2.addView(createActionButton(activity, "🪟 Tüm Camları Kapat", "#1E293B", () -> controller.controlAllWindows(1)));
        row2.addView(createActionButton(activity, "🌬 Camları Havalandır (%20)", "#1E293B", () -> controller.controlAllWindows(3)));
        row2.addView(createActionButton(activity, "🪟 Tüm Camları Aç", "#1E293B", () -> controller.controlAllWindows(2)));
        row2.addView(createActionButton(activity, "☀️ Sunroof Kapat", "#1E293B", () -> controller.setSunroofPercent(0)));
        row2.addView(createActionButton(activity, "☀️ Sunroof %25", "#1E293B", () -> controller.setSunroofPercent(25)));
        row2.addView(createActionButton(activity, "☀️ Sunroof Tam Aç", "#1E293B", () -> controller.setSunroofPercent(100)));
        content.addView(row2);

        // Section 2: Sürüş Modu, Direksiyon, Enerji Geri Kazanımı & Fren
        content.addView(createSectionTitle(activity, "SÜRÜŞ MODU, DİREKSİYON & ENERJİ GERİ KAZANIMI (REJENERASYON)"));
        LinearLayout rowDrive = createButtonRow(activity);
        rowDrive.addView(createActionButton(activity, "Sürüş: Normal", st.driveMode == 0 ? "#2563EB" : "#1E293B", () -> {
            controller.setDriveMode(0);
            dlg.dismiss();
            showVehicleControlSheet(activity, controller, onOpenSetupWizard);
        }));
        rowDrive.addView(createActionButton(activity, "Sürüş: Ekonomi (ECO)", st.driveMode == 1 ? "#16A34A" : "#1E293B", () -> {
            controller.setDriveMode(1);
            dlg.dismiss();
            showVehicleControlSheet(activity, controller, onOpenSetupWizard);
        }));
        rowDrive.addView(createActionButton(activity, "Sürüş: Spor (SPORT)", st.driveMode == 2 ? "#DC2626" : "#1E293B", () -> {
            controller.setDriveMode(2);
            dlg.dismiss();
            showVehicleControlSheet(activity, controller, onOpenSetupWizard);
        }));
        rowDrive.addView(createActionButton(activity, st.autoHold ? "Auto Hold: AÇIK ✓" : "Auto Hold: KAPALI",
                st.autoHold ? "#16A34A" : "#1E293B", () -> {
                    controller.setAutoHold(!st.autoHold);
                    dlg.dismiss();
                    showVehicleControlSheet(activity, controller, onOpenSetupWizard);
                }));
        boolean escOn = st.escEnabled == null || st.escEnabled;
        rowDrive.addView(createActionButton(activity, escOn ? "ESC: AÇIK ✓" : "ESC: KAPALI !",
                escOn ? "#16A34A" : "#D97706", () -> {
                    controller.setEscEnabled(!escOn);
                    dlg.dismiss();
                    showVehicleControlSheet(activity, controller, onOpenSetupWizard);
                }));
        content.addView(rowDrive);

        LinearLayout rowRegen = createButtonRow(activity);
        int[] regenLevels = new int[]{25, 50, 75, 100};
        String[] regenNames = new String[]{"Geri Kazanım %25 (Düşük)", "Geri Kazanım %50 (Standart)", "Geri Kazanım %75 (Yüksek)", "Geri Kazanım %100 (Tek Pedal)"};
        for (int i = 0; i < regenLevels.length; i++) {
            final int pct = regenLevels[i];
            boolean active = Math.abs(st.regenPercent - pct) <= 12;
            rowRegen.addView(createActionButton(activity, regenNames[i], active ? "#0284C7" : "#1E293B", () -> {
                controller.setRegenPercent(pct);
                dlg.dismiss();
                showVehicleControlSheet(activity, controller, onOpenSetupWizard);
            }));
        }
        content.addView(rowRegen);

        // Section 3: ADAS Sürüş Destek Sistemleri
        content.addView(createSectionTitle(activity, "ADAS SÜRÜŞ DESTEK SİSTEMLERİ (com.skyworth.car.aisettings)"));
        LinearLayout rowAdas = createButtonRow(activity);
        rowAdas.addView(createActionButton(activity, st.lkaEnabled ? "Şerit Takip (LKA): AÇIK" : "Şerit Takip (LKA): KAPALI",
                st.lkaEnabled ? "#2563EB" : "#1E293B", () -> {
                    st.lkaEnabled = !st.lkaEnabled;
                    controller.writeAiDatabase("assistance", "lka", st.lkaEnabled ? 1 : 0);
                    dlg.dismiss();
                    showVehicleControlSheet(activity, controller, onOpenSetupWizard);
                }));
        rowAdas.addView(createActionButton(activity, st.aebEnabled ? "Acil Fren (AEB): AÇIK" : "Acil Fren (AEB): KAPALI",
                st.aebEnabled ? "#2563EB" : "#1E293B", () -> {
                    st.aebEnabled = !st.aebEnabled;
                    controller.writeAiDatabase("assistance", "aeb", st.aebEnabled ? 1 : 0);
                    dlg.dismiss();
                    showVehicleControlSheet(activity, controller, onOpenSetupWizard);
                }));
        rowAdas.addView(createActionButton(activity, st.bsdEnabled ? "Kör Nokta (BSD): AÇIK" : "Kör Nokta (BSD): KAPALI",
                st.bsdEnabled ? "#2563EB" : "#1E293B", () -> {
                    st.bsdEnabled = !st.bsdEnabled;
                    controller.writeAiDatabase("assistance", "bsd", st.bsdEnabled ? 1 : 0);
                    dlg.dismiss();
                    showVehicleControlSheet(activity, controller, onOpenSetupWizard);
                }));
        rowAdas.addView(createActionButton(activity, st.hmaEnabled ? "Akıllı Uzun Far: AÇIK" : "Akıllı Uzun Far: KAPALI",
                st.hmaEnabled ? "#2563EB" : "#1E293B", () -> {
                    st.hmaEnabled = !st.hmaEnabled;
                    controller.writeAiDatabase("light", "hma", st.hmaEnabled ? 1 : 0);
                    dlg.dismiss();
                    showVehicleControlSheet(activity, controller, onOpenSetupWizard);
                }));
        content.addView(rowAdas);

        // Section 4: Koltuk Hafızası, Dinlenme Modu & Özel Kabin Modları
        content.addView(createSectionTitle(activity, "KOLTUK HAFIZASI, DİNLENME KONUMU & KABİN MODLARI"));
        LinearLayout rowSeat = createButtonRow(activity);
        rowSeat.addView(createActionButton(activity, "💺 Koltuk Hafıza 1", "#1E293B", () -> controller.applySeatMemorySlot(1)));
        rowSeat.addView(createActionButton(activity, "💺 Koltuk Hafıza 2", "#1E293B", () -> controller.applySeatMemorySlot(2)));
        rowSeat.addView(createActionButton(activity, "💺 Koltuk Hafıza 3", "#1E293B", () -> controller.applySeatMemorySlot(3)));
        rowSeat.addView(createActionButton(activity, "🛌 Koltuk Dinlenme (Yatır)", "#1E293B", () -> controller.setSeatRestMode(true)));
        rowSeat.addView(createActionButton(activity, "⛺ Kamp Modu", st.campMode ? "#16A34A" : "#1E293B", () -> {
            controller.setCampMode(!st.campMode);
            dlg.dismiss();
            showVehicleControlSheet(activity, controller, onOpenSetupWizard);
        }));
        rowSeat.addView(createActionButton(activity, "🐾 Evcil Hayvan Modu", st.petMode ? "#16A34A" : "#1E293B", () -> {
            controller.setPetMode(!st.petMode);
            dlg.dismiss();
            showVehicleControlSheet(activity, controller, onOpenSetupWizard);
        }));
        rowSeat.addView(createActionButton(activity, "🚿 Oto Yıkama Modu", st.carWashMode ? "#2563EB" : "#1E293B", () -> {
            controller.setCarWashMode(!st.carWashMode);
            dlg.dismiss();
            showVehicleControlSheet(activity, controller, onOpenSetupWizard);
        }));
        content.addView(rowSeat);

        // Section 5: Şarj Limiti, Ambiyans Aydınlatma & Gösterge Paneli
        content.addView(createSectionTitle(activity, "ŞARJ LİMİTİ, AMBİYANS AYDINLATMA & DİJİTAL GÖSTERGE TEMASI"));
        LinearLayout rowCharge = createButtonRow(activity);
        rowCharge.addView(createActionButton(activity, "Şarj Limiti: %80", st.chargeLimitPercent == 80 ? "#16A34A" : "#1E293B", () -> controller.setChargeLimit(80)));
        rowCharge.addView(createActionButton(activity, "Şarj Limiti: %90", st.chargeLimitPercent == 90 ? "#16A34A" : "#1E293B", () -> controller.setChargeLimit(90)));
        rowCharge.addView(createActionButton(activity, "Şarj Limiti: %100", st.chargeLimitPercent == 100 ? "#16A34A" : "#1E293B", () -> controller.setChargeLimit(100)));
        rowCharge.addView(createActionButton(activity, "Ambiyans: Buz Mavisi", "#0284C7", () -> controller.setAmbientLight(true, 18, 90)));
        rowCharge.addView(createActionButton(activity, "Ambiyans: Zümrüt", "#16A34A", () -> controller.setAmbientLight(true, 48, 90)));
        rowCharge.addView(createActionButton(activity, "Ambiyans: Mor", "#7C3AED", () -> controller.setAmbientLight(true, 96, 90)));
        rowCharge.addView(createActionButton(activity, "Gösterge: Yol Teması", st.clusterTheme == 1 ? "#2563EB" : "#1E293B", () -> controller.setClusterTheme(1)));
        rowCharge.addView(createActionButton(activity, "Gösterge: Klasik Tema", st.clusterTheme == 0 ? "#2563EB" : "#1E293B", () -> controller.setClusterTheme(0)));
        content.addView(rowCharge);

        // Section 6: Sistem, Kurulum Sihirbazı ve Orijinal Başlatıcıya Dön
        content.addView(createSectionTitle(activity, "SİSTEM YETKİLENDİRME (ADB) & ORİJİNAL BAŞLATICI"));
        LinearLayout rowSys = createButtonRow(activity);
        rowSys.addView(createActionButton(activity, "🔑 Kurulum Sihirbazı & Coocaa OS Şifresi", "#0284C7", () -> {
            dlg.dismiss();
            if (onOpenSetupWizard != null) onOpenSetupWizard.run();
        }));
        rowSys.addView(createActionButton(activity, "🔄 CAN-Bus Köprüsünü Yeniden Başlat", "#1E293B", () -> {
            controller.reconnectNow();
            Toast.makeText(activity, "AracYardimci (127.0.0.1:8724) yeniden bağlanıyor...", Toast.LENGTH_SHORT).show();
        }));
        rowSys.addView(createActionButton(activity, "↩ Aracın Orijinal Başlatıcısına Dön", "#DC2626", () -> {
            dlg.dismiss();
            AdbRootBridge.restoreStockLauncher(activity);
        }));
        content.addView(rowSys);

        dlg.setContentView(root);
        dlg.show();
    }

    // =========================================================================
    // 2. KLİMA, FAN VE KOLTUK ISITMA / SOĞUTMA PENCERESİ
    // =========================================================================
    public static void showClimateSheet(Activity activity, VehicleController controller) {
        Dialog dlg = createBaseDialog(activity, 0.84f, 0.80f);
        VehicleState st = controller.getState();

        LinearLayout root = createSheetContainer(activity);
        root.addView(createHeaderRow(activity, "SKYWELL ET5 — İKLİMLENDİRME & KOLTUK KONFOR PAKETİ",
                "Kabin İçi: " + st.formatCabinTemp() + "   |   Dış Sıcaklık: " + st.formatOutsideTemp(),
                "#38BDF8", dlg::dismiss));

        // Temperature Control Row
        LinearLayout tempRow = new LinearLayout(activity);
        tempRow.setOrientation(LinearLayout.HORIZONTAL);
        tempRow.setGravity(Gravity.CENTER);
        tempRow.setBackground(makeRoundedBg(activity, "#131824", "#263042", 14));
        tempRow.setPadding(dp(activity, 18), dp(activity, 14), dp(activity, 18), dp(activity, 14));

        final TextView tempDisplay = new TextView(activity);
        tempDisplay.setText(st.formatHvacTargetTemp());
        tempDisplay.setTextColor(Color.WHITE);
        tempDisplay.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
        tempDisplay.setTypeface(Typeface.DEFAULT_BOLD);
        tempDisplay.setPadding(dp(activity, 28), 0, dp(activity, 28), 0);

        Button minusBtn = createActionButton(activity, "—  0.5°C Soğut", "#2563EB", () -> {
            float cur = Float.isNaN(st.hvacTargetTemp) ? 22.0f : st.hvacTargetTemp;
            controller.setHvacTemperature(cur - 0.5f);
            tempDisplay.setText(st.formatHvacTargetTemp());
        });
        Button plusBtn = createActionButton(activity, "+  0.5°C Isıt", "#DC2626", () -> {
            float cur = Float.isNaN(st.hvacTargetTemp) ? 22.0f : st.hvacTargetTemp;
            controller.setHvacTemperature(cur + 0.5f);
            tempDisplay.setText(st.formatHvacTargetTemp());
        });

        tempRow.addView(minusBtn);
        tempRow.addView(tempDisplay);
        tempRow.addView(plusBtn);
        root.addView(tempRow);

        // Quick Temperature Presets
        LinearLayout presetRow = createButtonRow(activity);
        float[] presets = new float[]{16.0f, 19.0f, 21.0f, 22.0f, 24.0f, 26.0f, 32.0f};
        String[] presetLabels = new String[]{"LOW (16°C)", "19.0°C", "21.0°C", "22.0°C", "24.0°C", "26.0°C", "HI (32°C)"};
        for (int i = 0; i < presets.length; i++) {
            final float p = presets[i];
            presetRow.addView(createActionButton(activity, presetLabels[i], "#1E293B", () -> {
                controller.setHvacTemperature(p);
                tempDisplay.setText(st.formatHvacTargetTemp());
            }));
        }
        root.addView(presetRow);

        // HVAC Mode Toggles
        root.addView(createSectionTitle(activity, "KLİMA MODLARI VE BUĞU ÇÖZÜCÜLER"));
        LinearLayout modeRow = createButtonRow(activity);
        modeRow.addView(createActionButton(activity, st.hvacPower ? "Klima Güç: AÇIK ✓" : "Klima Güç: KAPALI",
                st.hvacPower ? "#16A34A" : "#1E293B", () -> {
                    controller.setHvacPower(!st.hvacPower);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        modeRow.addView(createActionButton(activity, st.hvacAc ? "A/C Soğutma: AÇIK" : "A/C Soğutma: KAPALI",
                st.hvacAc ? "#0284C7" : "#1E293B", () -> {
                    controller.setHvacAc(!st.hvacAc);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        modeRow.addView(createActionButton(activity, st.hvacAuto ? "AUTO: AÇIK" : "AUTO: KAPALI",
                st.hvacAuto ? "#2563EB" : "#1E293B", () -> {
                    controller.setHvacAuto(!st.hvacAuto);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        modeRow.addView(createActionButton(activity, st.hvacRecirc ? "İç Hava Sirkülasyon: AÇIK" : "Dış Temiz Hava",
                st.hvacRecirc ? "#2563EB" : "#1E293B", () -> {
                    controller.setHvacRecirc(!st.hvacRecirc);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        modeRow.addView(createActionButton(activity, st.hvacFrontDefrost ? "Ön Buğu Çözücü: AÇIK" : "Ön Buğu Çözücü",
                st.hvacFrontDefrost ? "#D97706" : "#1E293B", () -> {
                    controller.setHvacFrontDefrost(!st.hvacFrontDefrost);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        modeRow.addView(createActionButton(activity, st.hvacRearDefrost ? "Arka Rezistans: AÇIK" : "Arka Rezistans",
                st.hvacRearDefrost ? "#D97706" : "#1E293B", () -> {
                    controller.setHvacRearDefrost(!st.hvacRearDefrost);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        root.addView(modeRow);

        // Fan Speed 1..7
        root.addView(createSectionTitle(activity, "FAN HIZI KADEMESİ (1 - 7)"));
        LinearLayout fanRow = createButtonRow(activity);
        for (int f = 1; f <= 7; f++) {
            final int fanLevel = f;
            boolean active = st.hvacPower && st.hvacFanSpeed == fanLevel;
            fanRow.addView(createActionButton(activity, "Fan " + fanLevel, active ? "#0284C7" : "#1E293B", () -> {
                controller.setHvacFanSpeed(fanLevel);
                dlg.dismiss();
                showClimateSheet(activity, controller);
            }));
        }
        root.addView(fanRow);

        // Seat Heating & Ventilation (Driver & Passenger)
        root.addView(createSectionTitle(activity, "SÜRÜCÜ VE YOLCU KOLTUK ISITMA / SOĞUTMA (3 KADEME)"));
        LinearLayout seatRow = createButtonRow(activity);
        seatRow.addView(createActionButton(activity, "🔥 Sürücü Isıtma: " + st.driverSeatHeat,
                st.driverSeatHeat > 0 ? "#DC2626" : "#1E293B", () -> {
                    controller.setSeatHeating(true, (st.driverSeatHeat + 1) % 4);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        seatRow.addView(createActionButton(activity, "❄️ Sürücü Soğutma: " + st.driverSeatVent,
                st.driverSeatVent > 0 ? "#0284C7" : "#1E293B", () -> {
                    controller.setSeatVentilation(true, (st.driverSeatVent + 1) % 4);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        seatRow.addView(createActionButton(activity, "🔥 Yolcu Isıtma: " + st.passengerSeatHeat,
                st.passengerSeatHeat > 0 ? "#DC2626" : "#1E293B", () -> {
                    controller.setSeatHeating(false, (st.passengerSeatHeat + 1) % 4);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        seatRow.addView(createActionButton(activity, "❄️ Yolcu Soğutma: " + st.passengerSeatVent,
                st.passengerSeatVent > 0 ? "#0284C7" : "#1E293B", () -> {
                    controller.setSeatVentilation(false, (st.passengerSeatVent + 1) % 4);
                    dlg.dismiss();
                    showClimateSheet(activity, controller);
                }));
        root.addView(seatRow);

        dlg.setContentView(root);
        dlg.show();
    }

    // =========================================================================
    // 3. GERÇEK UYGULAMA MERKEZİ & SESSİZ APK KURUCU (SPOTIFY, YOUTUBE, RADYO)
    // =========================================================================
    public static void showAppHubSheet(Activity activity, Et5MediaHub mediaHub, OemMediaRouter mediaRouter, Et5AppStore appStore) {
        Dialog dlg = createBaseDialog(activity, 0.90f, 0.88f);
        LinearLayout root = createSheetContainer(activity);

        final TextView statusBanner = new TextView(activity);
        statusBanner.setText("Yüklü uygulamalar doğrudan açılır; yüklü olmayan GMS-Free araç uygulamaları ADB üzerinden sessizce kurulur.");
        statusBanner.setTextColor(Color.parseColor("#94A3B8"));
        statusBanner.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);

        root.addView(createHeaderRow(activity, "SKYWELL ET5 — GERÇEK UYGULAMA MERKEZİ & GMS-FREE APK KURUCU",
                "Google Servisleri (GMS) gerektirmeyen gerçek Android araç uygulamaları", "#38BDF8", dlg::dismiss));
        root.addView(statusBanner);

        appStore.setCallback((pkg, percent, statusText) -> {
            statusBanner.setText(pkg + " ➔ " + statusText);
            statusBanner.setTextColor(percent >= 100 ? Color.parseColor("#4ADE80")
                    : (percent < 0 ? Color.parseColor("#EF4444") : Color.parseColor("#38BDF8")));
        });

        ScrollView scroll = new ScrollView(activity);
        LinearLayout content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // 1. Aracın Kendi Donanım Uygulamaları (OEM FM Radyo, 360 Kamera, USB Müzik, Ayarlar)
        content.addView(createSectionTitle(activity, "ARAÇ DONANIM UYGULAMALARI (DOĞRUDAN BAŞLAT)"));
        LinearLayout oemRow = createButtonRow(activity);
        oemRow.addView(createActionButton(activity, "📻 OEM FM Radyo", "#0284C7", () -> {
            dlg.dismiss();
            mediaRouter.openFmRadio();
        }));
        oemRow.addView(createActionButton(activity, "🎵 OEM USB Müzik", "#1E293B", () -> {
            dlg.dismiss();
            mediaRouter.openUsbLocalMusic();
        }));
        oemRow.addView(createActionButton(activity, "📱 OEM Bluetooth Müzik", "#1E293B", () -> {
            dlg.dismiss();
            mediaRouter.openBluetoothMusic();
        }));
        oemRow.addView(createActionButton(activity, "📷 360° AVM Kamera", "#1E293B", () -> {
            dlg.dismiss();
            launchPackageIfInstalled(activity, "com.skyworth.car.evs");
        }));
        oemRow.addView(createActionButton(activity, "🚗 Araç Ayarları (OEM)", "#1E293B", () -> {
            dlg.dismiss();
            launchPackageIfInstalled(activity, "com.skyworth.car.aisettings");
        }));
        oemRow.addView(createActionButton(activity, "⚙️ Sistem Ayarları", "#1E293B", () -> {
            dlg.dismiss();
            launchPackageIfInstalled(activity, "com.skyworth.car.systemsettings");
        }));
        content.addView(oemRow);

        // 2. GMS-Free Medya & Navigasyon Katalog Uygulamaları (Spotify, Metrolist, SmartTube, NewPipe, Yandex)
        content.addView(createSectionTitle(activity, "SPOTIFY, YOUTUBE, YOUTUBE MUSIC & NAVİGASYON (AÇ VEYA TEK TIKLA KUR)"));
        try {
            JSONArray catalog = new JSONArray(appStore.getCatalogJson());
            for (int i = 0; i < catalog.length(); i++) {
                JSONObject item = catalog.getJSONObject(i);
                final String pkg = item.getString("pkg");
                final String name = item.getString("name");
                final String desc = item.getString("desc");
                final String url = item.getString("url");
                final boolean installed = item.getBoolean("installed");

                LinearLayout card = new LinearLayout(activity);
                card.setOrientation(LinearLayout.HORIZONTAL);
                card.setGravity(Gravity.CENTER_VERTICAL);
                card.setBackground(makeRoundedBg(activity, "#131824", installed ? "#22C55E" : "#263042", 10));
                card.setPadding(dp(activity, 14), dp(activity, 10), dp(activity, 14), dp(activity, 10));
                LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                cardLp.bottomMargin = dp(activity, 8);
                card.setLayoutParams(cardLp);

                LinearLayout textCol = new LinearLayout(activity);
                textCol.setOrientation(LinearLayout.VERTICAL);
                textCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                TextView tName = new TextView(activity);
                tName.setText(name + (installed ? "  [YÜKLÜ ✓]" : "  [KURULU DEĞİL]"));
                tName.setTextColor(installed ? Color.parseColor("#4ADE80") : Color.WHITE);
                tName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                tName.setTypeface(Typeface.DEFAULT_BOLD);
                textCol.addView(tName);

                TextView tDesc = new TextView(activity);
                tDesc.setText(desc + " (" + pkg + ")");
                tDesc.setTextColor(Color.parseColor("#94A3B8"));
                tDesc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
                textCol.addView(tDesc);
                card.addView(textCol);

                Button btn = createActionButton(activity,
                        installed ? "Uygulamayı Aç ➔" : "İndir & Kur (GMS-Free)",
                        installed ? "#16A34A" : "#2563EB",
                        () -> {
                            if (installed) {
                                dlg.dismiss();
                                launchPackageIfInstalled(activity, pkg);
                            } else {
                                statusBanner.setText(name + " indiriliyor ve kuruluyor...");
                                appStore.downloadAndInstallApp(pkg, url);
                            }
                        });
                card.addView(btn);
                content.addView(card);
            }
        } catch (Throwable ignored) {
        }

        // 3. Cihazdaki Tüm Yüklü Uygulamalar
        content.addView(createSectionTitle(activity, "ARAÇTA YÜKLÜ TÜM UYGULAMALAR"));
        LinearLayout allAppsRow = createButtonRow(activity);
        try {
            PackageManager pm = activity.getPackageManager();
            Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = pm.queryIntentActivities(mainIntent, 0);
            for (ResolveInfo ri : apps) {
                final String pkg = ri.activityInfo.packageName;
                if (pkg.equals(activity.getPackageName())) continue;
                String label = ri.loadLabel(pm).toString();
                allAppsRow.addView(createActionButton(activity, label, "#1E293B", () -> {
                    dlg.dismiss();
                    launchPackageIfInstalled(activity, pkg);
                }));
            }
        } catch (Throwable ignored) {
        }
        content.addView(allAppsRow);

        dlg.setContentView(root);
        dlg.show();
    }

    // =========================================================================
    // 4. GERÇEK BLUETOOTH TELEFON, REHBER VE ARAMA KAYITLARI PENCERESİ
    // =========================================================================
    public static void showPhoneSheet(Activity activity) {
        Dialog dlg = createBaseDialog(activity, 0.80f, 0.82f);
        LinearLayout root = createSheetContainer(activity);
        root.addView(createHeaderRow(activity, "BLUETOOTH TELEFON, REHBER VE SON ARAMALAR",
                "Gerçek Android Telecom / Bluetooth HFP Arama Köprüsü", "#4ADE80", dlg::dismiss));

        LinearLayout body = new LinearLayout(activity);
        body.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Left: Dialpad
        LinearLayout dialCol = new LinearLayout(activity);
        dialCol.setOrientation(LinearLayout.VERTICAL);
        dialCol.setBackground(makeRoundedBg(activity, "#131824", "#263042", 12));
        dialCol.setPadding(dp(activity, 14), dp(activity, 12), dp(activity, 14), dp(activity, 12));
        LinearLayout.LayoutParams dialLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.42f);
        dialLp.rightMargin = dp(activity, 12);
        dialCol.setLayoutParams(dialLp);

        final EditText numberInput = new EditText(activity);
        numberInput.setHint("Numara girin...");
        numberInput.setHintTextColor(Color.parseColor("#64748B"));
        numberInput.setTextColor(Color.WHITE);
        numberInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        numberInput.setSingleLine(true);
        dialCol.addView(numberInput);

        String[][] keys = new String[][]{
                {"1", "2", "3"},
                {"4", "5", "6"},
                {"7", "8", "9"},
                {"*", "0", "#"}
        };
        for (String[] r : keys) {
            LinearLayout kr = new LinearLayout(activity);
            kr.setOrientation(LinearLayout.HORIZONTAL);
            for (final String d : r) {
                Button b = createActionButton(activity, d, "#1E293B", () -> numberInput.append(d));
                LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                blp.setMargins(dp(activity, 3), dp(activity, 3), dp(activity, 3), dp(activity, 3));
                b.setLayoutParams(blp);
                kr.addView(b);
            }
            dialCol.addView(kr);
        }

        LinearLayout callBtnRow = new LinearLayout(activity);
        callBtnRow.setOrientation(LinearLayout.HORIZONTAL);
        Button clearBtn = createActionButton(activity, "Sil ⌫", "#334155", () -> {
            String cur = numberInput.getText().toString();
            if (!cur.isEmpty()) numberInput.setText(cur.substring(0, cur.length() - 1));
        });
        Button callBtn = createActionButton(activity, "📞 Ara", "#16A34A", () -> {
            String num = numberInput.getText().toString().trim();
            if (!num.isEmpty()) placeRealPhoneCall(activity, num);
        });
        callBtnRow.addView(clearBtn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.4f));
        callBtnRow.addView(callBtn, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.6f));
        dialCol.addView(callBtnRow);
        body.addView(dialCol);

        // Right: Real Contacts & Call Log
        ScrollView contactScroll = new ScrollView(activity);
        contactScroll.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.58f));
        LinearLayout contactList = new LinearLayout(activity);
        contactList.setOrientation(LinearLayout.VERTICAL);
        contactScroll.addView(contactList);

        contactList.addView(createSectionTitle(activity, "SON ARAMALAR VE REHBER KİŞİLERİ"));
        loadRealContactsAndCalls(activity, contactList, numberInput);
        body.addView(contactScroll);

        dlg.setContentView(root);
        dlg.show();
    }

    private static void loadRealContactsAndCalls(Activity activity, LinearLayout container, EditText numberInput) {
        int count = 0;
        // 1. Recent Calls
        try (Cursor c = activity.getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME},
                null, null, CallLog.Calls.DATE + " DESC")) {
            if (c != null) {
                while (c.moveToNext() && count < 10) {
                    final String num = c.getString(0);
                    String name = c.getString(1);
                    if (num == null || num.isEmpty()) continue;
                    String label = "🕒 " + (name != null && !name.isEmpty() ? name + " (" + num + ")" : num);
                    container.addView(createActionButton(activity, label, "#131824", () -> {
                        numberInput.setText(num);
                        placeRealPhoneCall(activity, num);
                    }));
                    count++;
                }
            }
        } catch (Throwable ignored) {
        }

        // 2. Contacts
        try (Cursor c = activity.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
            if (c != null) {
                while (c.moveToNext() && count < 35) {
                    String name = c.getString(0);
                    final String num = c.getString(1);
                    if (num == null || num.isEmpty()) continue;
                    container.addView(createActionButton(activity, "👤 " + name + " — " + num, "#1E293B", () -> {
                        numberInput.setText(num);
                        placeRealPhoneCall(activity, num);
                    }));
                    count++;
                }
            }
        } catch (Throwable ignored) {
        }

        if (count == 0) {
            TextView empty = new TextView(activity);
            empty.setText("Rehber veya arama kaydı bulunamadı (Bluetooth telefon bağlantısını veya ADB izinlerini kontrol edin).");
            empty.setTextColor(Color.parseColor("#64748B"));
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            empty.setPadding(dp(activity, 8), dp(activity, 8), dp(activity, 8), dp(activity, 8));
            container.addView(empty);
        }
    }

    private static void placeRealPhoneCall(Context context, String number) {
        try {
            Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)));
            callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(callIntent);
        } catch (SecurityException se) {
            try {
                Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)));
                dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(dialIntent);
            } catch (Throwable ignored) {
            }
        }
    }

    // =========================================================================
    // 5. TÜRKÇE SESLİ ASİSTAN PENCERESİ
    // =========================================================================
    public static void showVoiceSheet(Activity activity, Et5VoiceAssistant assistant) {
        Dialog dlg = createBaseDialog(activity, 0.72f, 0.68f);
        LinearLayout root = createSheetContainer(activity);
        root.addView(createHeaderRow(activity, "SKYVOICE — TÜRKÇE DOĞAL DİL ARAÇ ASİSTANI",
                "Mikrofonla konuşun veya aşağıdaki hızlı komutlara dokunun", "#38BDF8", () -> {
                    assistant.stopListening();
                    dlg.dismiss();
                }));

        final TextView stateTv = new TextView(activity);
        stateTv.setText("🎙 Dinliyorum, komutunuzu söyleyin...");
        stateTv.setTextColor(Color.parseColor("#4ADE80"));
        stateTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        stateTv.setTypeface(Typeface.DEFAULT_BOLD);
        stateTv.setPadding(0, dp(activity, 8), 0, dp(activity, 8));
        root.addView(stateTv);

        assistant.setCallback(new Et5VoiceAssistant.AssistantCallback() {
            @Override
            public void onStateChanged(String state, String transcript, String reply, float audioLevel) {
                stateTv.setText((transcript != null && !transcript.isEmpty() ? "\"" + transcript + "\" ➔ " : "") + reply);
            }

            @Override
            public void onUiAction(String actionType, String target, String param) {
            }
        });

        LinearLayout inputRow = new LinearLayout(activity);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        final EditText cmdInput = new EditText(activity);
        cmdInput.setHint("Örn: Klimayı 22 derece yap, Bagajı aç, Koltuk ısıtmayı aç...");
        cmdInput.setHintTextColor(Color.parseColor("#64748B"));
        cmdInput.setTextColor(Color.WHITE);
        cmdInput.setSingleLine(true);
        inputRow.addView(cmdInput, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button sendBtn = createActionButton(activity, "Komutu Çalıştır", "#2563EB", () -> {
            String q = cmdInput.getText().toString().trim();
            if (!q.isEmpty()) assistant.processVoiceCommand(q);
        });
        inputRow.addView(sendBtn);
        root.addView(inputRow);

        root.addView(createSectionTitle(activity, "HIZLI SESLİ KOMUTLAR"));
        String[] sampleCmds = new String[]{
                "Klimayı 22 derece yap", "Koltuk ısıtmayı aç", "Koltuk soğutmayı aç",
                "Bagajı aç", "Cam tavanı arala", "Spor moda geç",
                "Batarya yüzde kaç", "Kamp modunu aç", "Ön cam buğusunu çöz"
        };
        LinearLayout quickRow1 = createButtonRow(activity);
        for (final String sc : sampleCmds) {
            quickRow1.addView(createActionButton(activity, sc, "#1E293B", () -> assistant.processVoiceCommand(sc)));
        }
        root.addView(quickRow1);

        dlg.setContentView(root);
        dlg.show();
        assistant.startMicrophoneVadListening(null);
    }

    public static boolean launchPackageIfInstalled(Context context, String pkg) {
        try {
            Intent i = context.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
                return true;
            }
        } catch (Throwable ignored) {
        }
        Toast.makeText(context, pkg + " uygulaması araçta bulunamadı", Toast.LENGTH_SHORT).show();
        return false;
    }

    // =========================================================================
    // UI HELPER BUILDERS
    // =========================================================================
    private static Dialog createBaseDialog(Activity activity, float widthRatio, float heightRatio) {
        Dialog dlg = new Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (dlg.getWindow() != null) {
            int w = Math.round(activity.getResources().getDisplayMetrics().widthPixels * widthRatio);
            int h = Math.round(activity.getResources().getDisplayMetrics().heightPixels * heightRatio);
            dlg.getWindow().setLayout(w, h);
            dlg.getWindow().setGravity(Gravity.CENTER);
            dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
        return dlg;
    }

    private static LinearLayout createSheetContainer(Context context) {
        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(makeRoundedBg(context, "#0B0E14", "#263042", 18));
        int p = dp(context, 18);
        root.setPadding(p, p, p, p);
        return root;
    }

    private static View createHeaderRow(Context context, String titleText, String subText, String subColorHex, Runnable onClose) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, 0, 0, dp(context, 10));

        LinearLayout titles = new LinearLayout(context);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView t = new TextView(context);
        t.setText(titleText);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        titles.addView(t);

        TextView s = new TextView(context);
        s.setText(subText);
        s.setTextColor(Color.parseColor(subColorHex));
        s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        titles.addView(s);

        row.addView(titles);

        Button closeBtn = createActionButton(context, "✕ Kapat", "#334155", onClose);
        row.addView(closeBtn);
        return row;
    }

    private static TextView createSectionTitle(Context context, String title) {
        TextView tv = new TextView(context);
        tv.setText(title);
        tv.setTextColor(Color.parseColor("#94A3B8"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, dp(context, 10), 0, dp(context, 6));
        return tv;
    }

    private static LinearLayout createButtonRow(Context context) {
        HorizontalScrollView hsv = new HorizontalScrollView(context);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout inner = new LinearLayout(context);
        inner.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(inner);

        LinearLayout wrapper = new LinearLayout(context) {
            @Override
            public void addView(View child) {
                if (child == hsv) {
                    super.addView(child);
                } else {
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.rightMargin = dp(context, 8);
                    lp.bottomMargin = dp(context, 4);
                    child.setLayoutParams(lp);
                    inner.addView(child);
                }
            }
        };
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.addView(hsv);
        return wrapper;
    }

    private static Button createActionButton(Context context, String label, String bgColorHex, Runnable onClick) {
        Button b = new Button(context);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(makeRoundedBg(context, bgColorHex, "#334155", 10));
        b.setPadding(dp(context, 14), dp(context, 9), dp(context, 14), dp(context, 9));
        b.setOnClickListener(v -> {
            if (onClick != null) onClick.run();
        });
        return b;
    }

    private static GradientDrawable makeRoundedBg(Context context, String fillHex, String strokeHex, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(fillHex));
        gd.setCornerRadius(dp(context, radiusDp));
        if (strokeHex != null) {
            gd.setStroke(Math.max(1, dp(context, 1)), Color.parseColor(strokeHex));
        }
        return gd;
    }

    private static int dp(Context context, int v) {
        return Math.round(v * context.getResources().getDisplayMetrics().density);
    }
}
