package tr.halil.et5;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import tr.halil.et5.helper.AdbRootBridge;

/**
 * Boot Receiver for 2023 Skywell ET5.
 * Starts AracYardimci helper daemon on vehicle ignition/boot.
 */
public final class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(final Context context, Intent intent) {
        if (context == null || intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            Thread t = new Thread(() -> AdbRootBridge.ensureHelperStarted(context), "et5-boot-init");
            t.setDaemon(true);
            t.start();
        }
    }
}
