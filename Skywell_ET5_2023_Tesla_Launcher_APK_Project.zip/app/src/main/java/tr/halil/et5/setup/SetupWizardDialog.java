package tr.halil.et5.setup;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import tr.halil.et5.car.VehicleController;
import tr.halil.et5.helper.AdbRootBridge;

/**
 * Skywell ET5 (2023) Kurulum Sihirbazı (IC0.java + AbstractC2297oa.t + pn0.smali birebir karşılığı).
 * Coocaa OS Geliştirici Modu şifresini otomatik hesaplar, 127.0.0.1:5555 ADB bağlantısını
 * canlı dinler ve 5 adımlı sistem + AracYardimci (127.0.0.1:8724) kurulumunu otomatik tamamlar.
 */
public final class SetupWizardDialog extends Dialog {

    private final Context context;
    private final VehicleController vehicleController;
    private final Runnable onSetupComplete;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private TextView passwordValueText;
    private TextView passwordHintText;
    private TextView vinInfoText;
    private EditText manualVinInput;
    private TextView adbStatusBanner;
    private final TextView[] stepStatusViews = new TextView[5];
    private Button actionBtn;
    private Button skipBtn;

    private volatile boolean pollingActive = false;
    private volatile boolean provisioningInProgress = false;

    public SetupWizardDialog(Context context, VehicleController vehicleController, Runnable onSetupComplete) {
        super(context, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        this.context = context;
        this.vehicleController = vehicleController;
        this.onSetupComplete = onSetupComplete;
        initUi();
    }

    private void initUi() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (getWindow() != null) {
            getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        }

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Color.parseColor("#0B0E14"));
        root.setPadding(dp(22), dp(18), dp(22), dp(18));

        // LEFT COLUMN (54%): Coocaa OS Developer Mode Steps & Password Generator
        ScrollView leftScroll = new ScrollView(context);
        LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.54f);
        leftLp.rightMargin = dp(16);
        leftScroll.setLayoutParams(leftLp);

        LinearLayout leftCard = new LinearLayout(context);
        leftCard.setOrientation(LinearLayout.VERTICAL);
        leftCard.setBackground(makeRoundedBg("#131822", "#263042", dp(16)));
        leftCard.setPadding(dp(20), dp(18), dp(20), dp(18));
        leftScroll.addView(leftCard);

        TextView title = new TextView(context);
        title.setText("SKYWELL ET5 — GERÇEK ARAÇ KÖPRÜSÜ KURULUM SİHİRBAZI");
        title.setTextColor(Color.parseColor("#38BDF8"));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        leftCard.addView(title);

        TextView subTitle = new TextView(context);
        subTitle.setText("Aracın gerçek CAN-Bus verilerini (batarya, menzil, klima, TPMS, kapılar, koltuklar) okumak ve kontrol etmek için tek seferlik Geliştirici Modu (ADB 127.0.0.1:5555) yetkilendirmesi gerekir.");
        subTitle.setTextColor(Color.parseColor("#94A3B8"));
        subTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        subTitle.setPadding(0, dp(4), 0, dp(12));
        leftCard.addView(subTitle);

        // Open System Settings Button
        Button openSettingsBtn = new Button(context);
        openSettingsBtn.setText("1. Adım: Araç Sistem Ayarlarını Aç  ➔");
        openSettingsBtn.setAllCaps(false);
        openSettingsBtn.setTextColor(Color.WHITE);
        openSettingsBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        openSettingsBtn.setTypeface(Typeface.DEFAULT_BOLD);
        openSettingsBtn.setBackground(makeRoundedBg("#2563EB", "#3B82F6", dp(10)));
        openSettingsBtn.setPadding(dp(14), dp(10), dp(14), dp(10));
        openSettingsBtn.setOnClickListener(v -> openCarSystemSettings());
        leftCard.addView(openSettingsBtn);

        // Coocaa OS Password Card
        LinearLayout passBox = new LinearLayout(context);
        passBox.setOrientation(LinearLayout.VERTICAL);
        passBox.setBackground(makeRoundedBg("#0F172A", "#22C55E", dp(12)));
        passBox.setPadding(dp(16), dp(12), dp(16), dp(12));
        LinearLayout.LayoutParams passBoxLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        passBoxLp.topMargin = dp(12);
        passBoxLp.bottomMargin = dp(12);
        passBox.setLayoutParams(passBoxLp);

        TextView passLabel = new TextView(context);
        passLabel.setText("COOCAA OS GELİŞTİRİCİ MODU PAROLASI (Sistem -> Coocaa OS logosuna 20 kez dokunun):");
        passLabel.setTextColor(Color.parseColor("#86EFAC"));
        passLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        passLabel.setTypeface(Typeface.DEFAULT_BOLD);
        passBox.addView(passLabel);

        passwordValueText = new TextView(context);
        passwordValueText.setTextColor(Color.parseColor("#4ADE80"));
        passwordValueText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        passwordValueText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        passwordValueText.setPadding(0, dp(4), 0, dp(2));
        passBox.addView(passwordValueText);

        passwordHintText = new TextView(context);
        passwordHintText.setTextColor(Color.parseColor("#CBD5E1"));
        passwordHintText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        passBox.addView(passwordHintText);

        vinInfoText = new TextView(context);
        vinInfoText.setTextColor(Color.parseColor("#64748B"));
        vinInfoText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        vinInfoText.setPadding(0, dp(4), 0, dp(4));
        passBox.addView(vinInfoText);

        // Manual VIN last 3 chars override row (in case persist.tbox.vin.name is empty before ADB)
        LinearLayout vinRow = new LinearLayout(context);
        vinRow.setOrientation(LinearLayout.HORIZONTAL);
        vinRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView vinPrompt = new TextView(context);
        vinPrompt.setText("Şasi (VIN) son 3 hane manuel giriş (gerekirse): ");
        vinPrompt.setTextColor(Color.parseColor("#94A3B8"));
        vinPrompt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        vinRow.addView(vinPrompt);

        manualVinInput = new EditText(context);
        manualVinInput.setHint("Örn: 223");
        manualVinInput.setHintTextColor(Color.parseColor("#475569"));
        manualVinInput.setTextColor(Color.WHITE);
        manualVinInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        manualVinInput.setSingleLine(true);
        manualVinInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(17)});
        manualVinInput.setBackground(makeRoundedBg("#1E293B", "#475569", dp(6)));
        manualVinInput.setPadding(dp(10), dp(4), dp(10), dp(4));
        LinearLayout.LayoutParams vinInLp = new LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT);
        manualVinInput.setLayoutParams(vinInLp);
        manualVinInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                refreshPasswordDisplay();
            }
        });
        vinRow.addView(manualVinInput);
        passBox.addView(vinRow);

        leftCard.addView(passBox);

        // Step-by-step user instructions (Exact 8 steps from AbstractC2297oa.t)
        String[] userSteps = new String[]{
                "① Yukarıdaki mavi butonla aracın kendi Ayarlar uygulamasını açın.",
                "② Sol menüden Sistem sekmesine girin; sağdaki Coocaa OS logosuna parmağınızla 20 kez üst üste dokunun.",
                "③ Çıkan \"Lütfen Parolanı Girin\" kutusuna yukarıdaki yeşil parolayı büyük/küçük harfe dikkat ederek yazıp Onayla'ya basın.",
                "④ Açılan Geliştirme Modu ekranında adb satırındaki Aç düğmesine dokunun (Durum: Açık olmalı).",
                "⑤ Bu ekrana geri dönün; birkaç saniye içinde araç ekranında \"USB hata ayıklamasına izin verilsin mi?\" penceresi çıkacaktır.",
                "⑥ Penceredeki \"Her zaman bu bilgisayardan izin ver\" kutusunu işaretleyip Tamam'a dokunun."
        };
        for (String stepStr : userSteps) {
            TextView tv = new TextView(context);
            tv.setText(stepStr);
            tv.setTextColor(Color.parseColor("#E2E8F0"));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            tv.setPadding(0, dp(3), 0, dp(3));
            leftCard.addView(tv);
        }

        root.addView(leftScroll);

        // RIGHT COLUMN (46%): Live ADB Status & 5-Step Provisioning Checklist
        LinearLayout rightCard = new LinearLayout(context);
        rightCard.setOrientation(LinearLayout.VERTICAL);
        rightCard.setBackground(makeRoundedBg("#131822", "#263042", dp(16)));
        rightCard.setPadding(dp(20), dp(18), dp(20), dp(18));
        LinearLayout.LayoutParams rightLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.46f);
        rightCard.setLayoutParams(rightLp);

        TextView rightTitle = new TextView(context);
        rightTitle.setText("CANLI BAĞLANTI & YETKİLENDİRME DURUMU");
        rightTitle.setTextColor(Color.WHITE);
        rightTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f);
        rightTitle.setTypeface(Typeface.DEFAULT_BOLD);
        rightCard.addView(rightTitle);

        adbStatusBanner = new TextView(context);
        adbStatusBanner.setText("ADB Durumu: Bağlantı bekleniyor... (127.0.0.1:5555)");
        adbStatusBanner.setTextColor(Color.parseColor("#FBBF24"));
        adbStatusBanner.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        adbStatusBanner.setTypeface(Typeface.DEFAULT_BOLD);
        adbStatusBanner.setBackground(makeRoundedBg("#1E293B", "#334155", dp(10)));
        adbStatusBanner.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams bannerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bannerLp.topMargin = dp(10);
        bannerLp.bottomMargin = dp(12);
        adbStatusBanner.setLayoutParams(bannerLp);
        rightCard.addView(adbStatusBanner);

        String[] checkTitles = new String[]{
                "1. Kalıcı ADB Anahtarı & Port 5555",
                "2. Sistem İzinleri & Telefon Rolü",
                "3. Araç CAN-Bus Köprüsü (127.0.0.1:8724)",
                "4. Varsayılan Ana Ekran & Stok Koruması",
                "5. Güvenlik Duvarı (Port 5555 Koruması)"
        };

        for (int i = 0; i < 5; i++) {
            LinearLayout row = new LinearLayout(context);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setBackground(makeRoundedBg("#0F172A", "#1E293B", dp(8)));
            row.setPadding(dp(12), dp(8), dp(12), dp(8));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dp(7);
            row.setLayoutParams(rowLp);

            TextView t = new TextView(context);
            t.setText(checkTitles[i]);
            t.setTextColor(Color.parseColor("#E2E8F0"));
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            row.addView(t);

            TextView s = new TextView(context);
            s.setText("Bekleniyor...");
            s.setTextColor(Color.parseColor("#64748B"));
            s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
            row.addView(s);
            stepStatusViews[i] = s;

            rightCard.addView(row);
        }

        View spacer = new View(context);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));
        rightCard.addView(spacer);

        actionBtn = new Button(context);
        actionBtn.setText("Şimdi Bağlan ve Kurulumu Başlat");
        actionBtn.setAllCaps(false);
        actionBtn.setTextColor(Color.WHITE);
        actionBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        actionBtn.setTypeface(Typeface.DEFAULT_BOLD);
        actionBtn.setBackground(makeRoundedBg("#16A34A", "#22C55E", dp(10)));
        actionBtn.setPadding(dp(14), dp(11), dp(14), dp(11));
        actionBtn.setOnClickListener(v -> triggerProvisioningNow());
        rightCard.addView(actionBtn);

        skipBtn = new Button(context);
        skipBtn.setText("Pencereyi Kapat (Başlatıcı Ekranına Dön)");
        skipBtn.setAllCaps(false);
        skipBtn.setTextColor(Color.parseColor("#94A3B8"));
        skipBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        skipBtn.setBackground(makeRoundedBg("#1E293B", "#334155", dp(10)));
        skipBtn.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams skipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        skipLp.topMargin = dp(8);
        skipBtn.setLayoutParams(skipLp);
        skipBtn.setOnClickListener(v -> dismiss());
        rightCard.addView(skipBtn);

        root.addView(rightCard);
        setContentView(root);

        refreshPasswordDisplay();
    }

    private void refreshPasswordDisplay() {
        String manualVin = manualVinInput != null ? manualVinInput.getText().toString().trim() : "";
        String detectedVin = AdbRootBridge.getDetectedVin();
        String skylink = AdbRootBridge.getDetectedSkylinkVersion();
        String pwd = AdbRootBridge.computeCoocaaPassword(manualVin);

        if (pwd != null) {
            passwordValueText.setText(pwd);
            passwordHintText.setText("Harf harf okunuşu: " + AdbRootBridge.formatPasswordPhoneticHint(pwd));
        } else {
            passwordValueText.setText("Şasi son 3 haneyi girin");
            passwordHintText.setText("Sistem şasi numarasını (persist.tbox.vin.name) henüz paylaşmadıysa aşağıdaki kutuya şasi son 3 hanesini yazın.");
        }
        vinInfoText.setText("Algılanan VIN: " + (detectedVin.isEmpty() ? "(bekleniyor)" : detectedVin)
                + "  |  SkyLink: " + (skylink.isEmpty() ? "(bekleniyor)" : skylink));
    }

    private void openCarSystemSettings() {
        String[] pkgs = new String[]{
                "com.skyworth.car.systemsettings",
                "com.android.car.settings",
                "com.android.settings"
        };
        for (String pkg : pkgs) {
            try {
                Intent launch = context.getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(launch);
                    return;
                }
            } catch (Throwable ignored) {
            }
        }
        try {
            Intent intent = new Intent(Settings.ACTION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        pollingActive = true;
        new Thread(this::pollAdbLoop, "Et5-SetupWizardPoll").start();
    }

    @Override
    protected void onStop() {
        pollingActive = false;
        super.onStop();
    }

    private void pollAdbLoop() {
        while (pollingActive) {
            if (!provisioningInProgress) {
                boolean helperUp = AdbRootBridge.isHelperAlive();
                if (helperUp) {
                    AdbRootBridge.markSetupCompleted(context, true);
                    mainHandler.post(() -> {
                        adbStatusBanner.setText("✓ AracYardimci Aktif (127.0.0.1:8724) — Gerçek CAN-Bus Bağlı!");
                        adbStatusBanner.setTextColor(Color.parseColor("#4ADE80"));
                        for (int i = 0; i < 5; i++) {
                            stepStatusViews[i].setText("✓ Tamamlandı");
                            stepStatusViews[i].setTextColor(Color.parseColor("#4ADE80"));
                        }
                    });
                } else {
                    boolean adbOk = AdbRootBridge.probeAdbConnection(context);
                    final String statusMsg = AdbRootBridge.getBridgeStatus();
                    mainHandler.post(() -> {
                        refreshPasswordDisplay();
                        adbStatusBanner.setText("ADB Durumu: " + statusMsg);
                        adbStatusBanner.setTextColor(adbOk ? Color.parseColor("#4ADE80") : Color.parseColor("#FBBF24"));
                    });
                    if (adbOk && !provisioningInProgress) {
                        triggerProvisioningNow();
                    }
                }
            }
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ignored) {
            }
        }
    }

    private void triggerProvisioningNow() {
        if (provisioningInProgress) return;
        provisioningInProgress = true;
        mainHandler.post(() -> {
            actionBtn.setEnabled(false);
            actionBtn.setText("Kurulum Yapılıyor, Lütfen Bekleyin...");
            adbStatusBanner.setText("ADB Bağlantısı Kuruluyor ve Yetkiler Tanımlanıyor...");
            adbStatusBanner.setTextColor(Color.parseColor("#38BDF8"));
        });

        new Thread(() -> {
            boolean ok = AdbRootBridge.runFullSetup(context, new AdbRootBridge.SetupStepCallback() {
                @Override
                public void onStepUpdate(int stepIndex, String title, String status, boolean done, boolean success) {
                    mainHandler.post(() -> {
                        if (stepIndex >= 0 && stepIndex < stepStatusViews.length) {
                            stepStatusViews[stepIndex].setText(status);
                            stepStatusViews[stepIndex].setTextColor(
                                    !done ? Color.parseColor("#38BDF8")
                                            : (success ? Color.parseColor("#4ADE80") : Color.parseColor("#FBBF24"))
                            );
                        }
                    });
                }

                @Override
                public void onSetupFinished(boolean allSuccess, String summaryMessage) {
                    mainHandler.post(() -> {
                        provisioningInProgress = false;
                        actionBtn.setEnabled(true);
                        adbStatusBanner.setText(summaryMessage);
                        adbStatusBanner.setTextColor(allSuccess ? Color.parseColor("#4ADE80") : Color.parseColor("#FBBF24"));
                        if (allSuccess) {
                            actionBtn.setText("✓ Kurulum Tamamlandı — Başlatıcıya Geç");
                            actionBtn.setOnClickListener(v -> {
                                if (vehicleController != null) vehicleController.reconnectNow();
                                if (onSetupComplete != null) onSetupComplete.run();
                                dismiss();
                            });
                            if (vehicleController != null) vehicleController.reconnectNow();
                            if (onSetupComplete != null) onSetupComplete.run();
                        } else {
                            actionBtn.setText("Tekrar Dene (ADB Bağlantısını Kontrol Edin)");
                        }
                    });
                }
            });
            if (!ok) {
                provisioningInProgress = false;
            }
        }, "Et5-Provisioning").start();
    }

    private int dp(int v) {
        return Math.round(v * context.getResources().getDisplayMetrics().density);
    }

    private GradientDrawable makeRoundedBg(String fillHex, String strokeHex, int radiusPx) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(fillHex));
        gd.setCornerRadius(radiusPx);
        if (strokeHex != null) {
            gd.setStroke(Math.max(1, dp(1)), Color.parseColor(strokeHex));
        }
        return gd;
    }
}
