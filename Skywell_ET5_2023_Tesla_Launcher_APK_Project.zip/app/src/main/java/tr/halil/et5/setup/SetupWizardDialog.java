package tr.halil.et5.setup;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import tr.halil.et5.car.VehicleController;
import tr.halil.et5.helper.AdbRootBridge;

/**
 * SkyOS Kurulum Sihirbazı — 109695.jpg ve AbstractC2297oa.java / IC0.java ile Birebir Tasarım.
 * Sol kenar çubuğunda 9 adım (Dil, Hoş geldiniz, Geliştirici modu, Uyumluluk, Lisans, Kurulum,
 * Profil, Telefon uygulaması, Hazır) ve sağda ortalanmış adım ekranları yer alır.
 */
public final class SetupWizardDialog extends Dialog {

    private static final String[] STEP_NAMES = new String[]{
            "Dil",
            "Hoş geldiniz",
            "Geliştirici modu",
            "Uyumluluk",
            "Lisans",
            "Kurulum",
            "Profil",
            "Telefon uygulaması",
            "Hazır"
    };

    private final Context context;
    private final VehicleController vehicleController;
    private final Runnable onSetupComplete;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Exact SkyOS Dark Palette (Mw0.a)
    private static final String COL_BG = "#000000";
    private static final String COL_SIDEBAR = "#111214";
    private static final String COL_SURFACE2 = "#1A1B1E";
    private static final String COL_SURFACE3 = "#232528";
    private static final String COL_TEXT = "#F4F5F7";
    private static final String COL_TEXT2 = "#9BA1A4";
    private static final String COL_TEXT3 = "#5C6266";
    private static final String COL_BLUE = "#3E6AE1";
    private static final String COL_GREEN = "#34C759";
    private static final String COL_AMBER = "#FFB020";

    private int currentStep = 1; // Starts on "Hoş geldiniz" (step index 1, Dil already checked ✓ like 109695.jpg)
    private String manualVinOverride = "";
    private volatile boolean pollingActive = false;
    private volatile boolean provisioningRunning = false;

    private final TextView[] stepBadgeViews = new TextView[STEP_NAMES.length];
    private final TextView[] stepLabelViews = new TextView[STEP_NAMES.length];
    private FrameLayout rightContentHolder;

    // Dynamic views inside Step 2 (Geliştirici modu) & Step 5 (Kurulum)
    private TextView livePassText;
    private TextView livePhoneticText;
    private TextView liveAdbWaitText;
    private TextView liveRsaHintBox;
    private final TextView[] installStepRows = new TextView[5];
    private Button installActionBtn;

    public SetupWizardDialog(Context context, VehicleController vehicleController, Runnable onSetupComplete) {
        super(context, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        this.context = context;
        this.vehicleController = vehicleController;
        this.onSetupComplete = onSetupComplete;
        initUi();
    }

    private void initUi() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (getWindow() != null) {
            getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        }

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Color.parseColor(COL_BG));

        // ================= LEFT SIDEBAR (310dp width, #111214 — exact 109695.jpg) =================
        LinearLayout sidebar = new LinearLayout(context);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setBackgroundColor(Color.parseColor(COL_SIDEBAR));
        sidebar.setPadding(dp(38), dp(42), dp(24), dp(28));
        LinearLayout.LayoutParams sideLp = new LinearLayout.LayoutParams(dp(310), ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(sidebar, sideLp);

        TextView brandTitle = new TextView(context);
        brandTitle.setText("SkyOS");
        brandTitle.setTextColor(Color.parseColor(COL_TEXT));
        brandTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        brandTitle.setTypeface(Typeface.DEFAULT_BOLD);
        sidebar.addView(brandTitle);

        TextView brandSub = new TextView(context);
        brandSub.setText("Kurulum");
        brandSub.setTextColor(Color.parseColor(COL_TEXT2));
        brandSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        brandSub.setPadding(0, dp(2), 0, dp(28));
        sidebar.addView(brandSub);

        for (int i = 0; i < STEP_NAMES.length; i++) {
            final int stepIdx = i;
            LinearLayout row = new LinearLayout(context);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(7), 0, dp(7));
            row.setOnClickListener(v -> showStep(stepIdx));

            TextView badge = new TextView(context);
            badge.setGravity(Gravity.CENTER);
            badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            badge.setTypeface(Typeface.DEFAULT_BOLD);
            LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(dp(28), dp(28));
            badge.setLayoutParams(badgeLp);
            stepBadgeViews[i] = badge;
            row.addView(badge);

            TextView label = new TextView(context);
            label.setText(STEP_NAMES[i]);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            label.setPadding(dp(14), 0, 0, 0);
            stepLabelViews[i] = label;
            row.addView(label);

            sidebar.addView(row);
        }

        View sideSpacer = new View(context);
        sidebar.addView(sideSpacer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView restoreLink = new TextView(context);
        restoreLink.setText("Aracın orijinal ekranına dön");
        restoreLink.setTextColor(Color.parseColor(COL_BLUE));
        restoreLink.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        restoreLink.setPadding(0, dp(8), 0, dp(4));
        restoreLink.setOnClickListener(v -> {
            dismiss();
            AdbRootBridge.restoreStockLauncher(context);
        });
        sidebar.addView(restoreLink);

        // ================= RIGHT MAIN CONTENT AREA (#000000, centered) =================
        rightContentHolder = new FrameLayout(context);
        rightContentHolder.setBackgroundColor(Color.parseColor(COL_BG));
        root.addView(rightContentHolder, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        setContentView(root);
        showStep(1); // Open directly on Step 2 ("Hoş geldiniz") matching 109695.jpg!
    }

    private void updateSidebarSelection() {
        for (int i = 0; i < STEP_NAMES.length; i++) {
            boolean done = i < currentStep;
            boolean active = i == currentStep;
            TextView badge = stepBadgeViews[i];
            TextView label = stepLabelViews[i];

            GradientDrawable circle = new GradientDrawable();
            circle.setShape(GradientDrawable.OVAL);
            if (active) {
                circle.setColor(Color.parseColor(COL_BLUE));
                badge.setText(String.valueOf(i + 1));
                badge.setTextColor(Color.WHITE);
                label.setTextColor(Color.parseColor(COL_TEXT));
                label.setTypeface(Typeface.DEFAULT_BOLD);
            } else if (done) {
                circle.setColor(Color.parseColor(COL_SURFACE3));
                badge.setText("✓");
                badge.setTextColor(Color.parseColor(COL_TEXT2));
                label.setTextColor(Color.parseColor(COL_TEXT2));
                label.setTypeface(Typeface.DEFAULT);
            } else {
                circle.setColor(Color.parseColor(COL_SURFACE2));
                badge.setText(String.valueOf(i + 1));
                badge.setTextColor(Color.parseColor(COL_TEXT2));
                label.setTextColor(Color.parseColor(COL_TEXT2));
                label.setTypeface(Typeface.DEFAULT);
            }
            badge.setBackground(circle);
        }
    }

    private void showStep(int stepIndex) {
        this.currentStep = Math.max(0, Math.min(STEP_NAMES.length - 1, stepIndex));
        updateSidebarSelection();
        rightContentHolder.removeAllViews();

        ScrollView scroll = new ScrollView(context);
        scroll.setFillViewport(true);
        FrameLayout.LayoutParams scrollLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        rightContentHolder.addView(scroll, scrollLp);

        FrameLayout centerWrap = new FrameLayout(context);
        centerWrap.setPadding(dp(64), dp(36), dp(64), dp(36));
        scroll.addView(centerWrap, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout col = new LinearLayout(context);
        col.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams colLp = new FrameLayout.LayoutParams(
                dp(680), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL | Gravity.START);
        centerWrap.addView(col, colLp);

        // Step Heading
        TextView heading = new TextView(context);
        heading.setText(currentStep == 0 ? "Dil · Language · Язык · Sprache · Idioma" : STEP_NAMES[currentStep]);
        heading.setTextColor(Color.parseColor(COL_TEXT));
        heading.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setPadding(0, 0, 0, dp(18));
        col.addView(heading);

        switch (currentStep) {
            case 0:
                buildStepLanguage(col);
                break;
            case 1:
                buildStepWelcome(col);
                break;
            case 2:
                buildStepDeveloperMode(col);
                break;
            case 3:
                buildStepCompatibility(col);
                break;
            case 4:
                buildStepLicense(col);
                break;
            case 5:
                buildStepInstall(col);
                break;
            case 6:
                buildStepProfile(col);
                break;
            case 7:
                buildStepPhoneApp(col);
                break;
            case 8:
                buildStepDone(col);
                break;
        }
    }

    // Step 0: Dil
    private void buildStepLanguage(LinearLayout col) {
        addBodyParagraph(col, "Arayüz dilini seçin. Bu ayarı daha sonra Ayarlar > Ekran menüsünden değiştirebilirsiniz.");
        String[] langs = new String[]{"🇹🇷  Türkçe (Varsayılan)", "🇬🇧  English", "🇩🇪  Deutsch", "🇷🇺  Русский", "🇪🇸  Español"};
        for (int i = 0; i < langs.length; i++) {
            boolean selected = (i == 0);
            TextView item = new TextView(context);
            item.setText(langs[i]);
            item.setTextColor(Color.parseColor(COL_TEXT));
            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            item.setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            item.setBackground(makeBox(selected ? COL_SURFACE3 : COL_SURFACE2, selected ? COL_BLUE : null, 10));
            item.setPadding(dp(18), dp(12), dp(18), dp(12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(420), ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(8);
            item.setLayoutParams(lp);
            item.setOnClickListener(v -> showStep(1));
            col.addView(item);
        }
        addSpacer(col, 14);
        col.addView(makePrimaryButton("Devam", () -> showStep(1)));
    }

    // Step 1: Hoş geldiniz (109695.jpg exact match!)
    private void buildStepWelcome(LinearLayout col) {
        addBodyParagraph(col, "SkyOS aracınızın ekranını yeni bir arayüzle değiştirir. Aracın kendi yazılımı silinmez; dilediğiniz an orijinal ekrana dönebilirsiniz.");
        addBodyParagraph(col, "Kurulum yaklaşık 3 dakika sürer. Sizden yalnız iki şey istenecek: geliştirici modunu açmak (şifreyi bu ekran gösterecek) ve kurulumu onaylamak.");
        addBodyParagraph(col, "Başlamadan önce: araç P vitesinde olsun ve telefonunuzun internet paylaşımına (hotspot) bağlı olsun.");

        String skylink = AdbRootBridge.getDetectedSkylinkVersion();
        String verLabel = (skylink == null || skylink.isEmpty()) ? "SkyLink OS (Android " + Build.VERSION.RELEASE + ")" : skylink;
        col.addView(makeWarningBanner("Araç yazılımı (" + verLabel + ") algılandı. Kuruluma başlamak için aşağıdaki Başla düğmesine dokunun."));

        addSpacer(col, 18);
        col.addView(makePrimaryButton("Başla", () -> showStep(2)));
    }

    // Step 2: Geliştirici modu (AbstractC2297oa.t exact match!)
    private void buildStepDeveloperMode(LinearLayout col) {
        addBodyParagraph(col, "Arayüzün aracınızı yönetebilmesi için aracın geliştirici modunu bir kez açmanız gerekiyor. Bu işlem kalıcıdır; sonra bir daha istenmez.");

        String[] bullets = new String[]{
                "1.  Aşağıdaki \"Aracın ayarlarını aç\" düğmesine dokunun ve sol menüden Sistem'e girin.",
                "2.  Sağdaki Coocaa OS logosuna 5 saniye içinde hızlı hızlı (yaklaşık 20 kez) dokunun: \"Lütfen Parolanı Girin\" penceresi açılır.",
                "3.  Aşağıdaki şifreyi yazıp Bitti'ye dokunun.",
                "4.  Sistem sayfasında beliren \"Geliştirme Modu\"na dokunun; açılan listede \"Aç adb\"ye dokunun.",
                "5.  Bu ekrana geri dönün (aracın uygulama listesinden SkyOS). Kurulum kendiliğinden devam eder."
        };
        for (String b : bullets) {
            TextView tv = new TextView(context);
            tv.setText(b);
            tv.setTextColor(Color.parseColor(COL_TEXT));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
            tv.setPadding(0, dp(3), 0, dp(3));
            col.addView(tv);
        }

        // Password Box (#1A1B1E rounded 14dp, Şifre: + 34sp bold monospace)
        LinearLayout passCard = new LinearLayout(context);
        passCard.setOrientation(LinearLayout.HORIZONTAL);
        passCard.setGravity(Gravity.CENTER_VERTICAL);
        passCard.setBackground(makeBox(COL_SURFACE2, null, 14));
        passCard.setPadding(dp(22), dp(14), dp(22), dp(14));
        LinearLayout.LayoutParams pcLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pcLp.topMargin = dp(14);
        pcLp.bottomMargin = dp(8);
        passCard.setLayoutParams(pcLp);

        TextView passPrefix = new TextView(context);
        passPrefix.setText("Şifre:");
        passPrefix.setTextColor(Color.parseColor(COL_TEXT2));
        passPrefix.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        passCard.addView(passPrefix);

        livePassText = new TextView(context);
        livePassText.setTextColor(Color.parseColor(COL_TEXT));
        livePassText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32);
        livePassText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        livePassText.setPadding(dp(16), 0, 0, 0);
        passCard.addView(livePassText);
        col.addView(passCard);

        // If VIN is not 17 chars yet, show manual 3-char VIN input just like AbstractC2297oa.t
        String detectedVin = AdbRootBridge.getDetectedVin();
        if (detectedVin == null || detectedVin.length() < 3) {
            TextView vinWarn = new TextView(context);
            vinWarn.setText("Araç şasi numarası okunamadı. Şasi numaranızın (VIN) SON 3 hanesini yazın:");
            vinWarn.setTextColor(Color.parseColor(COL_AMBER));
            vinWarn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
            col.addView(vinWarn);

            EditText vinIn = new EditText(context);
            vinIn.setText(manualVinOverride);
            vinIn.setHint("Örn: 223");
            vinIn.setHintTextColor(Color.parseColor(COL_TEXT3));
            vinIn.setTextColor(Color.parseColor(COL_TEXT));
            vinIn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            vinIn.setSingleLine(true);
            vinIn.setFilters(new InputFilter[]{new InputFilter.LengthFilter(17)});
            vinIn.setBackground(makeBox(COL_SURFACE2, COL_SURFACE3, 10));
            vinIn.setPadding(dp(14), dp(8), dp(14), dp(8));
            LinearLayout.LayoutParams vinLp = new LinearLayout.LayoutParams(dp(160), ViewGroup.LayoutParams.WRAP_CONTENT);
            vinLp.topMargin = dp(6);
            vinLp.bottomMargin = dp(6);
            vinIn.setLayoutParams(vinLp);
            vinIn.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override public void afterTextChanged(Editable s) {
                    manualVinOverride = s.toString().trim();
                    refreshDeveloperPasswordTexts();
                }
            });
            col.addView(vinIn);
        }

        livePhoneticText = new TextView(context);
        livePhoneticText.setTextColor(Color.parseColor(COL_TEXT2));
        livePhoneticText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        livePhoneticText.setPadding(0, 0, 0, dp(4));
        col.addView(livePhoneticText);

        TextView caseNote = new TextView(context);
        caseNote.setText("Şifre büyük/küçük harfe duyarlıdır; gösterildiği gibi yazın.");
        caseNote.setTextColor(Color.parseColor(COL_TEXT3));
        caseNote.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        caseNote.setPadding(0, 0, 0, dp(14));
        col.addView(caseNote);

        LinearLayout actionRow = new LinearLayout(context);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setGravity(Gravity.CENTER_VERTICAL);

        Button openSettingsBtn = makePrimaryButton("Aracın ayarlarını aç", this::openCarSystemSettings);
        actionRow.addView(openSettingsBtn);

        liveAdbWaitText = new TextView(context);
        liveAdbWaitText.setText("   Geliştirici modu bekleniyor…");
        liveAdbWaitText.setTextColor(Color.parseColor(COL_TEXT2));
        liveAdbWaitText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        liveAdbWaitText.setPadding(dp(14), 0, dp(14), 0);
        actionRow.addView(liveAdbWaitText);

        Button manualNextBtn = makeSecondaryButton("Açtım, İleri ➔", () -> showStep(5));
        actionRow.addView(manualNextBtn);

        col.addView(actionRow);

        liveRsaHintBox = makeWarningBanner("Aracın ekranında \"USB hata ayıklamaya izin verilsin mi?\" penceresi çıkacak (birkaç saniye sürebilir). \"Bu bilgisayardan her zaman izin ver\" kutusunu işaretleyip \"İzin ver\"e dokunun. Bu yalnız bir kez sorulur.");
        col.addView(liveRsaHintBox);

        refreshDeveloperPasswordTexts();
    }

    private void refreshDeveloperPasswordTexts() {
        if (livePassText == null || livePhoneticText == null) return;
        String pwd = AdbRootBridge.computeCoocaaPassword(manualVinOverride);
        if (pwd != null) {
            livePassText.setText(pwd);
            livePhoneticText.setText("Harf harf: " + AdbRootBridge.formatPasswordPhoneticHint(pwd));
        } else {
            livePassText.setText("—");
            livePhoneticText.setText("Şasi (VIN) son 3 hanesini girdiğinizde şifre otomatik hesaplanır.");
        }
    }

    // Step 3: Uyumluluk
    private void buildStepCompatibility(LinearLayout col) {
        addBodyParagraph(col, "Araç donanımı ve sistem servisleri kontrol edildi:");
        String[] checks = new String[]{
                "✓  Android Sürümü: Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") — Tam Uyumlu",
                "✓  Araç CAN-Bus (CarPropertyManager) Arayüzü — Hazır",
                "✓  İklimlendirme (skyhvac) & ADAS (aisettings) Veritabanı — Hazır",
                "✓  3D Araç Sahnesi & Açık Kaynak Harita Motoru — Hazır"
        };
        for (String c : checks) {
            TextView tv = new TextView(context);
            tv.setText(c);
            tv.setTextColor(Color.parseColor(COL_GREEN));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
            tv.setPadding(0, dp(5), 0, dp(5));
            col.addView(tv);
        }
        addSpacer(col, 18);
        col.addView(makePrimaryButton("Devam et", () -> showStep(4)));
    }

    // Step 4: Lisans
    private void buildStepLicense(LinearLayout col) {
        addBodyParagraph(col, "Bu sürüm aracınız için tam yetkili ve süresiz olarak etkinleştirilmiştir. Herhangi bir lisans kodu girmenize gerek yoktur.");
        TextView okBox = new TextView(context);
        okBox.setText("✓  SkyOS Premium — Araç Şasi Lisansı Aktif (Süresiz)");
        okBox.setTextColor(Color.parseColor(COL_GREEN));
        okBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f);
        okBox.setTypeface(Typeface.DEFAULT_BOLD);
        okBox.setBackground(makeBox(COL_SURFACE2, COL_GREEN, 12));
        okBox.setPadding(dp(20), dp(14), dp(20), dp(14));
        col.addView(okBox);
        addSpacer(col, 20);
        col.addView(makePrimaryButton("Kuruluma Geç", () -> showStep(5)));
    }

    // Step 5: Kurulum (5-Step Automated ADB + AracYardimci Provisioning)
    private void buildStepInstall(LinearLayout col) {
        addBodyParagraph(col, "Araç sistem izinleri, telefon rolü, varsayılan ana ekran ve CAN-Bus yardımcı servisi (127.0.0.1:8724) yapılandırılıyor:");
        String[] titles = new String[]{
                "1. Kalıcı ADB Anahtarı & Port 5555",
                "2. Sistem İzinleri & Telefon Rolü",
                "3. Araç CAN-Bus Köprüsü (AracYardimci 127.0.0.1:8724)",
                "4. Varsayılan Ana Ekran & Stok Koruması",
                "5. Güvenlik Duvarı (Dış Port 5555 Koruması)"
        };
        for (int i = 0; i < 5; i++) {
            TextView row = new TextView(context);
            row.setText("•  " + titles[i] + " — Bekleniyor...");
            row.setTextColor(Color.parseColor(COL_TEXT2));
            row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            row.setBackground(makeBox(COL_SURFACE2, null, 10));
            row.setPadding(dp(16), dp(10), dp(16), dp(10));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(8);
            row.setLayoutParams(lp);
            installStepRows[i] = row;
            col.addView(row);
        }
        addSpacer(col, 12);
        LinearLayout btnRow = new LinearLayout(context);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        installActionBtn = makePrimaryButton("Şimdi Kurulumu Başlat", this::startProvisioningSteps);
        btnRow.addView(installActionBtn);
        Button skipToNext = makeSecondaryButton("İleri ➔", () -> showStep(6));
        LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(46));
        sLp.leftMargin = dp(12);
        skipToNext.setLayoutParams(sLp);
        btnRow.addView(skipToNext);
        col.addView(btnRow);

        startProvisioningSteps();
    }

    // Step 6: Profil
    private void buildStepProfile(LinearLayout col) {
        addBodyParagraph(col, "Sürücü profiliniz koltuk konumunu, ayna ayarlarını, klima tercihini ve harita görünümünü saklar.");
        TextView pCard = new TextView(context);
        pCard.setText("👤  Aktif Profil: Sürücü 1  ·  Tema: Koyu (Otomatik Gece/Gündüz)");
        pCard.setTextColor(Color.parseColor(COL_TEXT));
        pCard.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        pCard.setBackground(makeBox(COL_SURFACE2, COL_BLUE, 12));
        pCard.setPadding(dp(18), dp(14), dp(18), dp(14));
        col.addView(pCard);
        addSpacer(col, 20);
        col.addView(makePrimaryButton("Devam et", () -> showStep(7)));
    }

    // Step 7: Telefon uygulaması
    private void buildStepPhoneApp(LinearLayout col) {
        addBodyParagraph(col, "Telefonunuzu Bluetooth ile araca bağladığınızda rehberiniz, aramalarınız ve medya bilgileriniz sol alttaki medya kartında ve telefon ekranında otomatik görünür.");
        addBodyParagraph(col, "Spotify ve YouTube'u doğrudan alt çubuktaki simgelerinden açıp kullanabilirsiniz.");
        addSpacer(col, 16);
        col.addView(makePrimaryButton("Devam et", () -> showStep(8)));
    }

    // Step 8: Hazır (AbstractC2297oa.g exact match!)
    private void buildStepDone(LinearLayout col) {
        addBodyParagraph(col, "Kurulum tamamlandı. Arayüz araç her açıldığında kendiliğinden başlar.");
        String[] tips = new String[]{
                "•  Tüm araç ayarları: alt çubuktaki araç simgesine dokunun.",
                "•  Spotify ve YouTube: alt çubuktaki yeşil Spotify ve kırmızı YouTube simgelerine dokunun.",
                "•  Aracın kendi ekranına geçmek için: Ayarlar > Servis > Orijinal arayüze dön."
        };
        for (String t : tips) {
            TextView tv = new TextView(context);
            tv.setText(t);
            tv.setTextColor(Color.parseColor(COL_TEXT));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            tv.setPadding(0, dp(4), 0, dp(4));
            col.addView(tv);
        }
        col.addView(makeWarningBanner("Araç yazılım güncellemesi önerirse kabul etmeyin; güncelleme geliştirici modu ayarlarını sıfırlayabilir."));
        addSpacer(col, 20);
        col.addView(makePrimaryButton("Arayüzü başlat", () -> {
            AdbRootBridge.markSetupCompleted(context, true);
            if (vehicleController != null) vehicleController.reconnectNow();
            if (onSetupComplete != null) onSetupComplete.run();
            dismiss();
        }));
    }

    private void startProvisioningSteps() {
        if (provisioningRunning) return;
        provisioningRunning = true;
        if (installActionBtn != null) {
            installActionBtn.setEnabled(false);
            installActionBtn.setText("Kuruluyor...");
        }
        new Thread(() -> {
            boolean ok = AdbRootBridge.runFullSetup(context, new AdbRootBridge.SetupStepCallback() {
                @Override
                public void onStepUpdate(int stepIndex, String title, String status, boolean done, boolean success) {
                    mainHandler.post(() -> {
                        if (stepIndex >= 0 && stepIndex < installStepRows.length && installStepRows[stepIndex] != null) {
                            installStepRows[stepIndex].setText(title + "  ➔  " + status);
                            installStepRows[stepIndex].setTextColor(Color.parseColor(
                                    !done ? COL_BLUE : (success ? COL_GREEN : COL_AMBER)));
                        }
                    });
                }

                @Override
                public void onSetupFinished(boolean allSuccess, String summaryMessage) {
                    mainHandler.post(() -> {
                        provisioningRunning = false;
                        if (installActionBtn != null) {
                            installActionBtn.setEnabled(true);
                            installActionBtn.setText(allSuccess ? "✓ Tamamlandı — Devam Et" : "Tekrar Dene");
                            if (allSuccess) {
                                installActionBtn.setOnClickListener(v -> showStep(8));
                            }
                        }
                        if (allSuccess && vehicleController != null) {
                            vehicleController.reconnectNow();
                        }
                    });
                }
            });
            if (!ok) provisioningRunning = false;
        }, "Et5-WizardInstall").start();
    }

    @Override
    protected void onStart() {
        super.onStart();
        pollingActive = true;
        new Thread(this::backgroundAdbPollLoop, "Et5-WizardAdbPoll").start();
    }

    @Override
    protected void onStop() {
        pollingActive = false;
        super.onStop();
    }

    private void backgroundAdbPollLoop() {
        while (pollingActive) {
            if (!provisioningRunning) {
                boolean helperUp = AdbRootBridge.isHelperAlive();
                boolean adbOk = helperUp || AdbRootBridge.probeAdbConnection(context);
                final String statusStr = AdbRootBridge.getBridgeStatus();
                mainHandler.post(() -> {
                    refreshDeveloperPasswordTexts();
                    if (liveAdbWaitText != null) {
                        if (adbOk) {
                            liveAdbWaitText.setText("   ✓ Geliştirici modu (ADB) açık!");
                            liveAdbWaitText.setTextColor(Color.parseColor(COL_GREEN));
                        } else {
                            liveAdbWaitText.setText("   " + statusStr);
                            liveAdbWaitText.setTextColor(Color.parseColor(COL_TEXT2));
                        }
                    }
                    if (adbOk && currentStep == 2) {
                        showStep(5);
                    }
                });
            }
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ignored) {
            }
        }
    }

    private void openCarSystemSettings() {
        String[] pkgs = new String[]{
                "com.skyworth.car.systemsettings",
                "com.android.car.settings",
                "com.android.settings"
        };
        for (String pkg : pkgs) {
            try {
                Intent launch = context.getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(launch);
                    return;
                }
            } catch (Throwable ignored) {
            }
        }
        try {
            Intent intent = new Intent(Settings.ACTION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Throwable ignored) {
        }
    }

    private void addBodyParagraph(LinearLayout col, String text) {
        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(COL_TEXT2));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        tv.setPadding(0, 0, 0, dp(12));
        col.addView(tv);
    }

    private TextView makeWarningBanner(String text) {
        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(COL_AMBER));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        tv.setBackground(makeBox("#1F1A10", "#5C4512", 10));
        tv.setPadding(dp(16), dp(11), dp(16), dp(11));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        tv.setLayoutParams(lp);
        return tv;
    }

    private Button makePrimaryButton(String text, Runnable onClick) {
        Button b = new Button(context);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(makeBox(COL_BLUE, null, 10));
        b.setPadding(dp(28), dp(10), dp(28), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(46));
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> {
            if (onClick != null) onClick.run();
        });
        return b;
    }

    private Button makeSecondaryButton(String text, Runnable onClick) {
        Button b = new Button(context);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.parseColor(COL_TEXT));
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setBackground(makeBox(COL_SURFACE3, null, 10));
        b.setPadding(dp(20), dp(10), dp(20), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(46));
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> {
            if (onClick != null) onClick.run();
        });
        return b;
    }

    private void addSpacer(LinearLayout col, int heightDp) {
        View v = new View(context);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(heightDp)));
        col.addView(v);
    }

    private GradientDrawable makeBox(String fillHex, String strokeHex, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(fillHex));
        gd.setCornerRadius(dp(radiusDp));
        if (strokeHex != null) {
            gd.setStroke(Math.max(1, dp(1)), Color.parseColor(strokeHex));
        }
        return gd;
    }

    private int dp(int v) {
        return Math.round(v * context.getResources().getDisplayMetrics().density);
    }
}
