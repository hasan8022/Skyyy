package tr.halil.et5;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.nio.charset.StandardCharsets;

/**
 * Automatic Bluetooth Pairing Confirmation Receiver for OBD2 (vLinker/ELM327) and Phones.
 */
@SuppressLint("MissingPermission")
public final class PairingReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !BluetoothDevice.ACTION_PAIRING_REQUEST.equals(intent.getAction())) {
            return;
        }
        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        if (device == null) return;
        int variant = intent.getIntExtra(BluetoothDevice.EXTRA_PAIRING_VARIANT, -1);
        try {
            if (variant == BluetoothDevice.PAIRING_VARIANT_PIN) {
                device.setPin("1234".getBytes(StandardCharsets.UTF_8));
            } else {
                device.setPairingConfirmation(true);
            }
        } catch (Throwable ignored) {}
    }
}
