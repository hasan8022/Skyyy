package tr.halil.et5.voice;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import tr.halil.et5.car.Et5PropertyCatalog;
import tr.halil.et5.car.VehicleController;
import tr.halil.et5.car.VehicleState;

/**
 * Skywell ET5 (2023) GMS-Free Yerleşik Türkçe Sesli Asistan (F8.java, C8.java, C0383Mh.java, C0714Xh.java).
 * Android 9 (API 28) ve Android 12 (API 31/32) tam uyumludur.
 */
public class Et5VoiceAssistant {
    private static final String TAG = "Et5Asistan";
    private static final Locale TR_LOCALE = new Locale("tr", "TR");

    public interface AssistantCallback {
        void onStateChanged(String state, String transcript, String reply, float audioLevel);
        void onUiAction(String actionType, String target, String param);
    }

    private final Context context;
    private final VehicleController vehicleController;
    private final AudioManager audioManager;
    private final File ttsCacheDir;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private TextToSpeech fallbackTts;
    private boolean fallbackTtsReady = false;
    private MediaPlayer activePlayer;
    private volatile boolean isListening = false;
    private boolean seatRestActive = false;
    private AssistantCallback callback;

    private static final List<String> BOOST_PHRASES_TR = Arrays.asList(
            "tavan perdesi", "tavan perdesini aç", "tavan perdesini kapat",
            "cam tavan", "cam tavanı aç", "cam tavanı kapat", "tavanı arala",
            "klimayı aç", "klimayı kapat", "koltuk ısıtma", "koltuk ısıtmayı aç",
            "yolcu koltuğu", "sürücü koltuğu", "ön cam buğusu", "arka cam buğusu",
            "iç aydınlatma", "ambiyans", "kamp modu", "evcil hayvan modu", "oto yıkama modu",
            "sıcaklığı", "derece", "fanı", "eve git", "işe git",
            "en yakın şarj istasyonu", "bagajı aç", "şarjı bitir",
            "youtube aç", "spotify çal", "radyoyu aç", "batarya yüzde kaç", "menzil kaç km"
    );

    public Et5VoiceAssistant(Context context, VehicleController vehicleController) {
        this.context = context.getApplicationContext();
        this.vehicleController = vehicleController;
        this.audioManager = (AudioManager) this.context.getSystemService(Context.AUDIO_SERVICE);
        this.ttsCacheDir = new File(this.context.getCacheDir(), "ses");
        if (!this.ttsCacheDir.exists()) {
            this.ttsCacheDir.mkdirs();
        }
        initFallbackTts();
    }

    private void initFallbackTts() {
        try {
            fallbackTts = new TextToSpeech(context, status -> {
                if (status == TextToSpeech.SUCCESS && fallbackTts != null) {
                    int res = fallbackTts.setLanguage(TR_LOCALE);
                    fallbackTtsReady = (res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED);
                }
            });
        } catch (Throwable ignored) {
        }
    }

    public void setCallback(AssistantCallback cb) {
        this.callback = cb;
    }

    public boolean isListening() {
        return isListening;
    }

    public void stopListening() {
        isListening = false;
    }

    /**
     * C0383Mh.java: 16kHz PCM Mikrofon Kaydedici + Gerçek Zamanlı VAD (Ses Etkinliği Algılama).
     */
    public void startMicrophoneVadListening(final String cloudSttApiKey) {
        if (isListening) {
            isListening = false;
            return;
        }
        isListening = true;
        notifyState("LISTENING", "", "Dinliyorum, komutunuzu söyleyin...", 0.05f);

        new Thread(() -> {
            AudioRecord recorder = null;
            try {
                int minBuf = Math.max(AudioRecord.getMinBufferSize(16000, 16, 2), 16000);
                recorder = new AudioRecord(6 /* VOICE_RECOGNITION */, 16000, 16 /* CHANNEL_IN_MONO */, 2 /* PCM_16BIT */, minBuf);
                if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                    recorder.release();
                    isListening = false;
                    notifyState("ERROR", "", "Mikrofon açılamadı (izin veya donanım meşgul)", 0f);
                    return;
                }

                ByteArrayOutputStream pcmOut = new ByteArrayOutputStream();
                short[] frame = new short[320]; // 20ms @ 16kHz
                recorder.startRecording();

                long elapsedMs = 0;
                long speechStartMs = -1;
                long lastSpeechMs = -1;
                long activeSpeechAccumMs = 0;
                long silenceAfterSpeechMs = 0;
                boolean speechDetected = false;
                double noiseFloor = -1.0;
                double maxRms = 0.0;

                while (isListening && elapsedMs < 10000) {
                    int read = recorder.read(frame, 0, 320);
                    if (read > 0) {
                        double sumSq = 0;
                        int peak = 0;
                        for (int i = 0; i < read; i++) {
                            short s = frame[i];
                            sumSq += (double) s * s;
                            int abs = Math.abs((int) s);
                            if (abs > peak) peak = abs;
                            pcmOut.write(s & 0xFF);
                            pcmOut.write((s >> 8) & 0xFF);
                        }
                        double rms = Math.sqrt(sumSq / read);
                        elapsedMs += 20;

                        float normLevel = Math.min(1.0f, Math.max(0.0f, peak / 12000.0f));
                        notifyState("LISTENING", "", "Dinliyorum...", normLevel);

                        if (noiseFloor < 0 || (elapsedMs <= 300 && rms < noiseFloor)) {
                            noiseFloor = rms;
                        }
                        if (rms > maxRms) maxRms = rms;

                        if (elapsedMs > 300) {
                            boolean strongSpeech = rms > Math.max(1.8 * noiseFloor, 220.0);
                            boolean contSpeech = rms > Math.max(1.5 * noiseFloor, Math.max(noiseFloor + 100.0, 150.0));
                            if (strongSpeech) {
                                activeSpeechAccumMs += 20;
                                if (activeSpeechAccumMs >= 100) speechDetected = true;
                                if (speechStartMs < 0) speechStartMs = elapsedMs;
                                lastSpeechMs = elapsedMs;
                            } else if (!speechDetected) {
                                activeSpeechAccumMs = 0;
                            }

                            if (speechDetected && contSpeech) {
                                silenceAfterSpeechMs = 0;
                            } else {
                                silenceAfterSpeechMs += 20;
                            }

                            if (!contSpeech && (!speechDetected || elapsedMs - lastSpeechMs > 1500)) {
                                noiseFloor = rms * 0.03 + noiseFloor * 0.97;
                            }

                            if ((speechDetected && silenceAfterSpeechMs >= 750)
                                    || (speechDetected && (elapsedMs - lastSpeechMs > 1800 || elapsedMs - speechStartMs > 8000))
                                    || (!speechDetected && elapsedMs > 4500)) {
                                break;
                            }
                        }
                    }
                }

                try {
                    recorder.stop();
                } catch (Throwable ignored) {
                }
                recorder.release();
                recorder = null;
                isListening = false;

                if (!speechDetected && maxRms < Math.max(noiseFloor * 1.5, 200.0)) {
                    String msg = "Bir şey duyamadım. Mikrofona dokunup tekrar söyleyebilir ya da hızlı komut seçebilirsiniz.";
                    notifyState("IDLE", "", msg, 0f);
                    speak(msg);
                    return;
                }

                byte[] rawPcm = pcmOut.toByteArray();
                byte[] normalizedPcm = normalizePcmGain(rawPcm);
                notifyState("PROCESSING", "", "Ses analiz ediliyor...", 0f);

                String transcript = null;
                if (cloudSttApiKey != null && !cloudSttApiKey.trim().isEmpty()) {
                    transcript = recognizeViaCloudRest(normalizedPcm, 16000, cloudSttApiKey.trim());
                }
                if (transcript != null && !transcript.trim().isEmpty()) {
                    processVoiceCommand(transcript.trim());
                } else {
                    notifyState("WEB_SPEECH_FALLBACK", "", "Ses algılandı. Hızlı komut seçebilir veya yazabilirsiniz.", 0f);
                }
            } catch (Throwable t) {
                Log.w(TAG, "VAD dinleme hatasi: " + t.getMessage());
                isListening = false;
                notifyState("IDLE", "", "Sesli komut hazır.", 0f);
            } finally {
                if (recorder != null) {
                    try {
                        recorder.release();
                    } catch (Throwable ignored) {
                    }
                }
            }
        }, "Et5-VadMic").start();
    }

    private byte[] normalizePcmGain(byte[] pcm) {
        int samples = pcm.length / 2;
        if (samples == 0) return pcm;
        int maxSample = 1;
        for (int i = 0; i < samples; i++) {
            int idx = i * 2;
            short s = (short) ((pcm[idx] & 0xFF) | (pcm[idx + 1] << 8));
            int abs = Math.abs((int) s);
            if (abs > maxSample) maxSample = abs;
        }
        double gain = Math.min(8.0, 26000.0 / maxSample);
        if (gain < 1.2) return pcm;
        byte[] out = new byte[samples * 2];
        for (int i = 0; i < samples; i++) {
            int idx = i * 2;
            short s = (short) ((pcm[idx] & 0xFF) | (pcm[idx + 1] << 8));
            int amplified = Math.max(-32768, Math.min(32767, (int) (s * gain)));
            out[idx] = (byte) (amplified & 0xFF);
            out[idx + 1] = (byte) ((amplified >> 8) & 0xFF);
        }
        return out;
    }

    private String recognizeViaCloudRest(byte[] pcm16k, int sampleRate, String apiKey) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://speech.googleapis.com/v1/speech:recognize?key=" + URLEncoder.encode(apiKey, "UTF-8"));
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(10000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

            JSONObject config = new JSONObject()
                    .put("languageCode", "tr-TR")
                    .put("encoding", "LINEAR16")
                    .put("sampleRateHertz", sampleRate)
                    .put("enableAutomaticPunctuation", true)
                    .put("model", "latest_short")
                    .put("speechContexts", new JSONArray().put(
                            new JSONObject().put("phrases", new JSONArray(BOOST_PHRASES_TR)).put("boost", 10)
                    ));
            JSONObject body = new JSONObject()
                    .put("config", config)
                    .put("audio", new JSONObject().put("content", Base64.encodeToString(pcm16k, Base64.NO_WRAP)));

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            if (conn.getResponseCode() == 200) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                JSONObject resp = new JSONObject(sb.toString());
                JSONArray results = resp.optJSONArray("results");
                if (results != null && results.length() > 0) {
                    JSONArray alts = results.getJSONObject(0).optJSONArray("alternatives");
                    if (alts != null && alts.length() > 0) {
                        return alts.getJSONObject(0).optString("transcript", "");
                    }
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return null;
    }

    /**
     * F8.java & F8.smali: Doğal Dil Türkçe Araç İçi Komut Çözücü ve Uygulayıcı (60+ Komut).
     */
    public String processVoiceCommand(String rawInput) {
        if (rawInput == null || rawInput.trim().isEmpty()) {
            String msg = "Bir şey duyamadım.";
            notifyState("IDLE", "", msg, 0f);
            speak(msg);
            return msg;
        }

        String text = rawInput.trim();
        String low = text.toLowerCase(TR_LOCALE)
                .replaceAll("[^a-zçğıöşü0-9., ]", " ")
                .replaceAll("\\s+", " ")
                .trim();

        VehicleState st = vehicleController.getState();
        String reply = null;

        // 1. Batarya ve Şarj Durumu Soruları
        if (low.matches(".*(şarj|sarj|batarya|pil)\\S*\\s*(kaç|ne kadar|durum|yüzde).*|.*kaç\\s*(yüzde|%).*")) {
            reply = "Batarya yüzde " + st.socPercent + ", tahmini menzil " + st.rangeKm + " kilometre"
                    + (st.chargingActive ? ", şu an şarj oluyor." : ".");
        }
        // 2. Menzil Soruları
        else if (low.matches(".*(menzil|kaç\\s*(km|kilometre)\\s*(gider|gideriz|kaldı|yol)|ne kadar (yol|gider)).*")) {
            reply = "Tahmini menzil " + st.rangeKm + " kilometre, batarya yüzde " + st.socPercent + ".";
        }
        // 3. Saat Sorusu
        else if (low.contains("saat kaç")) {
            String now = new SimpleDateFormat("HH:mm", TR_LOCALE).format(new Date());
            reply = "Saat " + now + ".";
        }
        // 4. Dış / İç Sıcaklık ve Hava Durumu Soruları
        else if (low.matches(".*(dışarı|dış|hava)\\S*\\s*(sıcaklı|kaç derece|durumu).*|.*hava kaç derece.*")) {
            reply = String.format(TR_LOCALE, "Dışarısı %.0f derece, araç içerisi %.0f derece.", st.outsideTempC, st.cabinTempC);
        } else if (low.matches(".*(içerisi|iç sıcaklık|araç içi)\\S*\\s*(kaç|sıcaklı).*")) {
            reply = String.format(TR_LOCALE, "İçerisi %.0f derece.", st.cabinTempC);
        }
        // 5. Üşüdüm / Terledim Doğal İklimlendirme Komutları
        else if (low.matches(".*(üşüdüm|üşüyorum|soğuk oldu|soğuk geldi|ısıt|i am cold|too cold).*") && !low.contains("koltuk")) {
            float target = Math.min(32.0f, st.hvacTargetTemp + 1.5f);
            vehicleController.setHvacPower(true);
            vehicleController.setHvacTemperature(target);
            reply = "Sıcaklığı biraz artırıyorum, " + String.format(TR_LOCALE, "%.1f", target) + " derece.";
        } else if (low.matches(".*(çok sıcak|sıcak oldu|sıcak geldi|terledim|bunaldım|serinlet|soğut|too hot).*") && !low.contains("koltuk")) {
            float target = Math.max(18.0f, st.hvacTargetTemp - 1.5f);
            vehicleController.setHvacPower(true);
            vehicleController.setHvacAc(true);
            vehicleController.setHvacTemperature(target);
            reply = "Sıcaklığı biraz düşürüyorum, " + String.format(TR_LOCALE, "%.1f", target) + " derece.";
        }
        // 6. Spesifik Klima Derecesi Ayarlama ("klimayı 22 derece yap", "23.5 derece")
        else if (extractTemperatureCommand(low) != null) {
            float deg = extractTemperatureCommand(low);
            deg = Math.max(18.0f, Math.min(32.0f, deg));
            vehicleController.setHvacPower(true);
            vehicleController.setHvacTemperature(deg);
            reply = "Sıcaklığı " + (deg == (int) deg ? String.valueOf((int) deg) : String.valueOf(deg)) + " derece yapıyorum.";
        }
        // 7. Fan Hızı Ayarlama ("fanı 4 yap")
        else if (extractFanCommand(low) != null) {
            int fan = Math.max(1, Math.min(7, extractFanCommand(low)));
            vehicleController.setHvacPower(true);
            vehicleController.setHvacFanSpeed(fan);
            reply = "Fanı " + fan + " yapıyorum.";
        }
        // 8. Ön / Arka Cam Buğu Çözme
        else if (low.matches(".*(ön\\s*)?(cam|buğu)\\S*\\s*(buğusunu|buğu)?\\s*(aç|çöz|al|temizle).*|.*defrost.*")) {
            vehicleController.setHvacFrontDefrost(true);
            reply = "Ön cam buğu çözmeyi açıyorum.";
        }
        // 9. Klima Aç / Kapat
        else if (low.matches(".*klima\\S*\\s*(aç|çalıştır|başlat).*")) {
            vehicleController.setHvacPower(true);
            reply = "Klimayı açıyorum.";
        } else if (low.matches(".*klima\\S*\\s*(kapat|kapa|durdur).*")) {
            vehicleController.setHvacPower(false);
            reply = "Klimayı kapatıyorum.";
        }
        // 10. Koltuk Isıtma / Soğutma / Uyku Konumu
        else if (low.contains("koltuk") && (low.contains("ısıtma") || low.contains("soğutma") || low.contains("havalandırma") || low.contains("uyku") || low.contains("dinlenme") || low.contains("yatır"))) {
            boolean open = !low.matches(".*(kapat|kapa|durdur).*");
            boolean passenger = low.contains("yolcu") || low.contains("sağ");
            boolean both = low.contains("ikisi") || low.contains("koltukları") || low.contains("her iki");
            if (low.contains("uyku") || low.contains("dinlenme") || low.contains("yatır")) {
                seatRestActive = !seatRestActive;
                if (seatRestActive) {
                    vehicleController.moveDriverSeatPosition(95, 25, 85, 85);
                    reply = "Sürücü koltuğu dinlenme konumuna alınıyor.";
                } else {
                    vehicleController.moveDriverSeatPosition(50, 50, 50, 0);
                    reply = "Sürücü koltuğu normal sürüş konumuna dönüyor.";
                }
            } else if (low.contains("soğutma") || low.contains("havalandırma")) {
                int lvl = open ? 3 : 0;
                if (both || !passenger) vehicleController.setSeatVentilation(true, lvl);
                if (both || passenger) vehicleController.setSeatVentilation(false, lvl);
                reply = open ? "Koltuk havalandırmayı açıyorum." : "Koltuk havalandırmayı kapatıyorum.";
            } else {
                int lvl = open ? 3 : 0;
                if (both || !passenger) vehicleController.setSeatHeating(true, lvl);
                if (both || passenger) vehicleController.setSeatHeating(false, lvl);
                reply = open ? "Koltuk ısıtmayı açıyorum." : "Koltuk ısıtmayı kapatıyorum.";
            }
        }
        // 11. İç Aydınlatma / Ambiyans
        else if (low.matches(".*(iç\\s*aydınlatma|ambiyans|iç\\s*ışık|ortam\\s*ışı).*")) {
            boolean open = !low.matches(".*(kapat|kapa|söndür).*");
            vehicleController.setVehicleSetting("ambiyans", open ? 1 : 0);
            reply = open ? "İç aydınlatmayı açıyorum." : "İç aydınlatmayı kapatıyorum.";
        }
        // 12. Tavan Perdesi (Sunshade) & Cam Tavan (Sunroof)
        else if (low.matches(".*(perde|güneşlik).*")) {
            boolean open = !low.matches(".*(kapat|kapa|indir|çek).*");
            vehicleController.setProperty(Et5PropertyCatalog.PROP_SUNSHADE_CMD, 0, "i", open ? "2" : "1");
            reply = open ? "Tavan perdesini açıyorum." : "Tavan perdesini kapatıyorum.";
        } else if (low.matches(".*(cam\\s*tavan|tavan|sunroof).*")) {
            if (low.matches(".*(arala|havalandır|biraz aç|hafif aç|yarım).*")) {
                vehicleController.setProperty(Et5PropertyCatalog.PROP_SUNROOF_CMD, 0, "i", "3");
                reply = "Cam tavanı aralıyorum.";
            } else if (low.matches(".*(kapat|kapa).*")) {
                vehicleController.setSunroof(false);
                reply = "Cam tavanı kapatıyorum.";
            } else {
                vehicleController.setSunroof(true);
                reply = "Cam tavanı açıyorum.";
            }
        }
        // 13. Camlar (Windows)
        else if (low.matches(".*\\bcam(lar|ı|ları)?\\b.*") && !low.contains("tavan") && !low.contains("buğu")) {
            boolean open = !low.matches(".*(kapat|kapa|yukarı|kaldır).*");
            if (low.contains("arala") || low.contains("havalandır")) {
                vehicleController.controlAllWindows(3);
                reply = "Camları aralıyorum.";
            } else {
                vehicleController.controlAllWindows(open ? 2 : 1);
                reply = open ? "Camları açıyorum." : "Camları kapatıyorum.";
            }
        }
        // 14. Bagaj & Kapı Kilitleri
        else if (low.contains("bagaj")) {
            if (!"P".equals(st.gear)) {
                reply = "Güvenlik nedeniyle bagajı yalnız P vitesindeyken açabilirim.";
            } else {
                boolean open = !low.matches(".*(kapat|kapa).*");
                vehicleController.setPowerTrunk(open);
                reply = open ? "Bagajı açıyorum." : "Bagajı kapatıyorum.";
            }
        } else if (low.contains("kilitle") || (low.contains("kilit") && low.contains("aç"))) {
            boolean lock = low.contains("kilitle") || !low.contains("aç");
            if (!lock && st.speedKmh > 5) {
                reply = "Araç hareket halindeyken kapı kilidini açamam.";
            } else {
                vehicleController.setProperty(Et5PropertyCatalog.PROP_CENTRAL_LOCK, 0, "i", lock ? "1" : "2");
                reply = lock ? "Kapıları kilitliyorum." : "Kapı kilitlerini açıyorum.";
            }
        }
        // 15. Şarjı Bitir / Durdur
        else if (low.matches(".*(şarj|sarj)\\S*\\s*(bitir|durdur|kes|sonlandır|kapat).*")) {
            vehicleController.startOrStopCharging(false);
            reply = "Şarjı bitiriyorum.";
        }
        // 16. Akıllı Modlar: Kamp / Evcil Hayvan / Oto Yıkama / Kış / Vale Modu
        else if (low.matches(".*(kamp|evcil|köpek|kedi|yıkama|kış|vale)\\S*\\s*mod.*")) {
            boolean open = !low.matches(".*(kapat|kapa|bitir|çık|sonlandır).*");
            if (low.contains("kamp")) {
                vehicleController.setHvacPower(open);
                fireUiAction("MODE", "CAMP", String.valueOf(open));
                reply = open ? "Kamp modunu açıyorum." : "Kamp modunu kapatıyorum.";
            } else if (low.contains("evcil") || low.contains("köpek") || low.contains("kedi")) {
                vehicleController.setHvacPower(open);
                fireUiAction("MODE", "PET", String.valueOf(open));
                reply = open ? "Evcil hayvan modunu açıyorum, klima açık kalacak." : "Evcil hayvan modunu kapatıyorum.";
            } else if (low.contains("yıkama")) {
                vehicleController.controlAllWindows(1);
                vehicleController.setSunroof(false);
                vehicleController.foldMirrors(true);
                fireUiAction("MODE", "WASH", String.valueOf(open));
                reply = open ? "Oto yıkama modunu açıyorum; camlar kapatılıyor ve aynalar katlanıyor." : "Oto yıkama modunu kapatıyorum.";
            } else if (low.contains("kış")) {
                vehicleController.setVehicleSetting("surus_modu", open ? 1 : 0);
                reply = open ? "Kış modunu açıyorum." : "Kış modunu kapatıyorum.";
            } else {
                fireUiAction("MODE", "VALET", String.valueOf(open));
                reply = open ? "Vale modu ekranını açıyorum." : "Vale modunu kapatıyorum.";
            }
        }
        // 17. Sürüş Modları (Spor / Konfor / Normal)
        else if (low.matches(".*(spor|konfor|ekonomi|eco|normal)\\s*mod.*")) {
            if (low.contains("spor")) {
                vehicleController.setVehicleSetting("surus_modu", 2);
                reply = "Spor sürüş moduna geçiyorum.";
            } else if (low.contains("konfor") || low.contains("ekonomi") || low.contains("eco")) {
                vehicleController.setVehicleSetting("surus_modu", 1);
                reply = "Ekonomi sürüş moduna geçiyorum.";
            } else {
                vehicleController.setVehicleSetting("surus_modu", 0);
                reply = "Normal sürüş moduna geçiyorum.";
            }
        }
        // 18. YouTube / Spotify / Radyo / Medya Komutları
        else if (low.contains("youtube")) {
            String query = low.replaceAll(".*youtube('da|da| müzik| music)?\\s*", "")
                    .replaceAll("\\s*(aç|çal|oynat|ara|göster)$", "").trim();
            fireUiAction("OPEN_MEDIA", "YOUTUBE", query);
            reply = query.isEmpty() ? "YouTube ekranını açıyorum." : "YouTube'da " + query + " açılıyor.";
        } else if (low.contains("spotify")) {
            String query = low.replaceAll(".*spotify('da|da)?\\s*", "")
                    .replaceAll("\\s*(aç|çal|oynat|ara|göster)$", "").trim();
            fireUiAction("OPEN_MEDIA", "SPOTIFY", query);
            reply = query.isEmpty() ? "Spotify ekranını açıyorum." : "Spotify'da " + query + " çalınıyor.";
        } else if (low.matches(".*(radyo|fm|trt|kral|power|fenomen|joy|metro|süper|alem)\\S*\\s*(aç|çal|başlat).*")) {
            fireUiAction("OPEN_MEDIA", "INTERNET_RADIO", low);
            reply = "Radyoyu açıyorum.";
        } else if (low.matches(".*(sonraki|sıradaki)\\s*(şarkı|parça).*|.*şarkıyı geç.*")) {
            fireUiAction("MEDIA_KEY", "NEXT", "");
            reply = "Sonraki parçaya geçiyorum.";
        } else if (low.matches(".*önceki\\s*(şarkı|parça).*")) {
            fireUiAction("MEDIA_KEY", "PREV", "");
            reply = "Önceki parçaya dönüyorum.";
        } else if (low.matches(".*müziği\\s*(durdur|kapat|duraklat).*")) {
            fireUiAction("MEDIA_KEY", "PAUSE", "");
            reply = "Müziği duraklatıyorum.";
        } else if (low.matches(".*(müziği|müzik)\\s*(başlat|aç|çal|devam).*")) {
            fireUiAction("MEDIA_KEY", "PLAY", "");
            reply = "Müziği başlatıyorum.";
        }
        // 19. Ses Seviyesi Komutları
        else if (low.matches(".*ses\\S*\\s*(\\d{1,2})\\s*(yap|olsun).*")) {
            Matcher m = Pattern.compile("(\\d{1,2})").matcher(low);
            if (m.find()) {
                int vol = Integer.parseInt(m.group(1));
                vehicleController.setMasterVolume(vol);
                reply = "Sesi " + vol + " yapıyorum.";
            }
        } else if (low.matches(".*(sesi aç|sesi yükselt|sesi artır).*")) {
            vehicleController.setMasterVolume(st.masterVolume + 4);
            reply = "Sesi yükseltiyorum.";
        } else if (low.matches(".*(sesi kıs|sesi düşür|sesi azalt).*")) {
            vehicleController.setMasterVolume(st.masterVolume - 4);
            reply = "Sesi kısıyorum.";
        } else if (low.matches(".*(sessize al|sesi kapat).*")) {
            vehicleController.setMasterVolume(0);
            reply = "Sesi kapatıyorum.";
        }
        // 20. Navigasyon & Rota Komutları
        else if (low.matches(".*(eve git|eve gidelim|beni eve götür|evime git|eve dön).*")) {
            fireUiAction("NAVIGATE", "home", "");
            reply = "Eve gidiyoruz.";
        } else if (low.matches(".*(işe git|işe gidelim|beni işe götür|ofise git).*")) {
            fireUiAction("NAVIGATE", "work", "");
            reply = "İşe gidiyoruz.";
        } else if (low.matches(".*(yakındaki şarj|en yakın şarj|yol üstü şarj|şarj istasyonu).*")) {
            fireUiAction("NAVIGATE", "chargers", "");
            reply = "Yakındaki elektrikli araç şarj istasyonlarını haritada gösteriyorum.";
        } else if (low.matches(".*(navigasyonu|rotayı|yol tarifini)\\s*(kapat|iptal|bitir).*")) {
            fireUiAction("NAVIGATE", "cancel", "");
            reply = "Navigasyonu kapatıyorum.";
        }
        // 21. Ekran Açma Komutları
        else if (low.matches(".*(kamerayı|360|avm)\\s*(aç|göster).*")) {
            fireUiAction("SCREEN", "camera", "");
            reply = "Kamerayı açıyorum.";
        } else if (low.matches(".*(enerji|tüketim)\\s*(ekranını)?\\s*(aç|göster).*")) {
            fireUiAction("SCREEN", "energy", "");
            reply = "Enerji ve tasarruf ekranını açıyorum.";
        } else if (low.matches(".*(obd|arıza|dtc)\\s*(ekranını|taraması)?\\s*(aç|göster|yap).*")) {
            fireUiAction("SCREEN", "obd", "");
            reply = "OBD2 ve arıza tespit ekranını açıyorum.";
        } else if (low.matches(".*(uygulamaları|mağazayı)\\s*(aç|göster).*")) {
            fireUiAction("SCREEN", "store", "");
            reply = "Uygulama mağazasını açıyorum.";
        } else if (low.matches(".*(ayarları|hızlı kontrolleri)\\s*(aç|göster).*")) {
            fireUiAction("SCREEN", "controls", "");
            reply = "Araç kontrol merkezini açıyorum.";
        } else if (low.matches(".*(haritayı)\\s*(aç|göster).*")) {
            fireUiAction("SCREEN", "map", "");
            reply = "Haritayı açıyorum.";
        } else if (low.matches(".*(orijinal|fabrika|kendi)\\s*(ekran|sistem)\\S*\\s*(dön|geç).*|.*kurtarma mod.*")) {
            fireUiAction("SCREEN", "restore_stock", "");
            reply = "Kurtarma moduna geçiyorum, aracın orijinal ekranı açılıyor.";
        } else {
            reply = "Anlaşıldı: \"" + text + "\".";
            fireUiAction("SEARCH", "global", text);
        }

        notifyState("DONE", text, reply, 0f);
        speak(reply);
        return reply;
    }

    private Float extractTemperatureCommand(String low) {
        Matcher m = Pattern.compile("(?:klima\\S*|sıcaklı\\S*|ısı\\S*)?\\D*?(\\d{2}(?:[.,]5)?)\\s*derece|(?:klima\\S*|sıcaklı\\S*)\\D*?(\\d{2}(?:[.,]5)?)").matcher(low);
        if (m.find()) {
            String g = m.group(1) != null ? m.group(1) : m.group(2);
            if (g != null) {
                try {
                    return Float.parseFloat(g.replace(',', '.'));
                } catch (Exception ignored) {
                }
            }
        }
        return null;
    }

    private Integer extractFanCommand(String low) {
        Matcher m = Pattern.compile("fan\\S*\\s*(\\d)").matcher(low);
        if (m.find()) {
            try {
                return Integer.parseInt(m.group(1));
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    public void speak(final String text) {
        if (text == null || text.trim().isEmpty()) return;
        new Thread(() -> {
            try {
                File mp3File = getOrDownloadCachedTtsMp3(text.trim());
                if (mp3File != null && mp3File.exists() && mp3File.length() > 128) {
                    playMp3WithDucking(mp3File);
                    return;
                }
            } catch (Throwable ignored) {
            }
            if (fallbackTtsReady && fallbackTts != null) {
                try {
                    fallbackTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "et5_tts_" + System.currentTimeMillis());
                } catch (Throwable ignored) {
                }
            }
        }, "Et5-TTS").start();
    }

    private File getOrDownloadCachedTtsMp3(String cleanText) throws Exception {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] digest = sha1.digest(("tr|" + cleanText).getBytes(StandardCharsets.UTF_8));
        StringBuilder hex = new StringBuilder();
        for (byte b : digest) hex.append(String.format("%02x", b));
        File cached = new File(ttsCacheDir, hex.toString() + ".mp3");
        if (cached.exists() && cached.length() > 128) {
            return cached;
        }
        String urlStr = "https://translate.googleapis.com/translate_tts?ie=UTF-8&client=tw-ob&tl=tr&q="
                + URLEncoder.encode(cleanText, "UTF-8");
        HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(6000);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12; Skywell ET5)");
        if (conn.getResponseCode() == 200) {
            try (InputStream is = conn.getInputStream();
                 FileOutputStream fos = new FileOutputStream(cached)) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = is.read(buf)) > 0) fos.write(buf, 0, n);
            }
            conn.disconnect();
            return cached;
        }
        conn.disconnect();
        return null;
    }

    private void playMp3WithDucking(File mp3File) {
        mainHandler.post(() -> {
            AudioFocusRequest focusReq = null;
            try {
                if (activePlayer != null) {
                    try {
                        activePlayer.stop();
                        activePlayer.release();
                    } catch (Throwable ignored) {
                    }
                }
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build();

                if (Build.VERSION.SDK_INT >= 26 && audioManager != null) {
                    focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                            .setAudioAttributes(attrs)
                            .build();
                    audioManager.requestAudioFocus(focusReq);
                }

                final AudioFocusRequest finalFocusReq = focusReq;
                activePlayer = new MediaPlayer();
                activePlayer.setAudioAttributes(attrs);
                activePlayer.setDataSource(mp3File.getAbsolutePath());
                activePlayer.setOnCompletionListener(mp -> {
                    try {
                        mp.release();
                    } catch (Throwable ignored) {
                    }
                    if (Build.VERSION.SDK_INT >= 26 && audioManager != null && finalFocusReq != null) {
                        try {
                            audioManager.abandonAudioFocusRequest(finalFocusReq);
                        } catch (Throwable ignored) {
                        }
                    }
                });
                activePlayer.prepare();
                activePlayer.start();
            } catch (Throwable ignored) {
            }
        });
    }

    private void notifyState(final String state, final String transcript, final String reply, final float level) {
        if (callback == null) return;
        mainHandler.post(() -> callback.onStateChanged(state, transcript, reply, level));
    }

    private void fireUiAction(final String actionType, final String target, final String param) {
        if (callback == null) return;
        mainHandler.post(() -> callback.onUiAction(actionType, target, param));
    }
}
