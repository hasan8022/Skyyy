package tr.halil.et5;

import android.telecom.Call;
import android.telecom.InCallService;

/**
 * Et5InCallService for hands-free Bluetooth HFP calls on the head unit.
 */
public final class Et5InCallService extends InCallService {

    public static volatile Call activeCall;

    @Override
    public void onCallAdded(Call call) {
        super.onCallAdded(call);
        activeCall = call;
    }

    @Override
    public void onCallRemoved(Call call) {
        if (activeCall == call) {
            activeCall = null;
        }
        super.onCallRemoved(call);
    }
}
