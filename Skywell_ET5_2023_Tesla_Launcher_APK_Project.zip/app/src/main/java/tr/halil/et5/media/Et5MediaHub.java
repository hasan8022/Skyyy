package tr.halil.et5.media;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import tr.halil.et5.MediaListener;
import tr.halil.et5.RadioService;

/**
 * Skywell ET5 (2023) GMS-Free Tümleşik Medya, YouTube, Spotify, İnternet Radyosu, USB, FM ve Bluetooth Merkezi.
 * Android 9 (API 28) ve Android 12 (API 31/32) tam uyumludur.
 */
public class Et5MediaHub {
    private static final String TAG = "Et5MediaHub";

    public static final String[] PIPED_INSTANCES = new String[]{
            "https://pipedapi.kavin.rocks",
            "https://pipedapi.tokhmi.xyz",
            "https://pipedapi.moomoo.me",
            "https://api.piped.private.coffee"
    };

    public static final String[] RADIO_BROWSER_MIRRORS = new String[]{
            "https://de1.api.radio-browser.info",
            "https://de2.api.radio-browser.info",
            "https://fi1.api.radio-browser.info",
            "https://all.api.radio-browser.info"
    };

    private final Context context;
    private final SharedPreferences prefs;
    private final AudioManager audioManager;
    private String activeSource = "INTERNET_RADIO";
    private String currentTitle = "TRT FM • Canlı Yayın";
    private String currentArtist = "Skywell ET5 Premium Ses Sistemi";
    private String currentStreamUrl = "https://trtcanlifm-lh.akamaihd.net/i/TRTFM_1@181846/master.m3u8";
    private boolean isPlaying = false;

    public Et5MediaHub(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences("et5_media_hub", Context.MODE_PRIVATE);
        this.audioManager = (AudioManager) this.context.getSystemService(Context.AUDIO_SERVICE);
        this.activeSource = prefs.getString("last_source", "INTERNET_RADIO");
    }

    public JSONArray getMediaSourcesJson() {
        JSONArray arr = new JSONArray();
        try {
            arr.put(makeSource("YOUTUBE", "YouTube (GMS-Free)", "video", true, "Gömülü + SmartTube / NewPipe"));
            arr.put(makeSource("SPOTIFY", "Spotify (GMS-Free)", "music", true, "Gömülü + Spotify Web/APK"));
            arr.put(makeSource("METROLIST", "YouTube Music (Metrolist)", "music", isPkgInstalled("com.metrolist.music") || isPkgInstalled("app.revanced.android.apps.youtube.music"), "com.metrolist.music"));
            arr.put(makeSource("INTERNET_RADIO", "İnternet Radyosu", "radio", true, "Canlı Türkiye & Dünya Radyoları"));
            arr.put(makeSource("FM_RADIO", "FM Radyo (OEM)", "radio", true, "com.skyworth.car.carradio"));
            arr.put(makeSource("BLUETOOTH", "Bluetooth Müzik", "bt", true, "AVRCP / A2DP Sink"));
            arr.put(makeSource("USB", "USB Bellek Müzik", "usb", true, "MP3 / FLAC / WAV Tarayıcı"));
            arr.put(makeSource("APPLE_MUSIC", "Apple Music", "music", isPkgInstalled("com.apple.android.music"), "com.apple.android.music"));
            arr.put(makeSource("DEEZER", "Deezer", "music", isPkgInstalled("deezer.android.app"), "deezer.android.app"));
            arr.put(makeSource("SOUNDCLOUD", "SoundCloud", "music", isPkgInstalled("com.soundcloud.android"), "com.soundcloud.android"));
        } catch (Exception ignored) {
        }
        return arr;
    }

    private JSONObject makeSource(String id, String name, String icon, boolean available, String desc) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("icon", icon);
        o.put("available", available);
        o.put("desc", desc);
        return o;
    }

    private boolean isPkgInstalled(String pkg) {
        try {
            context.getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String searchYouTubeGmsFree(String query, String filter) {
        JSONArray items = new JSONArray();
        if (query == null || query.trim().isEmpty()) {
            return getDefaultYouTubeCurated().toString();
        }
        String qEnc;
        try {
            qEnc = URLEncoder.encode(query.trim(), "UTF-8");
        } catch (Exception e) {
            qEnc = query.trim();
        }
        String fParam = (filter == null || filter.isEmpty()) ? "all" : filter;

        for (String base : PIPED_INSTANCES) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + "/search?q=" + qEnc + "&filter=" + fParam);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(7000);
                conn.setRequestProperty("User-Agent", "ET5-Arayuz/2.82 (Skywell ET5 GMS-Free)");
                if (conn.getResponseCode() == 200) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    JSONObject root = new JSONObject(sb.toString());
                    JSONArray rawItems = root.optJSONArray("items");
                    if (rawItems != null && rawItems.length() > 0) {
                        for (int i = 0; i < Math.min(rawItems.length(), 18); i++) {
                            JSONObject it = rawItems.getJSONObject(i);
                            String urlPath = it.optString("url", "");
                            if (!urlPath.contains("v=")) continue;
                            String videoId = urlPath.substring(urlPath.indexOf("v=") + 2);
                            if (videoId.contains("&")) videoId = videoId.substring(0, videoId.indexOf("&"));

                            JSONObject v = new JSONObject();
                            v.put("videoId", videoId);
                            v.put("title", it.optString("title", "Video"));
                            v.put("uploader", it.optString("uploaderName", "YouTube"));
                            v.put("duration", it.optInt("duration", 0));
                            v.put("thumbnail", "https://i.ytimg.com/vi/" + videoId + "/hqdefault.jpg");
                            v.put("embedUrl", "https://www.youtube-nocookie.com/embed/" + videoId + "?autoplay=1&rel=0&modestbranding=1&playsinline=1");
                            items.put(v);
                        }
                        if (items.length() > 0) {
                            return items.toString();
                        }
                    }
                }
            } catch (Throwable ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        return getDefaultYouTubeCurated().toString();
    }

    public JSONArray getDefaultYouTubeCurated() {
        JSONArray arr = new JSONArray();
        String[][] curated = new String[][]{
                {"jfKfPfyJRdk", "Lofi Hip Hop Radio - Beats to Relax/Drive to", "Lofi Girl • Canlı"},
                {"4xDzrJKXOOY", "Synthwave Night Drive Radio • Retro Electro", "Lofi Girl • Gece Sürüşü"},
                {"5qap5aO4i9A", "Chill Beats • Sürüş ve Dinlenme Müzikleri", "Chillhop Music"},
                {"DWcJFNfaw9c", "Ambient Space & Uzun Yol Sürüş Müzikleri", "Ambient Relaxation"},
                {"M5QY2_8704o", "Türkçe Pop & Akustik Sürüş Listesi", "Türkçe Müzik"},
                {"21qNxnCS8WU", "Deep House & Melodic Techno Car Mix", "Selected."}
        };
        for (String[] c : curated) {
            try {
                JSONObject v = new JSONObject();
                v.put("videoId", c[0]);
                v.put("title", c[1]);
                v.put("uploader", c[2]);
                v.put("duration", 0);
                v.put("thumbnail", "https://i.ytimg.com/vi/" + c[0] + "/hqdefault.jpg");
                v.put("embedUrl", "https://www.youtube-nocookie.com/embed/" + c[0] + "?autoplay=1&rel=0&modestbranding=1&playsinline=1");
                arr.put(v);
            } catch (Exception ignored) {
            }
        }
        return arr;
    }

    public String getSpotifyPlaylistsAndCurated() {
        JSONArray arr = new JSONArray();
        String[][] items = new String[][]{
                {"playlist", "37i9dQZF1DWY4lFlS4Pnso", "Türkçe Pop Hitleri", "Spotify Türkiye • Güncel"},
                {"playlist", "37i9dQZF1DX4Wsb4d7NKfP", "Türkçe Rock Klasikleri", "Spotify Türkiye • Rock"},
                {"playlist", "37i9dQZF1DX0XUsuxWHRQd", "RapCaviar & Sürüş Hitleri", "Spotify • Popüler Liste"},
                {"playlist", "37i9dQZF1DXcBWIGoYBM5M", "Today's Top Hits", "Spotify • Global Hit"},
                {"playlist", "37i9dQZF1DX10zKzsJ2jva", "Viva Latino & Enerjik Sürüş", "Spotify • Enerjik"},
                {"playlist", "37i9dQZF1DX6VdMW310YC7", "Chill Tracks & Gece Sürüşü", "Spotify • Chill"},
                {"playlist", "37i9dQZF1DWWQRwui0ExPn", "Lofi Beats", "Spotify • Odak & Sürüş"},
                {"playlist", "37i9dQZF1DX8Uebhn9wzrS", "Chill Lofi Study & Drive", "Spotify"}
        };
        for (String[] it : items) {
            try {
                JSONObject o = new JSONObject();
                o.put("type", it[0]);
                o.put("id", it[1]);
                o.put("title", it[2]);
                o.put("subtitle", it[3]);
                o.put("embedUrl", "https://open.spotify.com/embed/" + it[0] + "/" + it[1] + "?utm_source=generator&theme=0");
                o.put("uri", "spotify:" + it[0] + ":" + it[1]);
                arr.put(o);
            } catch (Exception ignored) {
            }
        }
        return arr.toString();
    }

    public String searchSpotifyWebApi(String query) {
        String token = prefs.getString("spotify_access_token", "");
        if (token == null || token.isEmpty() || query == null || query.trim().isEmpty()) {
            return getSpotifyPlaylistsAndCurated();
        }
        HttpURLConnection conn = null;
        try {
            String urlStr = "https://api.spotify.com/v1/search?type=track,playlist&limit=12&q="
                    + URLEncoder.encode(query.trim(), "UTF-8");
            conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(7000);
            conn.setRequestProperty("Authorization", "Bearer " + token);
            conn.setRequestProperty("Accept-Language", "tr-TR");
            if (conn.getResponseCode() == 200) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                JSONObject resp = new JSONObject(sb.toString());
                JSONArray out = new JSONArray();
                JSONObject tracksObj = resp.optJSONObject("tracks");
                if (tracksObj != null) {
                    JSONArray items = tracksObj.optJSONArray("items");
                    if (items != null) {
                        for (int i = 0; i < items.length(); i++) {
                            JSONObject t = items.getJSONObject(i);
                            String id = t.optString("id");
                            String name = t.optString("name");
                            String artist = "";
                            JSONArray artists = t.optJSONArray("artists");
                            if (artists != null && artists.length() > 0) {
                                artist = artists.getJSONObject(0).optString("name", "");
                            }
                            JSONObject o = new JSONObject();
                            o.put("type", "track");
                            o.put("id", id);
                            o.put("title", name);
                            o.put("subtitle", artist);
                            o.put("embedUrl", "https://open.spotify.com/embed/track/" + id + "?utm_source=generator&theme=0");
                            o.put("uri", "spotify:track:" + id);
                            out.put(o);
                        }
                    }
                }
                if (out.length() > 0) return out.toString();
            }
        } catch (Throwable ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return getSpotifyPlaylistsAndCurated();
    }

    public void saveSpotifyToken(String accessToken) {
        prefs.edit().putString("spotify_access_token", accessToken != null ? accessToken.trim() : "").apply();
    }

    public String getPresetRadioStationsJson() {
        JSONArray arr = new JSONArray();
        String[][] presets = new String[][]{
                {"TRT FM", "91.4 MHz • Ulusal Pop & Haber", "https://trtcanlifm-lh.akamaihd.net/i/TRTFM_1@181846/master.m3u8", "pop"},
                {"TRT Radyo 1", "93.3 MHz • Haber & Kültür", "https://trtcanlifm-lh.akamaihd.net/i/TRTRADYO1_1@181845/master.m3u8", "haber"},
                {"TRT Türkü", "98.6 MHz • Halk Müziği", "https://trtcanlifm-lh.akamaihd.net/i/TRTTURKU_1@181849/master.m3u8", "turku"},
                {"TRT Nağme", "101.6 MHz • Türk Sanat Müziği", "https://trtcanlifm-lh.akamaihd.net/i/TRTNAGME_1@181848/master.m3u8", "klasik"},
                {"PowerTürk FM", "99.8 MHz • Türkçe Pop", "https://live.powerapp.com.tr/powerturk/mpeg/icecast.audio", "pop"},
                {"Power FM", "100.0 MHz • Yabancı Hit", "https://live.powerapp.com.tr/powerfm/mpeg/icecast.audio", "pop"},
                {"Kral Pop Radyo", "94.7 MHz • Türkçe Pop", "https://dygedge.radyotvonline.net/kralpop/playlist.m3u8", "pop"},
                {"Kral FM", "92.0 MHz • Arabesk & Fantezi", "https://dygedge.radyotvonline.net/kralfm/playlist.m3u8", "arabesk"},
                {"Süper FM", "90.8 MHz • Türkçe Hit", "https://playerservices.streamtheworld.com/api/livestream-redirect/SUPER_FM.mp3", "pop"},
                {"Metro FM", "97.2 MHz • Yabancı Hit", "https://playerservices.streamtheworld.com/api/livestream-redirect/METRO_FM.mp3", "pop"},
                {"JoyTürk", "89.0 MHz • Türkçe Akustik & Slow", "https://playerservices.streamtheworld.com/api/livestream-redirect/JOY_TURK.mp3", "pop"},
                {"Radyo Fenomen", "100.4 MHz • Hit Müzik", "https://live.radyofenomen.com/fenomen/128/icecast.audio", "pop"},
                {"Alem FM", "89.2 MHz • Türkçe Karma", "https://turkmedya.radyotvonline.net/alemfmaac", "pop"},
                {"Best FM", "98.4 MHz • Ulusal Yayın", "https://bestfm.radyotvonline.net/bestfmaac", "pop"},
                {"NTV Radyo", "102.8 MHz • Canlı Haber", "https://dygedge.radyotvonline.net/ntvradyo/playlist.m3u8", "haber"},
                {"Power Smooth Jazz", "Dijital • Caz & Lounge", "https://live.powerapp.com.tr/powersmoothjazz/mpeg/icecast.audio", "jazz"}
        };
        for (String[] p : presets) {
            try {
                JSONObject o = new JSONObject();
                o.put("name", p[0]);
                o.put("subtitle", p[1]);
                o.put("url", p[2]);
                o.put("genre", p[3]);
                arr.put(o);
            } catch (Exception ignored) {
            }
        }
        return arr.toString();
    }

    public String searchInternetRadio(String query, String tag, String countryCode) {
        String path;
        try {
            if (query != null && !query.trim().isEmpty()) {
                path = "/json/stations/byname/" + URLEncoder.encode(query.trim(), "UTF-8") + "?hidebroken=true&order=clickcount&reverse=true&limit=25";
            } else if (tag != null && !tag.trim().isEmpty()) {
                path = "/json/stations/bytag/" + URLEncoder.encode(tag.trim(), "UTF-8") + "?hidebroken=true&order=clickcount&reverse=true&limit=25";
            } else {
                String cc = (countryCode == null || countryCode.isEmpty()) ? "TR" : countryCode.toUpperCase();
                path = "/json/stations/bycountrycodeexact/" + cc + "?hidebroken=true&order=clickcount&reverse=true&limit=25";
            }
        } catch (Exception e) {
            return getPresetRadioStationsJson();
        }

        for (String mirror : RADIO_BROWSER_MIRRORS) {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(mirror + path).openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(6000);
                conn.setRequestProperty("User-Agent", "ET5-Arayuz/2.82 (arac ici radyo)");
                if (conn.getResponseCode() == 200) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder sb = new StringBuilder();
                    String l;
                    while ((l = br.readLine()) != null) sb.append(l);
                    JSONArray raw = new JSONArray(sb.toString());
                    JSONArray out = new JSONArray();
                    for (int i = 0; i < raw.length(); i++) {
                        JSONObject item = raw.getJSONObject(i);
                        String streamUrl = item.optString("url_resolved", item.optString("url", ""));
                        if (streamUrl.isEmpty()) continue;
                        JSONObject o = new JSONObject();
                        o.put("name", item.optString("name", "Radyo").trim());
                        o.put("subtitle", item.optString("country", "TR") + " • " + item.optInt("bitrate", 128) + " kbps");
                        o.put("url", streamUrl);
                        o.put("genre", item.optString("tags", "pop"));
                        out.put(o);
                    }
                    if (out.length() > 0) return out.toString();
                }
            } catch (Throwable ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        return getPresetRadioStationsJson();
    }

    public void playInternetRadioStream(String name, String subtitle, String streamUrl) {
        if (streamUrl == null || streamUrl.isEmpty()) return;
        this.activeSource = "INTERNET_RADIO";
        this.currentTitle = name != null ? name : "İnternet Radyosu";
        this.currentArtist = subtitle != null ? subtitle : "Canlı Yayın";
        this.currentStreamUrl = streamUrl;
        this.isPlaying = true;
        prefs.edit().putString("last_source", "INTERNET_RADIO").putString("last_stream", streamUrl).apply();

        Intent i = new Intent(context, RadioService.class);
        i.setAction("PLAY_STREAM");
        i.putExtra("url", streamUrl);
        i.putExtra("title", this.currentTitle);
        context.startService(i);
    }

    public void stopInternetRadioStream() {
        this.isPlaying = false;
        Intent i = new Intent(context, RadioService.class);
        i.setAction("STOP_STREAM");
        context.startService(i);
    }

    public String scanUsbAudioFilesJson() {
        JSONArray arr = new JSONArray();
        ContentResolver cr = context.getContentResolver();
        String[] projection = new String[]{
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DISPLAY_NAME
        };

        List<Uri> volumeUris = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                Set<String> vols = MediaStore.getExternalVolumeNames(context);
                for (String v : vols) {
                    if (!"external_primary".equals(v)) {
                        volumeUris.add(MediaStore.Audio.Media.getContentUri(v));
                    }
                }
            } catch (Throwable ignored) {
            }
        }
        volumeUris.add(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI);

        for (Uri uri : volumeUris) {
            try (Cursor c = cr.query(uri, projection, "duration > 10000", null, MediaStore.Audio.Media.TITLE + " ASC")) {
                if (c == null) continue;
                while (c.moveToNext() && arr.length() < 150) {
                    long id = c.getLong(0);
                    String title = c.getString(1);
                    String artist = c.getString(2);
                    String album = c.getString(3);
                    long dur = c.getLong(4);
                    String disp = c.getString(5);
                    if (title == null || title.trim().isEmpty()) {
                        title = disp != null ? disp : "Parça #" + id;
                    }
                    Uri trackUri = ContentUris.withAppendedId(uri, id);
                    JSONObject o = new JSONObject();
                    o.put("id", id);
                    o.put("title", title);
                    o.put("artist", (artist == null || "<unknown>".equals(artist)) ? "USB Müzik" : artist);
                    o.put("album", album != null ? album : "");
                    o.put("durationSec", dur / 1000);
                    o.put("uri", trackUri.toString());
                    arr.put(o);
                }
            } catch (Throwable ignored) {
            }
        }
        return arr.toString();
    }

    public JSONObject getActiveMediaInfo() {
        JSONObject res = new JSONObject();
        try {
            res.put("source", activeSource);
            res.put("title", currentTitle);
            res.put("artist", currentArtist);
            res.put("playing", isPlaying);

            MediaSessionManager msm = (MediaSessionManager) context.getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (msm != null) {
                List<MediaController> controllers;
                try {
                    controllers = msm.getActiveSessions(new ComponentName(context, MediaListener.class));
                } catch (SecurityException se) {
                    controllers = msm.getActiveSessions(null);
                }
                if (controllers != null && !controllers.isEmpty()) {
                    for (MediaController mc : controllers) {
                        MediaMetadata meta = mc.getMetadata();
                        PlaybackState state = mc.getPlaybackState();
                        if (meta != null) {
                            String t = meta.getString(MediaMetadata.METADATA_KEY_TITLE);
                            if (t == null) t = meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE);
                            String a = meta.getString(MediaMetadata.METADATA_KEY_ARTIST);
                            if (a == null) a = meta.getString(MediaMetadata.METADATA_KEY_ALBUM);
                            if (t != null && !t.isEmpty()) {
                                res.put("package", mc.getPackageName());
                                res.put("title", t);
                                res.put("artist", a != null ? a : mc.getPackageName());
                                res.put("playing", state != null && state.getState() == PlaybackState.STATE_PLAYING);
                                break;
                            }
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return res;
    }

    public boolean launchOrPlaySource(String sourceId, String searchQuery) {
        this.activeSource = sourceId;
        prefs.edit().putString("last_source", sourceId).apply();
        try {
            switch (sourceId) {
                case "FM_RADIO":
                    return launchPackages("com.skyworth.car.carradio", "com.skyworth.car.radio", "com.coocaa.radio");

                case "BLUETOOTH":
                    if (Build.VERSION.SDK_INT < 29) {
                        launchPackages("com.skyworth.car.carbtmusic", "com.skyworth.car.btmusic");
                    }
                    sendMediaButtonKey(KeyEvent.KEYCODE_MEDIA_PLAY);
                    return true;

                case "USB":
                    return launchPackages("com.skyworth.car.localmedia", "com.skyworth.car.music", "com.coocaa.local.media");

                case "SPOTIFY":
                    if (searchQuery != null && !searchQuery.isEmpty() && isPkgInstalled("com.spotify.music")) {
                        Intent sIntent = new Intent("android.media.action.MEDIA_PLAY_FROM_SEARCH");
                        sIntent.setPackage("com.spotify.music");
                        sIntent.putExtra("query", searchQuery);
                        sIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(sIntent);
                        return true;
                    }
                    return launchPackages("com.spotify.music", "com.spotify.lite");

                case "METROLIST":
                case "YOUTUBE_MUSIC":
                    if (searchQuery != null && !searchQuery.isEmpty() && isPkgInstalled("com.metrolist.music")) {
                        Intent mIntent = new Intent("android.media.action.MEDIA_PLAY_FROM_SEARCH");
                        mIntent.setPackage("com.metrolist.music");
                        mIntent.putExtra("query", searchQuery);
                        mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(mIntent);
                        return true;
                    }
                    return launchPackages("com.metrolist.music", "app.revanced.android.apps.youtube.music", "app.rvx.android.apps.youtube.music", "com.google.android.apps.youtube.music");

                case "YOUTUBE_APP":
                    return launchPackages("org.smarttube.stable", "com.liskovsoft.smarttubetv.beta", "org.schabi.newpipe", "app.revanced.android.youtube");

                case "APPLE_MUSIC":
                    return launchPackages("com.apple.android.music");

                case "DEEZER":
                    return launchPackages("deezer.android.app");

                case "SOUNDCLOUD":
                    return launchPackages("com.soundcloud.android");
            }
        } catch (Throwable t) {
            Log.w(TAG, "Kaynak acilamadi: " + t.getMessage());
        }
        return false;
    }

    private void sendMediaButtonKey(int keyCode) {
        if (audioManager == null) return;
        try {
            audioManager.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
            audioManager.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyCode));
        } catch (Throwable ignored) {
        }
    }

    private boolean launchPackages(String... pkgs) {
        for (String pkg : pkgs) {
            try {
                Intent i = context.getPackageManager().getLaunchIntentForPackage(pkg);
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(i);
                    return true;
                }
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    public void setVolume(int level0to30) {
        if (audioManager == null) return;
        try {
            int max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            int scaled = Math.max(0, Math.min(max, Math.round((level0to30 / 30.0f) * max)));
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, scaled, 0);
        } catch (Throwable ignored) {
        }
    }
}
