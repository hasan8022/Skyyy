package tr.halil.et5;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/**
 * PanelGuardService Accessibility Service.
 * Prevents unintended system status bar shade pull-downs when operating the Tesla UI top bar.
 */
public final class PanelGuardService extends AccessibilityService {

    public static volatile boolean guardEnabled = false;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!guardEnabled || event == null) return;
        CharSequence pkg = event.getPackageName();
        if (pkg != null && "com.android.systemui".equals(pkg.toString())) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE);
        }
    }

    @Override
    public void onInterrupt() {}
}
