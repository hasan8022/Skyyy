package tr.halil.et5;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

public class RadioService extends Service {
    private static final String CHANNEL_ID = "et5_radio_channel";
    private MediaPlayer mediaPlayer;
    private String currentTitle = "Skywell ET5 Media & Radyo Aktif";

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundNotification(currentTitle);
    }

    private void startForegroundNotification(String text) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "ET5 Radyo Servisi", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
            Notification notif = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Skywell ET5")
                    .setContentText(text)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .build();
            startForeground(1001, notif);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            if ("PLAY_STREAM".equals(action)) {
                String url = intent.getStringExtra("url");
                if (url == null || url.isEmpty()) url = intent.getStringExtra("stream_url");
                String title = intent.getStringExtra("title");
                if (title == null || title.isEmpty()) title = intent.getStringExtra("stream_title");
                if (title != null && !title.isEmpty()) {
                    currentTitle = "Canlı Radyo: " + title;
                    startForegroundNotification(currentTitle);
                }
                playStream(url);
            } else if ("STOP_STREAM".equals(action)) {
                stopStream();
                startForegroundNotification("Radyo Durduruldu");
            }
        }
        return START_STICKY;
    }

    private void playStream(String url) {
        if (url == null || url.isEmpty()) return;
        stopStream();
        try {
            mediaPlayer = new MediaPlayer();
            if (Build.VERSION.SDK_INT >= 21) {
                mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build());
            }
            mediaPlayer.setDataSource(url);
            mediaPlayer.setOnPreparedListener(MediaPlayer::start);
            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                stopStream();
                return true;
            });
            mediaPlayer.prepareAsync();
        } catch (Throwable ignored) {}
    }

    private void stopStream() {
        if (mediaPlayer != null) {
            try {
                mediaPlayer.stop();
            } catch (Throwable ignored) {}
            try {
                mediaPlayer.release();
            } catch (Throwable ignored) {}
            mediaPlayer = null;
        }
    }

    @Override
    public void onDestroy() {
        stopStream();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
