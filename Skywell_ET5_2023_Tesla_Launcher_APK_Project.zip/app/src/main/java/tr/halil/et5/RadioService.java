package tr.halil.et5;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/**
 * RadioService Foreground Playback Service.
 */
public final class RadioService extends Service {

    private static final String CHANNEL_ID = "et5_radio_channel";

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_ID, "SkyOS Radyo Servisi", NotificationManager.IMPORTANCE_LOW);
                nm.createNotificationChannel(ch);
                Notification notif = new Notification.Builder(this, CHANNEL_ID)
                        .setContentTitle("Skywell ET5 Radyo")
                        .setContentText("Radyo aktif")
                        .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                        .build();
                startForeground(1001, notif);
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
