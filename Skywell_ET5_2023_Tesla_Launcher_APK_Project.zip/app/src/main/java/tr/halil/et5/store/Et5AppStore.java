package tr.halil.et5.store;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import tr.halil.et5.helper.AdbRootBridge;

/**
 * Skywell ET5 (2023) GMS-Free Araç Uygulama Mağazası ve Sessiz APK Kurucu (M6.java, U6.java, T6.java).
 *
 * Google Play Servisleri (GMS) olmayan Android 9 (API 28) ve Android 12 (API 31/32) ünitelerde
 * çalışabilen popüler müzik, video, navigasyon ve şarj uygulamalarını listeler, indirir ve
 * yerel ADB / Root köprüsü üzerinden sessizce (pm install -r) veya paket kurucu ile kurar.
 */
public class Et5AppStore {
    private static final String TAG = "Et5Installer";

    public interface StoreCallback {
        void onProgress(String pkg, int percent, String statusText);
    }

    private final Context context;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private StoreCallback callback;

    // M6.java & U6.java: Orijinal Katalogdaki 11 GMS-Free Araç Uygulaması
    private static final String[][] CATALOG = new String[][]{
            {"com.spotify.music", "Spotify", "9.1.92.3058", "muzik", "24", "GMS gerektirmez • Orijinal Spotify Araç & Mobil", "https://skyos.my/indir/spotify-9-1-92-3058.apk"},
            {"com.metrolist.music", "Metrolist (YouTube Music)", "13.7.0", "muzik", "26", "GMS gerektirmez • Reklamsız YouTube Music İstemcisi", "https://github.com/mostafaalagamy/Metrolist/releases/latest/download/app-release.apk"},
            {"org.smarttube.stable", "SmartTube (YouTube TV)", "32.68", "video", "17", "GMS gerektirmez • 4K Reklamsız Araç Ekranı YouTube", "https://github.com/yuliskov/SmartTube/releases/latest/download/SmartTube_stable_arm64-v8a.apk"},
            {"org.schabi.newpipe", "NewPipe (YouTube)", "0.29.1", "video", "23", "GMS gerektirmez • Arka planda çalan hafif YouTube", "https://github.com/TeamNewPipe/NewPipe/releases/latest/download/NewPipe_v0.27.6.apk"},
            {"ru.yandex.yandexmaps", "Yandex Haritalar & Navigasyon", "28.6.5", "navigasyon", "26", "GMS gerektirmez • Canlı trafik, radar ve sesli rota", "https://skyos.my/indir/ru.yandex.yandexmaps-28-6-5-android60.apk"},
            {"com.esarj.mobile", "Eşarj", "3.14.1", "sarj", "26", "Türkiye Elektrikli Araç Hızlı Şarj İstasyon Ağı", "https://skyos.my/indir/esarj-mobile-3.15.0.xapk"},
            {"deezer.android.app", "Deezer", "8.0.48.1", "muzik", "23", "GMS gerektirmez • Hi-Fi Müzik ve Podcast", "https://skyos.my/indir/deezer.android.app-1-0-1-1-android60.apk"},
            {"com.apple.android.music", "Apple Music", "5.0.0", "muzik", "29", "GMS gerektirmez • Kayıpsız Ses (Android 10+)", "https://skyos.my/indir/apple-music.apk"},
            {"com.soundcloud.android", "SoundCloud", "2026.10.14", "muzik", "28", "DJ Setleri, Remix ve Bağımsız Müzik", "https://skyos.my/indir/com.soundcloud.android-2026-10-14-release-arm64-v8a-android90.xapk"},
            {"com.openai.chatgpt", "ChatGPT", "1.2026", "asistan", "28", "OpenAI Sesli ve Yazılı Yapay Zeka", "https://skyos.my/indir/chatgpt.apk"},
            {"ai.x.grok", "Grok AI", "1.0", "asistan", "28", "xAI Gerçek Zamanlı Asistan", "https://skyos.my/indir/grok.apk"}
    };

    public Et5AppStore(Context context) {
        this.context = context.getApplicationContext();
    }

    public void setCallback(StoreCallback cb) {
        this.callback = cb;
    }

    public String getCatalogJson() {
        JSONArray arr = new JSONArray();
        PackageManager pm = context.getPackageManager();
        for (String[] row : CATALOG) {
            try {
                String pkg = row[0];
                int minSdk = Integer.parseInt(row[4]);
                boolean installed = false;
                try {
                    pm.getPackageInfo(pkg, 0);
                    installed = true;
                } catch (Exception ignored) {
                }
                boolean sdkSupported = Build.VERSION.SDK_INT >= minSdk;

                JSONObject o = new JSONObject();
                o.put("pkg", pkg);
                o.put("name", row[1]);
                o.put("version", row[2]);
                o.put("category", row[3]);
                o.put("minSdk", minSdk);
                o.put("desc", row[5]);
                o.put("url", row[6]);
                o.put("installed", installed);
                o.put("supported", sdkSupported);
                arr.put(o);
            } catch (Exception ignored) {
            }
        }
        return arr.toString();
    }

    public void downloadAndInstallApp(final String pkg, final String downloadUrl) {
        new Thread(() -> {
            notifyProgress(pkg, 2, "İndiriliyor...");
            HttpURLConnection conn = null;
            try {
                File dir = new File(context.getExternalFilesDir(null), "et5-indirilenler");
                if (!dir.exists()) dir.mkdirs();
                File apkFile = new File(dir, pkg + ".apk");

                URL url = new URL(downloadUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(30000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("User-Agent", "ET5-Arayuz/2.82");

                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) {
                    notifyProgress(pkg, -1, "Sunucu yanıt vermedi (" + code + ")");
                    return;
                }

                long total = conn.getContentLengthLong();
                long downloaded = 0;
                try (InputStream is = conn.getInputStream();
                     FileOutputStream fos = new FileOutputStream(apkFile)) {
                    byte[] buf = new byte[16384];
                    int n;
                    int lastPct = 2;
                    while ((n = is.read(buf)) > 0) {
                        fos.write(buf, 0, n);
                        downloaded += n;
                        if (total > 0) {
                            int pct = (int) ((downloaded * 85L) / total);
                            if (pct >= lastPct + 5) {
                                lastPct = pct;
                                notifyProgress(pkg, pct, "İndiriliyor %" + pct);
                            }
                        }
                    }
                }
                apkFile.setReadable(true, false);
                notifyProgress(pkg, 90, "Kuruluyor (Sessiz Kurulum)...");

                // T6.java & U6.java: Yerel ADB/Root köprüsü üzerinden sessiz kurulum
                String tmpTarget = "/data/local/tmp/et5_install.apk";
                String out = AdbRootBridge.execSmartAdb(context, 120000,
                        "su 0 cp '" + apkFile.getAbsolutePath() + "' " + tmpTarget
                                + " && su 0 chmod 644 " + tmpTarget
                                + " && pm install -r " + tmpTarget
                                + " && su 0 rm -f " + tmpTarget);

                if (out != null && out.toLowerCase().contains("success")) {
                    notifyProgress(pkg, 100, "Kuruldu ✓");
                    return;
                }

                // Yedek: Standart Android Paket Kurucu ekranı
                notifyProgress(pkg, 95, "Ekran kurulum onayı açılıyor...");
                Intent installIntent = new Intent(Intent.ACTION_VIEW);
                installIntent.setDataAndType(Uri.fromFile(apkFile), "application/vnd.android.package-archive");
                installIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                context.startActivity(installIntent);
            } catch (Throwable t) {
                Log.w(TAG, "Kurulum hatasi: " + t.getMessage());
                notifyProgress(pkg, -1, "Hata: " + t.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
            }
        }, "Et5-AppInstaller").start();
    }

    private void notifyProgress(final String pkg, final int pct, final String text) {
        if (callback == null) return;
        mainHandler.post(() -> callback.onProgress(pkg, pct, text));
    }
}
