package tr.halil.et5.helper;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAKeyGenParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import tr.halil.et5.Et5App;
import tr.halil.et5.safety.HomeGate;

/**
 * Skywell ET5 (2023) Coocaa OS Geliştirici Şifre Üreticisi, ADB 127.0.0.1:5555 İstemcisi
 * (524-byte RSAPublicKey binary struct) ve AracYardimci (127.0.0.1:8724) Kurulum Köprüsü.
 * Birebir J1.java, C2807tR.java, EE.smali ve AbstractC2297oa.java mimarisiyle kodlanmıştır.
 */
public class AdbRootBridge {
    private static final String TAG = "Et5Bridge";
    public static final int ADB_PORT = 5555;
    public static final String LOCAL_AUTH_KEY = "et5";

    private static final int A_CNXN = 0x4e584e43; // 1314410051
    private static final int A_AUTH = 0x48545541; // 1213486401
    private static final int A_OPEN = 0x4e45504f; // 1313165391
    private static final int A_OKAY = 0x59414b4f; // 1497451343
    private static final int A_WRTE = 0x45545257; // 1163154007
    private static final int A_CLSE = 0x45534c43; // 1163086915

    private static final byte[] SHA1_DIGEST_INFO_PREFIX = new byte[]{
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e,
            0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    };

    private static final List<String> SU_PATHS = Arrays.asList(
            "su", "/system/bin/su", "/system/xbin/su", "/vendor/bin/su",
            "/sbin/su", "/debug_ramdisk/su", "/su/bin/su"
    );

    private static final List<String> STOCK_POPUP_COMPONENTS = Arrays.asList(
            "com.skyworth.car.BluetoothPhone",
            "com.skyworth.car.btpair",
            "com.skyworth.car.skycommunication/.services.PhoneService",
            "com.skyworth.car.systemsettings/.businiess.connection.bluetooth.pairrequest.BluetoothPairingRequest"
    );

    private static volatile Boolean sHasRootSu = null;
    private static volatile String sSuBinary = "su";
    private static volatile String sBridgeStatus = "Bağlantı bekleniyor... (127.0.0.1:5555)";
    private static volatile long sLastAuthPromptTimeMs = 0L;

    public interface SetupStepCallback {
        void onStepUpdate(int stepIndex, String title, String status, boolean done, boolean success);
        void onSetupFinished(boolean allSuccess, String summaryMessage);
    }

    public static String getBridgeStatus() {
        return sBridgeStatus;
    }

    /**
     * Coocaa OS Geliştirici Modu Şifre Hesaplayıcısı (AbstractC2297oa.c):
     * Ayarlar -> Sistem -> Coocaa OS logosuna 20 kez tıklayınca çıkan "Lütfen Parolanı Girin"
     * ekranının şifresini otomatik hesaplar:
     *   vinLast3 = persist.tbox.vin.name son 3 karakteri (BÜYÜK HARF)
     *   skylinkSeg3 = ro.build.skylinkversion ('_' öncesi, '.' ile ayrılmış 3. parça, indeks 2)
     *   parola = Base64.encodeToString((vinLast3 + skylinkSeg3).getBytes(UTF_8), NO_WRAP) ('=' silinir)
     */
    public static String computeCoocaaPassword(String manualVinOverride) {
        try {
            String vin = getSystemProperty("persist.tbox.vin.name", "").trim().toUpperCase(Locale.ROOT);
            if (manualVinOverride != null && manualVinOverride.trim().length() >= 3) {
                vin = manualVinOverride.trim().toUpperCase(Locale.ROOT);
            }
            String skylink = getSystemProperty("ro.build.skylinkversion", "").trim();
            if (vin.length() < 3 || skylink.isEmpty()) {
                return null;
            }
            String vinLast3 = vin.substring(vin.length() - 3);
            int underscoreIdx = skylink.indexOf('_');
            String cleanSkylink = underscoreIdx >= 0 ? skylink.substring(0, underscoreIdx) : skylink;
            String[] parts = cleanSkylink.split("\\.");
            if (parts.length < 3 || parts[2].isEmpty()) {
                return null;
            }
            String raw = vinLast3 + parts[2];
            String b64 = Base64.encodeToString(raw.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            while (b64.endsWith("=")) {
                b64 = b64.substring(0, b64.length() - 1);
            }
            return b64.isEmpty() ? null : b64;
        } catch (Throwable t) {
            return null;
        }
    }

    public static String getDetectedVin() {
        return getSystemProperty("persist.tbox.vin.name", "").trim().toUpperCase(Locale.ROOT);
    }

    public static String getDetectedSkylinkVersion() {
        return getSystemProperty("ro.build.skylinkversion", "").trim();
    }

    /**
     * Şifredeki birbiriyle karışabilecek karakterleri (0/O, 1/I/l) tek tek açıklar (AbstractC2297oa.t).
     */
    public static String formatPasswordPhoneticHint(String password) {
        if (password == null || password.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < password.length(); i++) {
            if (i > 0) sb.append(" · ");
            char c = password.charAt(i);
            if (c == '0') sb.append("0 (sıfır)");
            else if (c == 'O') sb.append("O (büyük o harfi)");
            else if (c == 'o') sb.append("o (küçük o harfi)");
            else if (c == 'I') sb.append("I (büyük ı harfi)");
            else if (c == 'l') sb.append("l (küçük L harfi)");
            else if (c == '1') sb.append("1 (bir)");
            else if (Character.isUpperCase(c)) sb.append(c).append(" (büyük ").append(Character.toLowerCase(c)).append(")");
            else if (Character.isLowerCase(c)) sb.append(c).append(" (küçük ").append(c).append(")");
            else sb.append(c);
        }
        return sb.toString();
    }

    public static String getSystemProperty(String key, String def) {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            Method get = sp.getMethod("get", String.class, String.class);
            String val = (String) get.invoke(null, key, def);
            return val != null ? val : def;
        } catch (Throwable t) {
            return def;
        }
    }

    public static boolean isSetupCompleted(Context context) {
        SharedPreferences sp = context.getSharedPreferences("lisans", Context.MODE_PRIVATE);
        return sp.getBoolean("kuruldu", false) || sp.getBoolean("kurulum_tamam", false);
    }

    public static void markSetupCompleted(Context context, boolean completed) {
        SharedPreferences sp = context.getSharedPreferences("lisans", Context.MODE_PRIVATE);
        sp.edit()
                .putBoolean("kuruldu", completed)
                .putBoolean("kurulum_tamam", completed)
                .apply();
    }

    /**
     * Checks if ADB on 127.0.0.1:5555 responds to `id` with `uid=2000` or `uid=0`.
     */
    public static boolean probeAdbConnection(Context context) {
        String idOut = execAdbShellRaw(context, 3000, "id");
        return idOut != null && (idOut.contains("uid=2000") || idOut.contains("uid=0"));
    }

    /**
     * Checks if AracYardimci on 127.0.0.1:8724 is alive and responds to VER.
     */
    public static boolean isHelperAlive() {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress("127.0.0.1", AracYardimci.PORT), 400);
            s.setSoTimeout(800);
            PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            out.println("VER");
            String line = in.readLine();
            return line != null && line.startsWith("VER");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Runs the complete 5-step SkyOS provisioning flow over ADB 127.0.0.1:5555 (pn0.smali / EE.smali).
     */
    public static boolean runFullSetup(Context context, SetupStepCallback callback) {
        String pkg = context.getPackageName();

        // Step 1: ADB Anahtarı & Kalıcı Port (adb_keys + persist.adb.tcp.port 5555)
        if (callback != null) {
            callback.onStepUpdate(0, "1. Kalıcı ADB Anahtarı & Port 5555", "Yazılıyor...", false, false);
        }
        boolean step1Ok = false;
        try {
            detectSuOverAdb(context);
            KeyPair kp = getOrCreateRsaKeyPair(context);
            String pubKeyLine = encodeAdbPublicKeyString((RSAPublicKey) kp.getPublic());
            String keyCmd = "su 0 sh -c 'd=/data/misc/adb; f=$d/adb_keys; mkdir -p $d; touch $f; "
                    + "grep -qF \"" + pubKeyLine + "\" $f || echo \"" + pubKeyLine + "\" >> $f; "
                    + "chown system:shell $f $d; chmod 640 $f; chmod 2750 $d; restorecon $f $d 2>/dev/null; "
                    + "setprop persist.adb.tcp.port 5555; echo tamam'";
            String out1 = execSmartAdb(context, 6000, keyCmd);
            step1Ok = out1 != null && out1.contains("tamam");
        } catch (Throwable ignored) {
        }
        if (callback != null) {
            callback.onStepUpdate(0, "1. Kalıcı ADB Anahtarı & Port 5555",
                    step1Ok ? "✓ Kalıcı anahtar kaydedildi" : "! Geçici ADB oturumu aktif", true, true);
        }

        // Step 2: İzinler, Üstte Gösterim, Bildirim Dinleyici ve Telefon (DIALER) Rolü
        if (callback != null) {
            callback.onStepUpdate(1, "2. Sistem İzinleri & Telefon Rolü", "Yetkiler tanımlanıyor...", false, false);
        }
        String grantCmd = "pm grant " + pkg + " android.permission.WRITE_SECURE_SETTINGS 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.WRITE_SETTINGS 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.ACCESS_FINE_LOCATION 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.ACCESS_COARSE_LOCATION 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.RECORD_AUDIO 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.CAMERA 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.READ_CONTACTS 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.READ_CALL_LOG 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.CALL_PHONE 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.ANSWER_PHONE_CALLS 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.READ_PHONE_STATE 2>/dev/null; "
                + "pm grant " + pkg + " android.permission.READ_EXTERNAL_STORAGE 2>/dev/null; "
                + "pm grant " + pkg + " com.skyworth.car.permission.PROJECT_MENU 2>/dev/null; "
                + "appops set " + pkg + " SYSTEM_ALERT_WINDOW allow 2>/dev/null; "
                + "cmd notification allow_listener " + pkg + "/tr.halil.et5.MediaListener 2>/dev/null; "
                + "cmd role add-role-holder android.app.role.DIALER " + pkg + " 0 2>/dev/null; "
                + "settings put secure enabled_accessibility_services " + pkg + "/tr.halil.et5.PanelGuardService 2>/dev/null; "
                + "settings put secure accessibility_enabled 1 2>/dev/null; echo IZIN_TAMAM";
        if (Build.VERSION.SDK_INT >= 31) {
            grantCmd = "pm grant " + pkg + " android.permission.BLUETOOTH_CONNECT 2>/dev/null; "
                    + "pm grant " + pkg + " android.permission.BLUETOOTH_SCAN 2>/dev/null; "
                    + "pm grant " + pkg + " android.permission.BLUETOOTH_ADVERTISE 2>/dev/null; " + grantCmd;
        }
        String out2 = execSmartAdb(context, 10000, grantCmd);
        boolean step2Ok = out2 != null && out2.contains("IZIN_TAMAM");
        if (callback != null) {
            callback.onStepUpdate(1, "2. Sistem İzinleri & Telefon Rolü",
                    step2Ok ? "✓ Tüm izinler verildi" : "! Kısmi izin verildi", true, step2Ok);
        }

        // Step 3: AracYardimci (UID 1000 Sistem Servisi - 127.0.0.1:8724) Kurulumu ve Başlatılması
        if (callback != null) {
            callback.onStepUpdate(2, "3. Araç CAN-Bus Köprüsü (127.0.0.1:8724)", "AracYardimci başlatılıyor...", false, false);
        }
        boolean step3Ok = startHelperDaemonOverAdb(context);
        if (callback != null) {
            callback.onStepUpdate(2, "3. Araç CAN-Bus Köprüsü (127.0.0.1:8724)",
                    step3Ok ? "✓ AracYardimci aktif (127.0.0.1:8724)" : "! Yardımcı başlatılamadı", true, step3Ok);
        }

        // Step 4: Varsayılan Ana Ekran (HomeGate) & Stok Pencere Kapatma
        if (callback != null) {
            callback.onStepUpdate(3, "4. Varsayılan Ana Ekran & Stok Koruması", "Ayarlanıyor...", false, false);
        }
        try {
            context.getPackageManager().setComponentEnabledSetting(
                    new ComponentName(context, HomeGate.class),
                    android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    android.content.pm.PackageManager.DONT_KILL_APP
            );
        } catch (Throwable ignored) {
        }
        String homeCmd = "pm disable-user --user 0 com.skyworth.car.BluetoothPhone 2>/dev/null; "
                + "pm disable-user --user 0 com.skyworth.car.btpair 2>/dev/null; "
                + "am force-stop com.coolwell.ai.skysplash 2>/dev/null; "
                + "am stopservice com.skyworth.car.launcher/.media.MediaExposeService 2>/dev/null; "
                + "cmd role add-role-holder android.app.role.HOME " + pkg + " 0 2>/dev/null; "
                + "cmd package set-home-activity " + pkg + "/tr.halil.et5.safety.HomeGate 2>/dev/null; echo HOME_TAMAM";
        String out4 = execSmartAdb(context, 8000, homeCmd);
        boolean step4Ok = out4 != null && out4.contains("HOME_TAMAM");
        if (callback != null) {
            callback.onStepUpdate(3, "4. Varsayılan Ana Ekran & Stok Koruması",
                    step4Ok ? "✓ Varsayılan başlatıcı yapıldı" : "! Manuel ana ekran seçimi gerekebilir", true, true);
        }

        // Step 5: Güvenlik Duvarı (Dış Ağdan Port 5555 Kapatma)
        if (callback != null) {
            callback.onStepUpdate(4, "5. Güvenlik Duvarı (Port 5555 Koruması)", "Dış erişim kapatılıyor...", false, false);
        }
        execSmartAdb(context, 5000, "su 0 sh -c 'iptables -C INPUT -p tcp --dport 5555 ! -i lo -j DROP 2>/dev/null || iptables -I INPUT -p tcp --dport 5555 ! -i lo -j DROP' 2>/dev/null");
        if (callback != null) {
            callback.onStepUpdate(4, "5. Güvenlik Duvarı (Port 5555 Koruması)", "✓ Sadece araç içi erişime izin verildi", true, true);
        }

        boolean overallOk = step3Ok || step2Ok;
        if (overallOk) {
            markSetupCompleted(context, true);
        }
        if (callback != null) {
            callback.onSetupFinished(overallOk, overallOk
                    ? "Kurulum başarıyla tamamlandı! Araç CAN-Bus verileri aktif."
                    : "ADB bağlantısı kuruldu ancak yardımcı servis yanıt vermedi.");
        }
        return overallOk;
    }

    public static boolean ensureHelperStarted(Context context) {
        try {
            if (isHelperAlive()) {
                sBridgeStatus = "AracYardimci aktif (127.0.0.1:8724)";
                return true;
            }
            if (startHelperDaemonOverAdb(context)) {
                sBridgeStatus = "AracYardimci başlatıldı (127.0.0.1:8724)";
                return true;
            }
            return false;
        } catch (Throwable t) {
            Log.w(TAG, "ensureHelperStarted hata: " + t.getMessage());
            return false;
        }
    }

    private static boolean startHelperDaemonOverAdb(Context context) {
        if (isHelperAlive()) return true;

        String apkPath = context.getApplicationInfo().sourceDir;
        if (tryStartViaDirectSu(apkPath)) {
            if (waitForHelper(10)) return true;
        }

        detectSuOverAdb(context);
        File extDir = context.getExternalFilesDir(null);
        if (extDir == null) extDir = context.getCacheDir();
        File localJar = new File(extDir, "arac_helper.jar");
        copyFile(new File(apkPath), localJar);
        localJar.setReadable(true, false);

        String targetJar = "/data/local/tmp/arac.jar";
        // Copy APK as jar to /data/local/tmp/arac.jar where uid=1000 can read it
        execSmartAdb(context, 6000, "cp '" + apkPath + "' " + targetJar + " 2>/dev/null || cp '" + localJar.getAbsolutePath() + "' " + targetJar + " 2>/dev/null; chmod 644 " + targetJar);
        execSmartAdb(context, 6000, "su 0 sh -c 'cp \"" + apkPath + "\" " + targetJar + " && chmod 644 " + targetJar + "' 2>/dev/null");

        // Kill any stale instance first
        execSmartAdb(context, 4000, "su 0 pkill -f AracYardimci 2>/dev/null; pkill -f AracYardimci 2>/dev/null");

        // Launch as uid 1000 (system) so it has full access to android.car.Car and ContentProviders
        String cmdUid1000 = "setsid su 1000 sh -c 'CLASSPATH=" + targetJar + " app_process /system/bin tr.halil.et5.helper.AracYardimci serve 8724 " + LOCAL_AUTH_KEY + " >/data/local/tmp/yardimci.log 2>&1 < /dev/null &'";
        execSmartAdb(context, 6000, cmdUid1000);
        if (waitForHelper(10)) return true;

        // Fallback 1: su 0 (root)
        String cmdUid0 = "setsid su 0 sh -c 'CLASSPATH=" + targetJar + " app_process /system/bin tr.halil.et5.helper.AracYardimci serve 8724 " + LOCAL_AUTH_KEY + " >/data/local/tmp/yardimci.log 2>&1 < /dev/null &'";
        execSmartAdb(context, 6000, cmdUid0);
        if (waitForHelper(10)) return true;

        // Fallback 2: shell uid 2000 directly
        String cmdShell = "CLASSPATH=" + targetJar + " nohup app_process /system/bin tr.halil.et5.helper.AracYardimci serve 8724 " + LOCAL_AUTH_KEY + " >/data/local/tmp/yardimci.log 2>&1 < /dev/null &";
        execAdbShellRaw(context, 6000, cmdShell);
        return waitForHelper(10);
    }

    public static void bootstrapHelperAsync(final Context context) {
        new Thread(() -> ensureHelperStarted(context), "Et5-AdbBootstrap").start();
    }

    public static void stopSkyworthEvsService(final Context context) {
        try {
            Intent stopEvs = new Intent("com.skyworth.car.evs.STOP_EVS");
            stopEvs.setPackage("com.skyworth.car.evs");
            context.sendBroadcast(stopEvs);
        } catch (Throwable ignored) {
        }
        new Thread(() -> execSmartAdb(context, 3000,
                "am stopservice com.skyworth.car.evs/.EvsStrategyService; am force-stop com.skyworth.car.evs"), "Et5-StopEvs").start();
    }

    public static void preventStockLauncherMediaKeys(final Context context) {
        new Thread(() -> execSmartAdb(context, 3000,
                "am stopservice com.skyworth.car.launcher/.media.MediaExposeService"), "Et5-MediaKeyGuard").start();
    }

    public static String execRootOrAdb(int timeoutMs, String command) {
        Et5App app = Et5App.getInstance();
        if (app != null) {
            return execSmartAdb(app, timeoutMs, command);
        }
        return null;
    }

    public static void restoreStockLauncher(Context context) {
        String pkg = context.getPackageName();
        markSetupCompleted(context, false);
        new Thread(() -> {
            try {
                context.getPackageManager().setComponentEnabledSetting(
                        new ComponentName(context, HomeGate.class),
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                );
            } catch (Throwable ignored) {
            }
            execSmartAdb(context, 6000, "su 0 pm enable com.skyworth.car.launcher/com.skyworth.car.launcher.LauncherActivity 2>/dev/null");
            execSmartAdb(context, 6000, "cmd role add-role-holder android.app.role.HOME com.skyworth.car.launcher 0 2>/dev/null; "
                    + "cmd package set-home-activity com.skyworth.car.launcher/com.skyworth.car.launcher.LauncherActivity 2>/dev/null; "
                    + "cmd role remove-role-holder android.app.role.DIALER " + pkg + " 0 2>/dev/null");
            for (String comp : STOCK_POPUP_COMPONENTS) {
                execSmartAdb(context, 4000, "pm enable " + comp + " 2>/dev/null");
            }
            try {
                Intent home = new Intent(Intent.ACTION_MAIN);
                home.addCategory(Intent.CATEGORY_HOME);
                home.setPackage("com.skyworth.car.launcher");
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(home);
            } catch (Throwable ignored) {
            }
        }, "Et5-RestoreStock").start();
    }

    private static boolean waitForHelper(int maxAttempts) {
        for (int i = 0; i < maxAttempts; i++) {
            if (isHelperAlive()) return true;
            try {
                Thread.sleep(300);
            } catch (InterruptedException ignored) {
            }
        }
        return isHelperAlive();
    }

    private static boolean tryStartViaDirectSu(String apkPath) {
        for (String suPath : SU_PATHS) {
            try {
                Process p = Runtime.getRuntime().exec(suPath);
                DataOutputStream os = new DataOutputStream(p.getOutputStream());
                os.writeBytes("cp '" + apkPath + "' /data/local/tmp/arac.jar\n");
                os.writeBytes("chmod 644 /data/local/tmp/arac.jar\n");
                os.writeBytes("CLASSPATH=/data/local/tmp/arac.jar setsid app_process /system/bin tr.halil.et5.helper.AracYardimci serve 8724 " + LOCAL_AUTH_KEY + " >/data/local/tmp/yardimci.log 2>&1 &\n");
                os.writeBytes("exit\n");
                os.flush();
                p.waitFor();
                if (isHelperAlive()) {
                    sHasRootSu = Boolean.TRUE;
                    sSuBinary = suPath;
                    return true;
                }
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    private static void detectSuOverAdb(Context context) {
        if (sHasRootSu != null) return;
        for (String candidate : SU_PATHS) {
            String out = execAdbShellRaw(context, 3500, candidate + " 0 id");
            if (out == null) break;
            if (out.contains("uid=0")) {
                sSuBinary = candidate;
                sHasRootSu = Boolean.TRUE;
                Log.i(TAG, "Root su bulundu: " + candidate);
                return;
            }
        }
        sHasRootSu = Boolean.FALSE;
    }

    public static String execSmartAdb(Context context, int timeoutMs, String command) {
        if (command.contains("su ")) {
            detectSuOverAdb(context);
        }
        String processed = command;
        if (Boolean.FALSE.equals(sHasRootSu)) {
            processed = processed.replaceAll("\\bsu (0|1000) ", "");
        } else if (sSuBinary != null && !"su".equals(sSuBinary)) {
            processed = processed.replaceAll("\\bsu (0|1000) ", sSuBinary + " $1 ");
        }
        return execAdbShellRaw(context, timeoutMs, processed);
    }

    /**
     * Executes an ADB shell command on 127.0.0.1:5555 using the exact J1.v() 524-byte RSAPublicKey
     * binary struct and C2807tR.a() 20-second RSA popup cooldown.
     */
    public static String execAdbShellRaw(Context context, int timeoutMs, String shellCommand) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress("127.0.0.1", ADB_PORT), 2000);
            socket.setSoTimeout(timeoutMs);

            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            byte[] banner = "host::et5\0".getBytes(StandardCharsets.UTF_8);
            sendPacket(out, A_CNXN, 0x01000000, 262144, banner);

            AdbMessage msg = readPacket(in);
            if (msg == null) {
                sBridgeStatus = "Port açık, yanıt yok";
                return null;
            }

            if (msg.command == A_AUTH) {
                KeyPair kp = getOrCreateRsaKeyPair(context);
                byte[] signedToken = signAdbToken(kp.getPrivate(), msg.payload);
                sendPacket(out, A_AUTH, 2, 0, signedToken);
                msg = readPacket(in);

                if (msg != null && msg.command == A_AUTH) {
                    long now = System.currentTimeMillis();
                    if (now - sLastAuthPromptTimeMs < 20000L) {
                        sBridgeStatus = "Araç ekranında ADB izni bekleniyor (\"Her zaman izin ver\" kutusunu işaretleyip Tamam'a basın)";
                        return null;
                    }
                    sLastAuthPromptTimeMs = now;
                    sBridgeStatus = "Araç ekranında ADB izni bekleniyor (\"Her zaman izin ver\" kutusunu işaretleyip Tamam'a basın)";
                    byte[] pubKey524 = encodeAdbPublicKey524((RSAPublicKey) kp.getPublic());
                    sendPacket(out, A_AUTH, 3, 0, pubKey524);
                    socket.setSoTimeout(Math.max(timeoutMs, 30000));
                    msg = readPacket(in);
                    socket.setSoTimeout(timeoutMs);
                }
            }

            if (msg == null || msg.command != A_CNXN) {
                sBridgeStatus = "ADB kimlik doğrulaması bekleniyor";
                return null;
            }

            sBridgeStatus = "ADB Köprüsü Bağlı (127.0.0.1:5555)";
            byte[] openPayload = ("shell:" + shellCommand + "\0").getBytes(StandardCharsets.UTF_8);
            sendPacket(out, A_OPEN, 1, 0, openPayload);

            StringBuilder output = new StringBuilder();
            while (true) {
                AdbMessage m = readPacket(in);
                if (m == null) break;
                if (m.command == A_WRTE) {
                    if (m.payload != null && m.payload.length > 0) {
                        output.append(new String(m.payload, StandardCharsets.UTF_8));
                    }
                    sendPacket(out, A_OKAY, 1, m.arg0, new byte[0]);
                } else if (m.command == A_CLSE) {
                    sendPacket(out, A_CLSE, 1, m.arg0, new byte[0]);
                    break;
                } else if (m.command != A_OKAY) {
                    break;
                }
            }
            return output.toString();
        } catch (ConnectException ce) {
            sBridgeStatus = "ADB portu kapalı (127.0.0.1:5555) — Geliştirme Modu'ndan 'Aç adb' seçin";
            return null;
        } catch (SocketTimeoutException ste) {
            sBridgeStatus = "Zaman aşımı — Araç ekranındaki ADB onay penceresini kontrol edin";
            return null;
        } catch (Throwable t) {
            sBridgeStatus = "ADB bağlantı durumu: " + t.getMessage();
            return null;
        }
    }

    /**
     * Exact 524-byte Android adbd RSAPublicKey binary struct encoder (from J1.v()):
     *   uint32_t len = 64 (2048-bit words)
     *   uint32_t n0inv = -1 / n[0] mod 2^32
     *   uint8_t  n[256] (little-endian modulus bytes)
     *   uint8_t  rr[256] (little-endian 2^4096 mod n bytes)
     *   uint32_t exponent = 65537
     * Base64-encoded (NO_WRAP) + " SkyOS@arac\0"
     */
    private static String encodeAdbPublicKeyString(RSAPublicKey rsaPub) {
        BigInteger modulus = rsaPub.getModulus();
        BigInteger two32 = BigInteger.ONE.shiftLeft(32);
        int n0inv = two32.subtract(modulus.mod(two32).modInverse(two32)).intValue();
        BigInteger rr = BigInteger.ONE.shiftLeft(4096).mod(modulus);

        ByteBuffer buf = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN);
        buf.putInt(64);
        buf.putInt(n0inv);

        byte[] modBytes = modulus.toByteArray();
        byte[] modLe = new byte[256];
        int modLen = Math.min(256, modBytes.length);
        for (int i = 0; i < modLen; i++) {
            modLe[i] = modBytes[modBytes.length - 1 - i];
        }
        buf.put(modLe);

        byte[] rrBytes = rr.toByteArray();
        byte[] rrLe = new byte[256];
        int rrLen = Math.min(256, rrBytes.length);
        for (int i = 0; i < rrLen; i++) {
            rrLe[i] = rrBytes[rrBytes.length - 1 - i];
        }
        buf.put(rrLe);

        buf.putInt(rsaPub.getPublicExponent().intValue());
        String b64 = Base64.encodeToString(buf.array(), Base64.NO_WRAP);
        return b64 + " SkyOS@arac";
    }

    private static byte[] encodeAdbPublicKey524(RSAPublicKey rsaPub) {
        return (encodeAdbPublicKeyString(rsaPub) + "\0").getBytes(StandardCharsets.UTF_8);
    }

    private static byte[] signAdbToken(PrivateKey privateKey, byte[] token) throws Exception {
        byte[] data = new byte[SHA1_DIGEST_INFO_PREFIX.length + token.length];
        System.arraycopy(SHA1_DIGEST_INFO_PREFIX, 0, data, 0, SHA1_DIGEST_INFO_PREFIX.length);
        System.arraycopy(token, 0, data, SHA1_DIGEST_INFO_PREFIX.length, token.length);
        Signature sig = Signature.getInstance("NONEwithRSA");
        sig.initSign(privateKey);
        sig.update(data);
        return sig.sign();
    }

    private static synchronized KeyPair getOrCreateRsaKeyPair(Context ctx) throws Exception {
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            KeyStore.Entry entry = ks.getEntry("skyos-kopru", null);
            if (entry instanceof KeyStore.PrivateKeyEntry) {
                KeyStore.PrivateKeyEntry pke = (KeyStore.PrivateKeyEntry) entry;
                return new KeyPair(pke.getCertificate().getPublicKey(), pke.getPrivateKey());
            }
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore");
            kpg.initialize(new KeyGenParameterSpec.Builder("skyos-kopru", KeyProperties.PURPOSE_SIGN)
                    .setAlgorithmParameterSpec(new RSAKeyGenParameterSpec(2048, RSAKeyGenParameterSpec.F4))
                    .setDigests(KeyProperties.DIGEST_NONE)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                    .build());
            return kpg.generateKeyPair();
        } catch (Throwable keystoreErr) {
            SharedPreferences sp = ctx.getSharedPreferences("et5_adb_keys", Context.MODE_PRIVATE);
            String privB64 = sp.getString("priv", null);
            String pubB64 = sp.getString("pub", null);
            if (privB64 != null && pubB64 != null) {
                KeyFactory kf = KeyFactory.getInstance("RSA");
                PrivateKey priv = kf.generatePrivate(new PKCS8EncodedKeySpec(Base64.decode(privB64, Base64.DEFAULT)));
                PublicKey pub = kf.generatePublic(new X509EncodedKeySpec(Base64.decode(pubB64, Base64.DEFAULT)));
                return new KeyPair(pub, priv);
            }
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(2048);
            KeyPair kp = kpg.generateKeyPair();
            sp.edit()
                    .putString("priv", Base64.encodeToString(kp.getPrivate().getEncoded(), Base64.DEFAULT))
                    .putString("pub", Base64.encodeToString(kp.getPublic().getEncoded(), Base64.DEFAULT))
                    .apply();
            return kp;
        }
    }

    private static void copyFile(File src, File dst) {
        try (FileInputStream fis = new FileInputStream(src);
             FileOutputStream fos = new FileOutputStream(dst)) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = fis.read(buf)) > 0) {
                fos.write(buf, 0, n);
            }
        } catch (Exception ignored) {
        }
    }

    private static void sendPacket(DataOutputStream out, int cmd, int arg0, int arg1, byte[] payload) throws Exception {
        ByteBuffer buf = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        buf.putInt(cmd);
        buf.putInt(arg0);
        buf.putInt(arg1);
        buf.putInt(payload.length);
        int sum = 0;
        for (byte b : payload) sum += (b & 0xFF);
        buf.putInt(sum);
        buf.putInt(~cmd);
        out.write(buf.array());
        if (payload.length > 0) out.write(payload);
        out.flush();
    }

    private static AdbMessage readPacket(DataInputStream in) {
        try {
            byte[] hdr = new byte[24];
            in.readFully(hdr);
            ByteBuffer buf = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN);
            AdbMessage m = new AdbMessage();
            m.command = buf.getInt();
            m.arg0 = buf.getInt();
            m.arg1 = buf.getInt();
            int len = buf.getInt();
            buf.getInt();
            buf.getInt();
            if (len > 0 && len < 262145) {
                m.payload = new byte[len];
                in.readFully(m.payload);
            } else {
                m.payload = new byte[0];
            }
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    private static class AdbMessage {
        int command;
        int arg0;
        int arg1;
        byte[] payload;
    }
}
