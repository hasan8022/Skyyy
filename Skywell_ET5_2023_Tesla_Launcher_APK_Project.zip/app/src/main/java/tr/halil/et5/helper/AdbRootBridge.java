package tr.halil.et5.helper;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Base64;
import android.util.Log;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.List;

import tr.halil.et5.Et5App;
import tr.halil.et5.safety.HomeGate;

/**
 * Skywell ET5 (2023) Yerel ADB (127.0.0.1:5555) ve Sistem Yetkilendirme Köprüsü.
 * Android 9 (API 28) ve Android 12 (API 31/32) tam uyumludur.
 */
public class AdbRootBridge {
    private static final String TAG = "Et5Bridge";
    private static final int ADB_PORT = 5555;
    public static final String LOCAL_AUTH_KEY = "et5";

    private static final int A_CNXN = 0x4e584e43;
    private static final int A_AUTH = 0x48545541;
    private static final int A_OPEN = 0x4e45504f;
    private static final int A_OKAY = 0x59414b4f;
    private static final int A_WRTE = 0x45545257;
    private static final int A_CLSE = 0x45534c43;

    private static final byte[] SHA1_DIGEST_INFO_PREFIX = new byte[]{
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e,
            0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    };

    private static final List<String> SU_PATHS = Arrays.asList(
            "su", "/system/bin/su", "/system/xbin/su", "/vendor/bin/su",
            "/sbin/su", "/debug_ramdisk/su", "/su/bin/su"
    );

    private static final List<String> STOCK_POPUP_COMPONENTS = Arrays.asList(
            "com.skyworth.car.skycommunication/.services.PhoneService",
            "com.skyworth.car.systemsettings/.businiess.connection.bluetooth.pairrequest.BluetoothPairingRequest",
            "com.android.car.settings/.bluetooth.BluetoothPairingRequest",
            "com.coolwell.ai.skysplash"
    );

    private static volatile Boolean sHasRootSu = null;
    private static volatile String sSuBinary = "su";
    private static volatile String sBridgeStatus = "denenmedi";

    public static String getBridgeStatus() {
        return sBridgeStatus;
    }

    public static boolean ensureHelperStarted(Context context) {
        try {
            if (isHelperAlive()) {
                sBridgeStatus = "Yardımcı aktif (127.0.0.1:8724)";
                return true;
            }
            String apkPath = context.getApplicationInfo().sourceDir;
            String pkg = context.getPackageName();

            if (tryStartViaDirectSu(apkPath, pkg)) {
                if (waitForHelper(12)) {
                    sBridgeStatus = "Doğrudan Root ile başlatıldı";
                    applySystemSetup(context);
                    return true;
                }
            }

            detectSuOverAdb(context);
            File externalDir = context.getExternalFilesDir(null);
            if (externalDir == null) externalDir = context.getCacheDir();
            File localDexCopy = new File(externalDir, "arac_helper.jar");
            copyFile(new File(apkPath), localDexCopy);
            localDexCopy.setReadable(true, false);

            String targetJar = "/data/local/tmp/arac.jar";
            execSmartAdb(context, 6000, "su 0 cp '" + localDexCopy.getAbsolutePath() + "' " + targetJar + " && su 0 chmod 644 " + targetJar);

            String launchCmd = "setsid su 1000 app_process -cp " + targetJar + " /system/bin tr.halil.et5.helper.AracYardimci serve 8724 " + LOCAL_AUTH_KEY + " > /data/local/tmp/yardimci.log 2>&1 < /dev/null & sleep 1";
            execSmartAdb(context, 8000, launchCmd);

            if (!waitForHelper(12)) {
                String fallbackCmd = "setsid app_process -cp " + targetJar + " /system/bin tr.halil.et5.helper.AracYardimci serve 8724 " + LOCAL_AUTH_KEY + " > /data/local/tmp/yardimci.log 2>&1 < /dev/null & sleep 1";
                execAdbShellRaw(context, 8000, fallbackCmd);
                waitForHelper(10);
            }

            applySystemSetup(context);
            return isHelperAlive();
        } catch (Throwable t) {
            Log.w(TAG, "ensureHelperStarted uyarisi: " + t.getMessage());
            return false;
        }
    }

    public static void bootstrapHelperAsync(final Context context) {
        new Thread(() -> ensureHelperStarted(context), "Et5-AdbBootstrap").start();
    }

    /**
     * OC.java: Aracın kendi EVS kamera servisini (com.skyworth.car.evs) durdurur ki Camera2 ID "0" meşgul kalmasın.
     */
    public static void stopSkyworthEvsService(final Context context) {
        try {
            Intent stopEvs = new Intent("com.skyworth.car.evs.STOP_EVS");
            stopEvs.setPackage("com.skyworth.car.evs");
            context.sendBroadcast(stopEvs);
        } catch (Throwable ignored) {
        }
        new Thread(() -> execSmartAdb(context, 3000,
                "am stopservice com.skyworth.car.evs/.EvsStrategyService; am force-stop com.skyworth.car.evs"), "Et5-StopEvs").start();
    }

    /**
     * JS.java: Orijinal başlatıcının (com.skyworth.car.launcher.media.MediaExposeService) direksiyon medya tuşlarını çalmasını engeller.
     */
    public static void preventStockLauncherMediaKeys(final Context context) {
        new Thread(() -> execSmartAdb(context, 3000,
                "am stopservice com.skyworth.car.launcher/.media.MediaExposeService"), "Et5-MediaKeyGuard").start();
    }

    public static String execRootOrAdb(int timeoutMs, String command) {
        Et5App app = Et5App.getInstance();
        if (app != null) {
            return execSmartAdb(app, timeoutMs, command);
        }
        return null;
    }

    public static void applySystemSetup(Context context) {
        String pkg = context.getPackageName();
        String grantCmd = "pm grant " + pkg + " android.permission.WRITE_SECURE_SETTINGS; "
                + "pm grant " + pkg + " android.permission.WRITE_SETTINGS; "
                + "pm grant " + pkg + " android.permission.READ_PHONE_STATE; "
                + "pm grant " + pkg + " android.permission.CALL_PHONE; "
                + "pm grant " + pkg + " android.permission.READ_CONTACTS; "
                + "pm grant " + pkg + " android.permission.READ_CALL_LOG; "
                + "pm grant " + pkg + " android.permission.RECORD_AUDIO; "
                + "pm grant " + pkg + " android.permission.CAMERA; "
                + "pm grant " + pkg + " android.permission.ACCESS_FINE_LOCATION; "
                + "pm grant " + pkg + " android.permission.ACCESS_COARSE_LOCATION; "
                + "pm grant " + pkg + " com.skyworth.car.permission.PROJECT_MENU; "
                + "settings put secure enabled_accessibility_services " + pkg + "/tr.halil.et5.PanelGuardService; "
                + "settings put secure accessibility_enabled 1;";
        if (Build.VERSION.SDK_INT >= 31) {
            grantCmd += "pm grant " + pkg + " android.permission.BLUETOOTH_CONNECT; "
                    + "pm grant " + pkg + " android.permission.BLUETOOTH_SCAN; "
                    + "pm grant " + pkg + " android.permission.BLUETOOTH_ADVERTISE; ";
        }
        execSmartAdb(context, 8000, grantCmd);

        try {
            KeyPair kp = getOrCreateRsaKeyPair(context);
            String pubKeyLine = new String(encodeAdbPublicKey((RSAPublicKey) kp.getPublic()), StandardCharsets.UTF_8).replace("\0", "").trim();
            execSmartAdb(context, 6000, "su 0 sh -c 'd=/data/misc/adb; f=$d/adb_keys; mkdir -p $d; touch $f; grep -qF \"" + pubKeyLine + "\" $f || echo \"" + pubKeyLine + "\" >> $f; chown system:shell $f $d; chmod 640 $f; chmod 2750 $d; restorecon $f $d 2>/dev/null; echo tamam'");
        } catch (Throwable ignored) {
        }

        try {
            context.getPackageManager().setComponentEnabledSetting(
                    new ComponentName(context, HomeGate.class),
                    android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DEFAULT,
                    android.content.pm.PackageManager.DONT_KILL_APP
            );
        } catch (Throwable ignored) {
        }

        if (Build.VERSION.SDK_INT >= 29) {
            execSmartAdb(context, 6000, "cmd role add-role-holder android.app.role.DIALER " + pkg + " 0");
            execSmartAdb(context, 6000, "cmd role add-role-holder android.app.role.HOME " + pkg + " 0");
        } else {
            execSmartAdb(context, 6000, "su 0 setprop persist.adb.tcp.port 5555");
            execSmartAdb(context, 6000, "su 0 cmd package set-home-activity " + pkg + "/.safety.HomeGate");
        }
    }

    public static void restoreStockLauncher(Context context) {
        String pkg = context.getPackageName();
        new Thread(() -> {
            execSmartAdb(context, 6000, "su 0 pm enable com.skyworth.car.launcher/com.skyworth.car.launcher.LauncherActivity");
            if (Build.VERSION.SDK_INT >= 29) {
                execSmartAdb(context, 6000, "cmd role add-role-holder android.app.role.HOME com.skyworth.car.launcher 0");
                execSmartAdb(context, 6000, "cmd role remove-role-holder android.app.role.DIALER " + pkg + " 0");
            } else {
                execSmartAdb(context, 6000, "su 0 cmd package set-home-activity com.skyworth.car.launcher/com.skyworth.car.launcher.LauncherActivity");
            }
            for (String comp : STOCK_POPUP_COMPONENTS) {
                execSmartAdb(context, 4000, "su 0 pm enable " + comp);
            }
        }, "Et5-RestoreStock").start();
    }

    private static boolean waitForHelper(int maxAttempts) {
        for (int i = 0; i < maxAttempts; i++) {
            try {
                Thread.sleep(250);
            } catch (InterruptedException ignored) {
            }
            if (isHelperAlive()) return true;
        }
        return false;
    }

    public static boolean isHelperAlive() {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress("127.0.0.1", AracYardimci.PORT), 350);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean tryStartViaDirectSu(String apkPath, String pkg) {
        for (String suPath : SU_PATHS) {
            try {
                Process p = Runtime.getRuntime().exec(suPath);
                DataOutputStream os = new DataOutputStream(p.getOutputStream());
                os.writeBytes("cp '" + apkPath + "' /data/local/tmp/arac.jar\n");
                os.writeBytes("chmod 644 /data/local/tmp/arac.jar\n");
                os.writeBytes("setsid app_process -cp /data/local/tmp/arac.jar /system/bin tr.halil.et5.helper.AracYardimci serve 8724 " + LOCAL_AUTH_KEY + " >/data/local/tmp/yardimci.log 2>&1 &\n");
                os.writeBytes("exit\n");
                os.flush();
                p.waitFor();
                if (isHelperAlive()) {
                    sHasRootSu = Boolean.TRUE;
                    sSuBinary = suPath;
                    return true;
                }
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    private static void detectSuOverAdb(Context context) {
        if (sHasRootSu != null) return;
        for (String candidate : SU_PATHS) {
            String out = execAdbShellRaw(context, 3500, candidate + " 0 id");
            if (out == null) break;
            if (out.contains("uid=0")) {
                sSuBinary = candidate;
                sHasRootSu = Boolean.TRUE;
                Log.i(TAG, "Root su bulundu: " + candidate);
                return;
            }
        }
        sHasRootSu = Boolean.FALSE;
    }

    public static String execSmartAdb(Context context, int timeoutMs, String command) {
        detectSuOverAdb(context);
        String processed = command;
        if (Boolean.FALSE.equals(sHasRootSu)) {
            processed = processed.replaceAll("\\bsu (0|1000) ", "");
        } else if (sSuBinary != null && !"su".equals(sSuBinary)) {
            processed = processed.replaceAll("\\bsu (0|1000) ", sSuBinary + " $1 ");
        }
        return execAdbShellRaw(context, timeoutMs, processed);
    }

    public static String execAdbShellRaw(Context context, int timeoutMs, String shellCommand) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress("127.0.0.1", ADB_PORT), 2000);
            socket.setSoTimeout(timeoutMs);

            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            byte[] banner = "host::et5\0".getBytes(StandardCharsets.UTF_8);
            sendPacket(out, A_CNXN, 0x01000000, 262144, banner);

            AdbMessage msg = readPacket(in);
            if (msg == null) {
                sBridgeStatus = "ADB port açık, yanıt yok";
                return null;
            }

            if (msg.command == A_AUTH) {
                KeyPair kp = getOrCreateRsaKeyPair(context);
                byte[] signedToken = signAdbToken(kp.getPrivate(), msg.payload);
                sendPacket(out, A_AUTH, 2, 0, signedToken);
                msg = readPacket(in);

                if (msg != null && msg.command == A_AUTH) {
                    sBridgeStatus = "Araç ekranında ADB izni bekleniyor ('Her zaman izin ver')";
                    byte[] pubKey = encodeAdbPublicKey((RSAPublicKey) kp.getPublic());
                    sendPacket(out, A_AUTH, 3, 0, pubKey);
                    socket.setSoTimeout(Math.max(timeoutMs, 30000));
                    msg = readPacket(in);
                    socket.setSoTimeout(timeoutMs);
                }
            }

            if (msg == null || msg.command != A_CNXN) {
                sBridgeStatus = "ADB kimlik doğrulaması reddedildi";
                return null;
            }

            sBridgeStatus = "ADB Köprüsü Bağlı (127.0.0.1:5555)";
            byte[] openPayload = ("shell:" + shellCommand + "\0").getBytes(StandardCharsets.UTF_8);
            sendPacket(out, A_OPEN, 1, 0, openPayload);

            StringBuilder output = new StringBuilder();
            while (true) {
                AdbMessage m = readPacket(in);
                if (m == null) break;
                if (m.command == A_WRTE) {
                    if (m.payload != null && m.payload.length > 0) {
                        output.append(new String(m.payload, StandardCharsets.UTF_8));
                    }
                    sendPacket(out, A_OKAY, 1, m.arg0, new byte[0]);
                } else if (m.command == A_CLSE) {
                    sendPacket(out, A_CLSE, 1, m.arg0, new byte[0]);
                    break;
                } else if (m.command != A_OKAY) {
                    break;
                }
            }
            return output.toString();
        } catch (Throwable t) {
            sBridgeStatus = "ADB kapalı veya erişilemiyor: " + t.getMessage();
            return null;
        }
    }

    private static void copyFile(File src, File dst) {
        try (FileInputStream fis = new FileInputStream(src);
             FileOutputStream fos = new FileOutputStream(dst)) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = fis.read(buf)) > 0) {
                fos.write(buf, 0, n);
            }
        } catch (Exception ignored) {
        }
    }

    private static void sendPacket(DataOutputStream out, int cmd, int arg0, int arg1, byte[] payload) throws Exception {
        ByteBuffer buf = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        buf.putInt(cmd);
        buf.putInt(arg0);
        buf.putInt(arg1);
        buf.putInt(payload.length);
        int sum = 0;
        for (byte b : payload) sum += (b & 0xFF);
        buf.putInt(sum);
        buf.putInt(~cmd);
        out.write(buf.array());
        if (payload.length > 0) out.write(payload);
        out.flush();
    }

    private static AdbMessage readPacket(DataInputStream in) {
        try {
            byte[] hdr = new byte[24];
            in.readFully(hdr);
            ByteBuffer buf = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN);
            AdbMessage m = new AdbMessage();
            m.command = buf.getInt();
            m.arg0 = buf.getInt();
            m.arg1 = buf.getInt();
            int len = buf.getInt();
            buf.getInt();
            buf.getInt();
            if (len > 0 && len < 262145) {
                m.payload = new byte[len];
                in.readFully(m.payload);
            } else {
                m.payload = new byte[0];
            }
            return m;
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] signAdbToken(PrivateKey privateKey, byte[] token) throws Exception {
        byte[] data = new byte[SHA1_DIGEST_INFO_PREFIX.length + token.length];
        System.arraycopy(SHA1_DIGEST_INFO_PREFIX, 0, data, 0, SHA1_DIGEST_INFO_PREFIX.length);
        System.arraycopy(token, 0, data, SHA1_DIGEST_INFO_PREFIX.length, token.length);
        Signature sig = Signature.getInstance("NONEwithRSA");
        sig.initSign(privateKey);
        sig.update(data);
        return sig.sign();
    }

    private static byte[] encodeAdbPublicKey(RSAPublicKey pubKey) {
        String b64 = Base64.encodeToString(pubKey.getEncoded(), Base64.NO_WRAP);
        return (b64 + " et5@skywell\0").getBytes(StandardCharsets.UTF_8);
    }

    private static KeyPair getOrCreateRsaKeyPair(Context ctx) throws Exception {
        SharedPreferences sp = ctx.getSharedPreferences("et5_adb_keys", Context.MODE_PRIVATE);
        String privB64 = sp.getString("priv", null);
        String pubB64 = sp.getString("pub", null);
        if (privB64 != null && pubB64 != null) {
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PrivateKey priv = kf.generatePrivate(new PKCS8EncodedKeySpec(Base64.decode(privB64, Base64.DEFAULT)));
            PublicKey pub = kf.generatePublic(new X509EncodedKeySpec(Base64.decode(pubB64, Base64.DEFAULT)));
            return new KeyPair(pub, priv);
        }
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        KeyPair kp = kpg.generateKeyPair();
        sp.edit()
                .putString("priv", Base64.encodeToString(kp.getPrivate().getEncoded(), Base64.DEFAULT))
                .putString("pub", Base64.encodeToString(kp.getPublic().getEncoded(), Base64.DEFAULT))
                .apply();
        return kp;
    }

    private static class AdbMessage {
        int command;
        int arg0;
        int arg1;
        byte[] payload;
    }
}
