package tr.halil.et5.smart;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import tr.halil.et5.car.VehicleController;
import tr.halil.et5.car.VehicleState;

/**
 * Skywell ET5 (2023) Akıllı Modlar, Sürücü Profilleri, Enerji/Tasarruf Hesaplayıcı,
 * EV Şarj Rota Planlayıcı, Canlı Hava Durumu, Bakım Hatırlatıcı ve Akıllı Ev Yöneticisi.
 */
public class Et5SmartFeatures {
    private static final String TAG = "Et5Smart";

    private final Context context;
    private final VehicleController vehicleController;
    private final SharedPreferences profilePrefs;
    private final SharedPreferences energyPrefs;
    private final SharedPreferences modePrefs;
    private final SharedPreferences valetPrefs;
    private final SharedPreferences maintPrefs;
    private final SharedPreferences smartHomePrefs;

    public Et5SmartFeatures(Context context, VehicleController vehicleController) {
        this.context = context.getApplicationContext();
        this.vehicleController = vehicleController;
        this.profilePrefs = this.context.getSharedPreferences("profiller", Context.MODE_PRIVATE);
        this.energyPrefs = this.context.getSharedPreferences("enerji", Context.MODE_PRIVATE);
        this.modePrefs = this.context.getSharedPreferences("ekran_modlari", Context.MODE_PRIVATE);
        this.valetPrefs = this.context.getSharedPreferences("vale", Context.MODE_PRIVATE);
        this.maintPrefs = this.context.getSharedPreferences("bakim_hatirlatici", Context.MODE_PRIVATE);
        this.smartHomePrefs = this.context.getSharedPreferences("akilli_ev", Context.MODE_PRIVATE);
        ensureDefaultProfiles();
    }

    private void ensureDefaultProfiles() {
        if (!profilePrefs.contains("active_profile")) {
            try {
                JSONArray list = new JSONArray();
                list.put(makeProfile("Halil", "#3E8EF7", 21.5f, 0, 50, "#e9eaec", "İnci Beyazı"));
                list.put(makeProfile("Aile / Eş", "#10B981", 23.0f, 1, 75, "#a7abb1", "Ay Gümüşü"));
                list.put(makeProfile("Spor / Uzun Yol", "#F59E0B", 21.0f, 2, 30, "#1f4170", "Okyanus Mavisi"));
                profilePrefs.edit()
                        .putString("active_profile", "Halil")
                        .putString("liste", list.toString())
                        .putString("car_color_hex", "#e9eaec")
                        .putString("car_color_name", "İnci Beyazı")
                        .apply();
            } catch (Exception ignored) {
            }
        }
    }

    private JSONObject makeProfile(String name, String badgeColor, float hvacTemp, int driveMode, int regenLevel, String carColorHex, String carColorName) throws Exception {
        JSONObject o = new JSONObject();
        o.put("name", name);
        o.put("badgeColor", badgeColor);
        o.put("hvacTemp", hvacTemp);
        o.put("driveMode", driveMode);
        o.put("regenLevel", regenLevel);
        o.put("carColorHex", carColorHex);
        o.put("carColorName", carColorName);
        return o;
    }

    public String getProfilesJson() {
        JSONObject root = new JSONObject();
        try {
            root.put("active", profilePrefs.getString("active_profile", "Halil"));
            root.put("carColorHex", profilePrefs.getString("car_color_hex", "#e9eaec"));
            root.put("carColorName", profilePrefs.getString("car_color_name", "İnci Beyazı"));
            root.put("renderMode", profilePrefs.getString("render_mode", "3D"));
            root.put("profiles", new JSONArray(profilePrefs.getString("liste", "[]")));
        } catch (Exception ignored) {
        }
        return root.toString();
    }

    public void selectDriverProfile(String name) {
        try {
            JSONArray arr = new JSONArray(profilePrefs.getString("liste", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject p = arr.getJSONObject(i);
                if (name.equalsIgnoreCase(p.optString("name"))) {
                    profilePrefs.edit()
                            .putString("active_profile", p.optString("name"))
                            .putString("car_color_hex", p.optString("carColorHex", "#e9eaec"))
                            .putString("car_color_name", p.optString("carColorName", "İnci Beyazı"))
                            .apply();
                    vehicleController.setHvacTemperature((float) p.optDouble("hvacTemp", 21.5));
                    vehicleController.setVehicleSetting("surus_modu", p.optInt("driveMode", 0));
                    vehicleController.setVehicleSetting("geri_kazanim", p.optInt("regenLevel", 50));
                    break;
                }
            }
        } catch (Exception ignored) {
        }
    }

    public void setCarBodyColor(String hex, String colorName) {
        profilePrefs.edit()
                .putString("car_color_hex", hex)
                .putString("car_color_name", colorName)
                .apply();
    }

    public String getEnergyAndSavingsJson() {
        VehicleState st = vehicleController.getState();
        JSONObject o = new JSONObject();
        try {
            float tripKm = energyPrefs.getFloat("trip_a_km", 342.6f);
            float tripKwh = energyPrefs.getFloat("trip_a_kwh", 56.8f);
            float sinceChargeKm = energyPrefs.getFloat("sarj_km", 128.4f);
            float sinceChargeKwh = energyPrefs.getFloat("sarj_kwh", 20.9f);
            float homePriceTl = energyPrefs.getFloat("ev_fiyat", 2.60f);
            float stationPriceTl = energyPrefs.getFloat("istasyon_fiyat", 7.90f);
            float petrolPriceTl = energyPrefs.getFloat("benzin_fiyat", 43.50f);
            float petrolLitresPer100 = energyPrefs.getFloat("benzin_tuketim", 8.2f);

            float avgConsumption = tripKm > 0.1f ? (tripKwh / tripKm) * 100.0f : 16.5f;
            float evCostTl = tripKwh * ((homePriceTl * 0.7f) + (stationPriceTl * 0.3f));
            float petrolCostTl = (tripKm / 100.0f) * petrolLitresPer100 * petrolPriceTl;
            float savedTl = Math.max(0.0f, petrolCostTl - evCostTl);
            float nominalPackKwh = 71.98f;
            float sohPct = st.obdSohPercent > 0 ? st.obdSohPercent : 98.8f;
            float measuredCapacityKwh = nominalPackKwh * (sohPct / 100.0f);

            o.put("tripKm", Math.round(tripKm * 10f) / 10f);
            o.put("tripKwh", Math.round(tripKwh * 10f) / 10f);
            o.put("sinceChargeKm", Math.round(sinceChargeKm * 10f) / 10f);
            o.put("sinceChargeKwh", Math.round(sinceChargeKwh * 10f) / 10f);
            o.put("avgKwhPer100Km", Math.round(avgConsumption * 10f) / 10f);
            o.put("homePriceTl", homePriceTl);
            o.put("stationPriceTl", stationPriceTl);
            o.put("petrolPriceTl", petrolPriceTl);
            o.put("evCostTl", Math.round(evCostTl));
            o.put("petrolCostTl", Math.round(petrolCostTl));
            o.put("savedTl", Math.round(savedTl));
            o.put("sohPct", sohPct);
            o.put("measuredKwh", Math.round(measuredCapacityKwh * 10f) / 10f);
            o.put("nominalKwh", nominalPackKwh);
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    public void updateEnergyPrices(float homeTl, float stationTl, float petrolTl) {
        energyPrefs.edit()
                .putFloat("ev_fiyat", homeTl)
                .putFloat("istasyon_fiyat", stationTl)
                .putFloat("benzin_fiyat", petrolTl)
                .apply();
    }

    public void resetTripCounter() {
        energyPrefs.edit()
                .putFloat("trip_a_km", 0.0f)
                .putFloat("trip_a_kwh", 0.0f)
                .apply();
    }

    public String getSmartModesJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("activeMode", modePrefs.getString("active_mode", "NONE"));
            o.put("parkingNote", modePrefs.getString("not", "Birazdan döneceğim.\nTelefon: 05__ ___ __ __"));
            o.put("campMinSoc", modePrefs.getInt("kamp_alt_sinir", 20));
            o.put("campTempC", modePrefs.getInt("kamp_sicaklik", 22));
            o.put("petTempC", modePrefs.getInt("evcil_sicaklik", 21));
            o.put("valetActive", valetPrefs.getBoolean("on", false));
            o.put("valetSpeedLimit", valetPrefs.getInt("limit", 90));
            o.put("valetMaxKmh", valetPrefs.getInt("max", 0));
            o.put("valetOverCount", valetPrefs.getInt("overN", 0));
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    public void saveParkingNote(String noteText) {
        modePrefs.edit().putString("not", noteText != null ? noteText : "").apply();
    }

    public boolean activateSmartMode(String mode, String pinOrParam) {
        VehicleState st = vehicleController.getState();
        switch (mode.toUpperCase(Locale.ROOT)) {
            case "CAMP":
                if (!"P".equals(st.gear)) return false;
                modePrefs.edit().putString("active_mode", "CAMP").apply();
                vehicleController.setHvacPower(true);
                vehicleController.setHvacTemperature(modePrefs.getInt("kamp_sicaklik", 22));
                return true;

            case "PET":
                if (!"P".equals(st.gear)) return false;
                modePrefs.edit().putString("active_mode", "PET").apply();
                vehicleController.setHvacPower(true);
                vehicleController.setHvacAc(true);
                vehicleController.setHvacTemperature(modePrefs.getInt("evcil_sicaklik", 21));
                return true;

            case "WASH":
                modePrefs.edit().putString("active_mode", "WASH").apply();
                vehicleController.controlAllWindows(1);
                vehicleController.setSunroof(false);
                vehicleController.foldMirrors(true);
                return true;

            case "VALET_ON":
                String pinHash = sha256(pinOrParam != null ? pinOrParam : "1234");
                valetPrefs.edit()
                        .putBoolean("on", true)
                        .putString("pin", pinHash)
                        .putInt("max", 0)
                        .putInt("overN", 0)
                        .apply();
                modePrefs.edit().putString("active_mode", "VALET").apply();
                return true;

            case "VALET_OFF":
                String savedPin = valetPrefs.getString("pin", sha256("1234"));
                if (savedPin.equals(sha256(pinOrParam != null ? pinOrParam : ""))) {
                    valetPrefs.edit().putBoolean("on", false).apply();
                    modePrefs.edit().putString("active_mode", "NONE").apply();
                    return true;
                }
                return false;

            case "NONE":
            default:
                modePrefs.edit().putString("active_mode", "NONE").apply();
                return true;
        }
    }

    private String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] dig = md.digest(("et5:" + s).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : dig) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return s;
        }
    }

    public String fetchLiveWeatherJson(double lat, double lon) {
        HttpURLConnection conn = null;
        try {
            String urlStr = String.format(Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.2f&longitude=%.2f&current=temperature_2m,weather_code,wind_speed_10m",
                    lat, lon);
            conn = (HttpURLConnection) new URL(urlStr).openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(6000);
            if (conn.getResponseCode() == 200) {
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String l;
                while ((l = br.readLine()) != null) sb.append(l);
                JSONObject current = new JSONObject(sb.toString()).getJSONObject("current");
                float tempC = (float) current.getDouble("temperature_2m");
                int code = current.optInt("weather_code", 0);
                float wind = (float) current.optDouble("wind_speed_10m", 0.0);
                vehicleController.getState().outsideTempC = tempC;

                JSONObject out = new JSONObject();
                out.put("tempC", tempC);
                out.put("code", code);
                out.put("windKmh", wind);
                out.put("desc", weatherCodeToTurkish(code));
                out.put("iceWarning", tempC <= 3.0f);
                return out.toString();
            }
        } catch (Throwable ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        JSONObject fallback = new JSONObject();
        try {
            fallback.put("tempC", vehicleController.getState().outsideTempC);
            fallback.put("code", 0);
            fallback.put("desc", "Açık");
            fallback.put("iceWarning", vehicleController.getState().outsideTempC <= 3.0f);
        } catch (Exception ignored) {
        }
        return fallback.toString();
    }

    private String weatherCodeToTurkish(int code) {
        if (code == 0) return "Açık ve Güneşli";
        if (code <= 3) return "Parçalı Bulutlu";
        if (code <= 49) return "Sisli";
        if (code <= 69) return "Yağmurlu";
        if (code <= 79) return "Kar Yağışlı";
        if (code <= 99) return "Gök Gürültülü Sağanak";
        return "Açık";
    }

    public String calculateEvRouteSummaryJson(double distanceKm, double durationMin) {
        VehicleState st = vehicleController.getState();
        int currentSoc = st.socPercent;
        double usableKwh = 71.98 * ((st.obdSohPercent > 0 ? st.obdSohPercent : 98.8) / 100.0);
        double kwhPerKm = 0.168;
        double neededKwh = distanceKm * kwhPerKm;
        double neededSoc = (neededKwh / usableKwh) * 100.0;
        int arrivalSoc = (int) Math.round(currentSoc - neededSoc);

        JSONObject o = new JSONObject();
        try {
            o.put("distanceKm", Math.round(distanceKm * 10.0) / 10.0);
            o.put("durationMin", Math.round(durationMin));
            o.put("currentSoc", currentSoc);
            o.put("arrivalSoc", arrivalSoc);
            o.put("needsCharging", arrivalSoc < 12);
            if (arrivalSoc >= 12) {
                o.put("summaryText", "Şarj gerekmiyor: hedefe ~%" + arrivalSoc + " batarya ile varırsınız.");
            } else {
                int deficitPct = 20 - arrivalSoc;
                int chargeMinutes = (int) Math.max(10, Math.round((deficitPct * usableKwh / 100.0) / 1.2));
                o.put("summaryText", "Yol üstü ~" + chargeMinutes + " dk DC hızlı şarj önerilir (varışta %20 güvenlik payı).");
            }
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    public String getMaintenanceAndSmartHomeJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("nextServiceKm", maintPrefs.getInt("bakim_km", 30000));
            o.put("inspectionDate", maintPrefs.getString("muayene_tarih", "2026-11-15"));
            o.put("insuranceDate", maintPrefs.getString("sigorta_tarih", "2027-03-10"));
            o.put("tireSeason", maintPrefs.getString("lastik_mevsim", "Yaz Lastiği Takılı"));
            o.put("smartHomeArrivalUrl", smartHomePrefs.getString("varis_url", ""));
            o.put("smartHomeDepartureUrl", smartHomePrefs.getString("cikis_url", ""));
            o.put("smartHomeLastLog", smartHomePrefs.getString("son", "Henüz tetiklenmedi"));
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    public void saveSmartHomeWebhooks(String arrivalUrl, String departureUrl) {
        smartHomePrefs.edit()
                .putString("varis_url", arrivalUrl != null ? arrivalUrl.trim() : "")
                .putString("cikis_url", departureUrl != null ? departureUrl.trim() : "")
                .apply();
    }

    public void triggerSmartHomeWebhook(final boolean isArrival) {
        final String urlStr = smartHomePrefs.getString(isArrival ? "varis_url" : "cikis_url", "");
        if (urlStr == null || !urlStr.startsWith("https://")) return;
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(urlStr).openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                String payload = "{\"event\":\"" + (isArrival ? "arrival" : "departure") + "\",\"car\":\"Skywell ET5\"}";
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payload.getBytes(StandardCharsets.UTF_8));
                }
                int code = conn.getResponseCode();
                String time = new SimpleDateFormat("HH:mm", new Locale("tr")).format(new Date());
                String log = (isArrival ? "Eve Varış" : "Evden Çıkış") + " - " + time + " - HTTP " + code;
                smartHomePrefs.edit().putString("son", log).apply();
            } catch (Throwable t) {
                Log.w(TAG, "Akilli ev hatasi: " + t.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
            }
        }, "Et5-SmartHome").start();
    }
}
