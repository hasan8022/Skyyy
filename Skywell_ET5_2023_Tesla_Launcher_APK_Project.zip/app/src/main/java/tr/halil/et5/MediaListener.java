package tr.halil.et5;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * MediaListener NotificationListenerService.
 * Enables MediaSessionManager.getActiveSessions() and syncs track info to the instrument cluster.
 */
public final class MediaListener extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Et5App app = Et5App.getInstance();
        if (app != null && app.getMediaRouter() != null) {
            app.getMediaRouter().syncActiveMediaMetadata();
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {}
}
