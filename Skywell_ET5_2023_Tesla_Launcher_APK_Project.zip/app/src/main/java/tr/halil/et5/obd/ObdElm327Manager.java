package tr.halil.et5.obd;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import tr.halil.et5.car.VehicleController;
import tr.halil.et5.car.VehicleState;

/**
 * 2023 Skywell ET5 OBD2 / CAN-Bus Telemetry Engine (ELM327 & vLinker MS).
 * Implements all ECU headers, Mode 22 PIDs, VTP2D1/VTP251 CAN sniffing, and Mode 19 DTC scanning
 * extracted from C2326oo0.java, C1327f70.java, C0913b70.java, and C2972v.java.
 */
@SuppressLint("MissingPermission")
public final class ObdElm327Manager {

    private static final String TAG = "Et5Obd";
    public static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final Pattern ADAPTER_PATTERN = Pattern.compile("vlink|obd|elm|v-link|vgate|icar|konnwei|carista|veepeak", Pattern.CASE_INSENSITIVE);

    public static final String[][] ECUS = {
        {"VCU",          "7E0", "7E8"},
        {"BMS",          "711", "791"},
        {"Gösterge/VCU", "722", "7A2"},
        {"Motor",        "710", "790"},
        {"ABS",          "723", "7A3"},
        {"Şarj/DC-DC",   "713", "793"}
    };

    private final Context context;
    private final VehicleController controller;
    private volatile boolean running = false;
    private volatile boolean triggerDtcScan = false;
    private Thread workerThread;
    private String currentHeader = "";

    public ObdElm327Manager(Context context, VehicleController controller) {
        this.context = context.getApplicationContext();
        this.controller = controller;
    }

    public SharedPreferences prefs() {
        return context.getSharedPreferences("obd", Context.MODE_PRIVATE);
    }

    public void startIfConfigured() {
        if (running) return;
        running = true;
        workerThread = new Thread(this::obdLoop, "et5-obd-worker");
        workerThread.setDaemon(true);
        workerThread.start();
    }

    public void stop() {
        running = false;
        if (workerThread != null) {
            workerThread.interrupt();
            workerThread = null;
        }
    }

    public void requestDtcScan() {
        triggerDtcScan = true;
        if (!running) startIfConfigured();
    }

    public BluetoothDevice findBestObdDevice() {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null || !adapter.isEnabled()) return null;
            String savedMac = prefs().getString("adres", null);
            if (savedMac != null && !savedMac.isEmpty()) {
                return adapter.getRemoteDevice(savedMac);
            }
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            if (bonded != null) {
                for (BluetoothDevice dev : bonded) {
                    String name = dev.getName();
                    if (name != null && ADAPTER_PATTERN.matcher(name).find()) {
                        prefs().edit().putString("adres", dev.getAddress()).putString("ad", name).apply();
                        return dev;
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private void obdLoop() {
        VehicleState st = controller.getState();
        while (running) {
            BluetoothDevice dev = findBestObdDevice();
            if (dev == null) {
                st.obdConnected = false;
                st.obdStatus = "Adaptör Bekleniyor (Bluetooth OBD/vLinker)";
                controller.notifyStateChanged();
                sleepQuietly(5000);
                continue;
            }

            st.obdStatus = "Bağlanıyor: " + (dev.getName() != null ? dev.getName() : dev.getAddress());
            controller.notifyStateChanged();

            try (BluetoothSocket sock = dev.createRfcommSocketToServiceRecord(SPP_UUID)) {
                BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                sock.connect();
                InputStream in = sock.getInputStream();
                OutputStream out = sock.getOutputStream();

                st.obdConnected = true;
                st.obdStatus = "Bağlı (" + (dev.getName() != null ? dev.getName() : "OBD2") + ")";
                controller.notifyStateChanged();

                initAdapter(in, out);

                int cycle = 0;
                while (running && sock.isConnected()) {
                    // Fast Poll (C2326oo0.d): Pack A, Pack V, SoC, Speed, Motor RPM, Motor Torque
                    pollFastTelemetry(in, out, st);

                    // Full Poll (C2326oo0.k) every 3rd cycle
                    if (cycle % 3 == 0) {
                        pollExtendedTelemetry(in, out, st);
                    }

                    // On-demand DTC scan across all 6 ECUs (1902FF)
                    if (triggerDtcScan) {
                        triggerDtcScan = false;
                        scanAllEcuDtcs(in, out, st);
                    }

                    controller.notifyStateChanged();
                    cycle++;
                    sleepQuietly(350);
                }
            } catch (Throwable t) {
                st.obdConnected = false;
                st.obdStatus = "Yeniden Bağlanıyor...";
                controller.notifyStateChanged();
                sleepQuietly(4000);
            }
        }
    }

    private void initAdapter(InputStream in, OutputStream out) throws Exception {
        sendObdCommand(in, out, "ATZ", 2000);
        String[] initCmds = {"ATE0", "ATL0", "ATS0", "ATH0", "ATSP6", "ATCAF1", "ATCFC1", "ATAT1", "ATST32"};
        for (String cmd : initCmds) {
            sendObdCommand(in, out, cmd, 1000);
        }
        currentHeader = "";
    }

    private void selectEcu(InputStream in, OutputStream out, String txHeader, String rxFilter) throws Exception {
        if (txHeader.equals(currentHeader)) return;
        sendObdCommand(in, out, "ATSH" + txHeader, 800);
        sendObdCommand(in, out, "ATCRA" + rxFilter, 800);
        sendObdCommand(in, out, "ATFCSH" + txHeader, 800);
        sendObdCommand(in, out, "ATFCSD300000", 800);
        sendObdCommand(in, out, "ATFCSM1", 800);
        currentHeader = txHeader;
    }

    private void pollFastTelemetry(InputStream in, OutputStream out, VehicleState st) throws Exception {
        // BMS 711 -> 791
        int[] r1001 = queryPid(in, out, "711", "791", "1001");
        if (r1001 != null && r1001.length >= 2) {
            int raw = u16Be(r1001);
            st.hvCurrent = raw < 20000 ? 1000.0f - (raw / 10.0f) : (33592 - raw) / 10.0f;
        }
        int[] r1002 = queryPid(in, out, "711", "791", "1002");
        if (r1002 != null && r1002.length >= 2) {
            st.hvVoltage = u16Be(r1002) / 10.0f;
        }
        st.powerKw = (st.hvVoltage * st.hvCurrent) / 1000.0f;

        int[] r1003 = queryPid(in, out, "711", "791", "1003");
        if (r1003 != null && r1003.length >= 2) {
            st.socPercent = Math.round(u16Be(r1003) / 10.0f);
        }

        // VCU 722 -> 7A2 Speed
        int[] r0E01 = queryPid(in, out, "722", "7A2", "0E01");
        if (r0E01 != null && r0E01.length >= 2) {
            st.speedKmh = Math.round(u16Be(r0E01) * 0.05625f);
        }

        // Motor 710 -> 790 RPM & Torque
        int[] r1601 = queryPid(in, out, "710", "790", "1601");
        if (r1601 != null && r1601.length >= 2) {
            st.obdMotorRpm = Math.abs(u16Le(r1601) - 20000);
        }
        int[] r1606 = queryPid(in, out, "710", "790", "1606");
        if (r1606 != null && r1606.length >= 2) {
            st.obdMotorTorqueNm = (u16Le(r1606) - 4000) / 10.0f;
        }
    }

    private void pollExtendedTelemetry(InputStream in, OutputStream out, VehicleState st) throws Exception {
        // BMS Cell Min/Max V, Temp Min/Max C, Isolation kOhm
        int[] r1004 = queryPid(in, out, "711", "791", "1004");
        if (r1004 != null && r1004.length >= 2) st.obdCellMaxV = u16Be(r1004) / 10000.0f;

        int[] r1005 = queryPid(in, out, "711", "791", "1005");
        if (r1005 != null && r1005.length >= 2) st.obdCellMinV = u16Be(r1005) / 10000.0f;

        int[] r1006 = queryPid(in, out, "711", "791", "1006");
        if (r1006 != null && r1006.length >= 1) st.obdTempMaxC = r1006[0] - 40.0f;

        int[] r1007 = queryPid(in, out, "711", "791", "1007");
        if (r1007 != null && r1007.length >= 1) st.obdTempMinC = r1007[0] - 40.0f;

        int[] r1008 = queryPid(in, out, "711", "791", "1008");
        if (r1008 != null && r1008.length >= 2) st.obdIsolationKohm = u16Be(r1008);

        // VCU Odometer (0E0A)
        int[] r0E0A = queryPid(in, out, "722", "7A2", "0E0A");
        if (r0E0A != null && r0E0A.length >= 4) {
            long odo = ((long) r0E0A[0] << 24) | ((long) r0E0A[1] << 16) | ((long) r0E0A[2] << 8) | r0E0A[3];
            if (odo > 0) st.odometerKm = odo;
        }

        // Motor & Inverter Temps (1604, 1605)
        int[] r1604 = queryPid(in, out, "710", "790", "1604");
        if (r1604 != null && r1604.length >= 1) st.obdMotorTempC = r1604[0] - 40.0f;

        int[] r1605 = queryPid(in, out, "710", "790", "1605");
        if (r1605 != null && r1605.length >= 1 && r1605[0] >= 71 && r1605[0] < 171) {
            st.obdInverterTempC = r1605[0] - 40.0f;
        }

        // Charger / OBC / DC-DC (713 -> 793)
        int[] r1402 = queryPid(in, out, "713", "793", "1402");
        if (r1402 != null && r1402.length >= 1) st.obdObcTempC = r1402[0] - 40.0f;

        int[] r1408 = queryPid(in, out, "713", "793", "1408");
        if (r1408 != null && r1408.length >= 1) st.obdDcdcTempC = r1408[0] - 40.0f;

        int[] r140A = queryPid(in, out, "713", "793", "140A");
        if (r140A != null && r140A.length >= 2) {
            float acV = u16Be(r140A) / 10.0f;
            st.obdAcVoltage = acV > 30.0f ? acV : 0.0f;
        }

        int[] r140B = queryPid(in, out, "713", "793", "140B");
        if (r140B != null && r140B.length >= 2) st.obdAcCurrent = u16Be(r140B) / 10.0f;

        int[] r140F = queryPid(in, out, "713", "793", "140F");
        if (r140F != null && r140F.length >= 2) st.battery12v = u16Be(r140F);
    }

    private void scanAllEcuDtcs(InputStream in, OutputStream out, VehicleState st) {
        StringBuilder report = new StringBuilder();
        int totalDtcs = 0;
        for (String[] ecu : ECUS) {
            try {
                selectEcu(in, out, ecu[1], ecu[2]);
                List<String> lines = sendObdCommand(in, out, "1902FF", 2000);
                int[] bytes = parseIsoTpBytes(lines);
                if (bytes != null) {
                    int idx = indexOfSubArray(bytes, new int[]{0x59, 0x02});
                    if (idx >= 0) {
                        int i = idx + 3;
                        while (i + 3 < bytes.length) {
                            int b0 = bytes[i];
                            int b1 = bytes[i + 1];
                            int b2 = bytes[i + 2];
                            int status = bytes[i + 3];
                            if ((b0 | b1 | b2) != 0) {
                                char prefix = "PCBU".charAt((b0 >> 6) & 3);
                                String code = String.format("%c%d%X%02X-%02X",
                                        prefix, (b0 >> 4) & 3, b0 & 15, b1, b2);
                                report.append(ecu[0]).append(": ").append(code)
                                      .append(" (durum=0x").append(Integer.toHexString(status)).append(")\n");
                                totalDtcs++;
                            }
                            i += 4;
                        }
                    }
                }
            } catch (Throwable ignored) {}
        }
        if (totalDtcs == 0) {
            st.lastDtcReport = "6 ECU Tarandı (VCU, BMS, Gösterge, Motor, ABS, OBC): Arıza kodu (DTC) bulunmadı.";
        } else {
            st.lastDtcReport = totalDtcs + " Arıza Kodu Bulundu:\n" + report.toString().trim();
        }
        Log.i(TAG, st.lastDtcReport);
    }

    private int[] queryPid(InputStream in, OutputStream out, String tx, String rx, String didHex) throws Exception {
        selectEcu(in, out, tx, rx);
        List<String> lines = sendObdCommand(in, out, "22" + didHex, 1000);
        int[] bytes = parseIsoTpBytes(lines);
        if (bytes == null) return null;
        int d0 = Integer.parseInt(didHex.substring(0, 2), 16);
        int d1 = Integer.parseInt(didHex.substring(2, 4), 16);
        int pos = indexOfSubArray(bytes, new int[]{0x62, d0, d1});
        if (pos < 0 || pos + 3 >= bytes.length) return null;
        return Arrays.copyOfRange(bytes, pos + 3, bytes.length);
    }

    private List<String> sendObdCommand(InputStream in, OutputStream out, String cmd, long timeoutMs) throws Exception {
        while (in.available() > 0) in.read();
        out.write((cmd + "\r").getBytes(StandardCharsets.US_ASCII));
        out.flush();

        StringBuilder sb = new StringBuilder();
        long deadline = System.currentTimeMillis() + timeoutMs;
        byte[] buf = new byte[256];
        while (System.currentTimeMillis() < deadline) {
            if (in.available() > 0) {
                int r = in.read(buf);
                if (r > 0) {
                    String chunk = new String(buf, 0, r, StandardCharsets.US_ASCII);
                    sb.append(chunk);
                    if (chunk.indexOf('>') >= 0) break;
                }
            } else {
                Thread.sleep(15);
            }
        }
        String raw = sb.toString().replace(">", "").trim();
        String[] split = raw.split("[\\r\\n]+");
        List<String> lines = new ArrayList<>();
        for (String s : split) {
            String t = s.trim();
            if (!t.isEmpty()) lines.add(t);
        }
        return lines;
    }

    public static int[] parseIsoTpBytes(List<String> lines) {
        if (lines == null || lines.isEmpty()) return null;
        for (String l : lines) {
            if (l.contains("NO DATA") || l.contains("ERROR") || l.contains("?") || l.contains("STOPPED")) {
                return null;
            }
        }
        boolean multiFrame = false;
        Pattern mfCheck = Pattern.compile("^[0-9A-F]:");
        for (String l : lines) {
            if (mfCheck.matcher(l.trim()).find()) {
                multiFrame = true;
                break;
            }
        }
        StringBuilder hex = new StringBuilder();
        Pattern mfLine = Pattern.compile("^[0-9A-F]:([0-9A-F]+)$");
        Pattern sfLine = Pattern.compile("^[0-9A-F]+$");
        for (String l : lines) {
            String clean = l.replace(" ", "").trim();
            if (multiFrame) {
                Matcher m = mfLine.matcher(clean);
                if (m.find()) hex.append(m.group(1));
            } else if (sfLine.matcher(clean).matches()) {
                hex.append(clean);
            }
        }
        if (hex.length() < 4 || hex.toString().startsWith("7F")) return null;
        int len = hex.length() / 2;
        int[] out = new int[len];
        for (int i = 0; i < len; i++) {
            out[i] = Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
        }
        return out;
    }

    private static int indexOfSubArray(int[] haystack, int[] needle) {
        int max = haystack.length - needle.length;
        for (int i = 0; i <= max; i++) {
            boolean match = true;
            for (int j = 0; j < needle.length; j++) {
                if (haystack[i + j] != needle[j]) {
                    match = false;
                    break;
                }
            }
            if (match) return i;
        }
        return -1;
    }

    private static int u16Be(int[] b) {
        return ((b[0] & 0xFF) << 8) | (b[1] & 0xFF);
    }

    private static int u16Le(int[] b) {
        return (b[0] & 0xFF) | ((b[1] & 0xFF) << 8);
    }

    private static void sleepQuietly(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {}
    }
}
