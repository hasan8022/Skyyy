package tr.halil.et5.helper;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Skywell ET5 (2023) UID 1000 Sistem Yardımcı Servisi (127.0.0.1:8724).
 */
public class AracYardimci {
    public static final int PORT = 8724;
    public static final String HELPER_VER = "VER a8ff73d5e1f6";

    private static Object sCarObj;
    private static Object sCarPropertyManager;
    private static Object sCdsManager;
    private static Context sSystemContext;
    private static String sAuthSecret = "";
    private static final CopyOnWriteArrayList<PrintWriter> sWatchClients = new CopyOnWriteArrayList<>();
    private static final ConcurrentHashMap<Integer, Boolean> sRegisteredProps = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        try {
            if (Looper.getMainLooper() == null) {
                Looper.prepareMainLooper();
            }
            int port = PORT;
            if (args != null && args.length >= 2 && "serve".equals(args[0])) {
                try {
                    port = Integer.parseInt(args[1]);
                } catch (Exception ignored) {
                }
                if (args.length >= 3 && args[2] != null) {
                    sAuthSecret = args[2].trim();
                }
            }
            initSystemContext();
            initCarPropertyManager();
            initCdsManager();

            ServerSocket server = new ServerSocket(port, 32, InetAddress.getByName("127.0.0.1"));
            System.out.println("AracYardimci UID=" + android.os.Process.myUid() + " port=" + port + " hazir (" + HELPER_VER + ")");

            while (true) {
                final Socket client = server.accept();
                new Thread(() -> handleClient(client), "AracYardimci-Client").start();
            }
        } catch (Throwable t) {
            t.printStackTrace();
            System.exit(1);
        }
    }

    private static void initSystemContext() {
        try {
            Class<?> atClass = Class.forName("android.app.ActivityThread");
            Method systemMain = atClass.getDeclaredMethod("systemMain");
            Object at = systemMain.invoke(null);
            Method getSysCtx = atClass.getDeclaredMethod("getSystemContext");
            sSystemContext = (Context) getSysCtx.invoke(at);
        } catch (Throwable t) {
            System.err.println("SystemContext alinamadi: " + t.getMessage());
        }
    }

    private static synchronized void initCarPropertyManager() {
        if (sCarPropertyManager != null || sSystemContext == null) return;
        try {
            Class<?> carClass = Class.forName("android.car.Car");
            Method createCar = carClass.getMethod("createCar", Context.class);
            sCarObj = createCar.invoke(null, sSystemContext);
            if (sCarObj != null) {
                Method getCarManager = carClass.getMethod("getCarManager", String.class);
                sCarPropertyManager = getCarManager.invoke(sCarObj, "property");
            }
        } catch (Throwable t) {
            System.err.println("CarPropertyManager baslatilamadi: " + t.getMessage());
        }
    }

    private static synchronized void initCdsManager() {
        if (sCdsManager != null || sSystemContext == null) return;
        try {
            Class<?> cdsClass = Class.forName("com.skyworth.cds.CDSManager");
            try {
                Method getInstance = cdsClass.getMethod("getInstance", Context.class);
                sCdsManager = getInstance.invoke(null, sSystemContext);
            } catch (NoSuchMethodException e) {
                sCdsManager = cdsClass.getConstructor(Context.class).newInstance(sSystemContext);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void handleClient(Socket socket) {
        PrintWriter out = null;
        try {
            socket.setTcpNoDelay(true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);

            String line;
            while ((line = in.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String response = executeCommand(line, out);
                if (response != null) {
                    out.println(response);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (out != null) {
                sWatchClients.remove(out);
            }
            try {
                socket.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static String executeCommand(String line, PrintWriter clientOut) {
        try {
            String[] parts = line.split("\\s+");
            String cmd = parts[0];

            switch (cmd) {
                case "AUTH":
                case "LIC":
                    return "OK";

                case "VER":
                    return HELPER_VER;

                case "GET": {
                    if (parts.length < 3) return "ERR args";
                    int propId = parsePropId(parts[1]);
                    int areaId = Integer.parseInt(parts[2]);
                    String val = readCarPropertyFormatted(propId, areaId);
                    return val != null ? "VAL " + val : "ERR null";
                }

                case "SET": {
                    if (parts.length < 5) return "ERR args";
                    int propId = parsePropId(parts[1]);
                    int areaId = Integer.parseInt(parts[2]);
                    String type = parts[3];
                    String valStr = parts[4];
                    return writeCarPropertyTyped(propId, areaId, type, valStr);
                }

                case "WATCH": {
                    sWatchClients.addIfAbsent(clientOut);
                    for (int i = 1; i < parts.length; i++) {
                        try {
                            int propId = parsePropId(parts[i]);
                            registerPropertyWatch(propId);
                        } catch (Exception ignored) {
                        }
                    }
                    return "OK";
                }

                case "DASH": {
                    if (parts.length < 3) return "ERR args";
                    boolean ok = invokeCdsInt(parts[1], Integer.parseInt(parts[2]));
                    return ok ? "OK" : "ERR cds";
                }

                case "DASHGET":
                    return "OK 1,50,1";

                case "MUSIC": {
                    if (parts.length < 4) return "ERR args";
                    int state = Integer.parseInt(parts[1]);
                    String title = new String(Base64.decode(parts[2], Base64.NO_WRAP), StandardCharsets.UTF_8);
                    String artist = new String(Base64.decode(parts[3], Base64.NO_WRAP), StandardCharsets.UTF_8);
                    sendMusicToCluster(state, title, artist);
                    return "OK";
                }

                case "PREF": {
                    if (parts.length < 4) return "ERR args";
                    boolean ok = writeAiSettingsPref(parts[1], parts[2], Integer.parseInt(parts[3]));
                    return ok ? "OK" : "ERR pref";
                }

                case "PREFS":
                    return readAllAiSettingsPrefs();

                case "BT": {
                    if (parts.length >= 4 && "confirm".equals(parts[1])) {
                        boolean confirm = "true".equalsIgnoreCase(parts[3]) || "1".equals(parts[3]);
                        boolean ok = confirmBluetoothPairing(parts[2], confirm);
                        return ok ? "OK" : "ERR bt";
                    }
                    return "ERR bt_args";
                }

                case "NET": {
                    String shellCmd = line.substring(4).trim();
                    Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", shellCmd});
                    BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder sb = new StringBuilder();
                    String l;
                    while ((l = r.readLine()) != null) {
                        sb.append(l).append("\n");
                    }
                    p.waitFor();
                    String b64 = Base64.encodeToString(sb.toString().getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                    return "OUT " + b64;
                }

                case "merhaba":
                case "ping":
                    return "tamam uid=" + android.os.Process.myUid() + " " + HELPER_VER;

                case "car_oku": {
                    int propId = parsePropId(parts[1]);
                    int areaId = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
                    String val = readCarPropertyFormatted(propId, areaId);
                    return val != null ? "tamam " + val : "hata null";
                }

                case "car_int": {
                    int propId = parsePropId(parts[1]);
                    int areaId = Integer.parseInt(parts[2]);
                    String res = writeCarPropertyTyped(propId, areaId, "i", parts[3]);
                    return "OK".equals(res) ? "tamam" : "hata " + res;
                }

                case "car_float": {
                    int propId = parsePropId(parts[1]);
                    int areaId = Integer.parseInt(parts[2]);
                    String res = writeCarPropertyTyped(propId, areaId, "f", parts[3]);
                    return "OK".equals(res) ? "tamam" : "hata " + res;
                }

                case "car_int_dizi": {
                    int propId = parsePropId(parts[1]);
                    int areaId = Integer.parseInt(parts[2]);
                    String res = writeCarPropertyTyped(propId, areaId, "ia", parts[3]);
                    return "OK".equals(res) ? "tamam" : "hata " + res;
                }

                case "ayar_oku":
                    return "tamam " + readSetting(parts[1], parts[2]);

                case "ayar_yaz": {
                    String val = line.substring(line.indexOf(parts[2]) + parts[2].length()).trim();
                    boolean ok = writeSetting(parts[1], parts[2], val);
                    return ok ? "tamam" : "hata ayar_yaz";
                }

                case "prop_oku":
                    return "tamam " + getSystemProperty(parts[1], "");

                case "prop_yaz": {
                    boolean ok = setSystemProperty(parts[1], parts.length > 2 ? parts[2] : "");
                    return ok ? "tamam" : "hata prop_yaz";
                }

                case "cds_int": {
                    boolean ok = invokeCdsInt(parts[1], Integer.parseInt(parts[2]));
                    return ok ? "tamam" : "hata cds_int";
                }

                case "cds_float": {
                    boolean ok = invokeCdsFloat(parts[1], Float.parseFloat(parts[2]));
                    return ok ? "tamam" : "hata cds_float";
                }

                case "gorev_kaldir": {
                    Runtime.getRuntime().exec(new String[]{"am", "force-stop", parts[1]}).waitFor();
                    return "tamam";
                }

                case "one_getir": {
                    Runtime.getRuntime().exec(new String[]{"am", "start", "-n", parts[1] + "/tr.halil.et5.MainActivity"}).waitFor();
                    return "tamam";
                }

                default:
                    return "ERR unknown_cmd:" + cmd;
            }
        } catch (Throwable t) {
            return "ERR " + t.getClass().getSimpleName() + ": " + t.getMessage();
        }
    }

    private static int parsePropId(String s) {
        s = s.trim();
        if (s.startsWith("0x") || s.startsWith("0X")) {
            return (int) Long.parseLong(s.substring(2), 16);
        }
        return Integer.parseInt(s);
    }

    public static String readCarPropertyFormatted(int propId, int areaId) {
        initCarPropertyManager();
        if (sCarPropertyManager == null) return null;
        try {
            Method getProp = sCarPropertyManager.getClass().getMethod("getProperty", int.class, int.class);
            Object propVal = getProp.invoke(sCarPropertyManager, propId, areaId);
            if (propVal == null && areaId == 0) {
                propVal = getProp.invoke(sCarPropertyManager, propId, 117);
            }
            if (propVal == null) return null;
            Method getValue = propVal.getClass().getMethod("getValue");
            Object val = getValue.invoke(propVal);
            return formatPropertyValue(val);
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean writeCarProperty(int propId, int areaId, String type, String valStr) {
        return "OK".equals(writeCarPropertyTyped(propId, areaId, type, valStr));
    }

    private static String formatPropertyValue(Object val) {
        if (val == null) return null;
        if (val.getClass().isArray()) {
            int len = Array.getLength(val);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < len; i++) {
                if (i > 0) sb.append(",");
                sb.append(Array.get(val, i));
            }
            return sb.toString();
        }
        return String.valueOf(val);
    }

    private static String writeCarPropertyTyped(int propId, int areaId, String type, String valStr) {
        initCarPropertyManager();
        if (sCarPropertyManager == null) return "ERR no_car_manager";
        try {
            Class<?> valClass;
            Object valObj;
            if ("b".equalsIgnoreCase(type)) {
                valClass = Boolean.class;
                valObj = Boolean.parseBoolean(valStr) || "1".equals(valStr);
            } else if ("f".equalsIgnoreCase(type)) {
                valClass = Float.class;
                valObj = Float.parseFloat(valStr);
            } else if ("ia".equalsIgnoreCase(type)) {
                valClass = Integer[].class;
                String[] parts = valStr.split(",");
                Integer[] boxed = new Integer[parts.length];
                int[] prim = new int[parts.length];
                for (int i = 0; i < parts.length; i++) {
                    prim[i] = (int) Float.parseFloat(parts[i].trim());
                    boxed[i] = prim[i];
                }
                if (writeCarPropertyRaw(propId, areaId, Integer[].class, boxed)
                        || writeCarPropertyRaw(propId, areaId, int[].class, prim)) {
                    return "OK";
                }
                return "ERR ia";
            } else {
                valClass = Integer.class;
                valObj = (int) Float.parseFloat(valStr);
            }
            Method setProp = sCarPropertyManager.getClass().getMethod("setProperty", Class.class, int.class, int.class, Object.class);
            setProp.invoke(sCarPropertyManager, valClass, propId, areaId, valObj);
            return "OK";
        } catch (Throwable t) {
            Throwable cause = t.getCause() != null ? t.getCause() : t;
            return "ERR " + cause.getClass().getSimpleName() + ": " + cause.getMessage();
        }
    }

    private static boolean writeCarPropertyRaw(int propId, int areaId, Class<?> valClass, Object valObj) {
        initCarPropertyManager();
        if (sCarPropertyManager == null) return false;
        try {
            Method setProp = sCarPropertyManager.getClass().getMethod("setProperty", Class.class, int.class, int.class, Object.class);
            setProp.invoke(sCarPropertyManager, valClass, propId, areaId, valObj);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void registerPropertyWatch(int propId) {
        initCarPropertyManager();
        if (sCarPropertyManager == null || sRegisteredProps.putIfAbsent(propId, Boolean.TRUE) != null) {
            return;
        }
        try {
            Class<?> cbInterface = Class.forName("android.car.hardware.property.CarPropertyManager$CarPropertyEventCallback");
            Object proxy = java.lang.reflect.Proxy.newProxyInstance(
                    cbInterface.getClassLoader(),
                    new Class<?>[]{cbInterface},
                    (proxyObj, method, args) -> {
                        if ("onChangeEvent".equals(method.getName()) && args != null && args.length >= 1 && args[0] != null) {
                            Object carPropVal = args[0];
                            int pId = (Integer) carPropVal.getClass().getMethod("getPropertyId").invoke(carPropVal);
                            int aId = (Integer) carPropVal.getClass().getMethod("getAreaId").invoke(carPropVal);
                            Object v = carPropVal.getClass().getMethod("getValue").invoke(carPropVal);
                            String formatted = formatPropertyValue(v);
                            if (formatted != null) {
                                broadcastWatchEvent(pId, aId, formatted);
                            }
                        }
                        return null;
                    }
            );
            Method regMethod = sCarPropertyManager.getClass().getMethod("registerCallback", cbInterface, int.class, float.class);
            regMethod.invoke(sCarPropertyManager, proxy, propId, 0.0f);
        } catch (Throwable ignored) {
        }
    }

    private static void broadcastWatchEvent(int propId, int areaId, String formattedVal) {
        String evtLine = String.format(Locale.US, "EVT 0x%08x %d %s", propId, areaId, formattedVal);
        for (PrintWriter pw : sWatchClients) {
            try {
                pw.println(evtLine);
            } catch (Throwable t) {
                sWatchClients.remove(pw);
            }
        }
    }

    private static String readSetting(String table, String key) {
        if (sSystemContext == null) return "";
        ContentResolver cr = sSystemContext.getContentResolver();
        switch (table.toLowerCase(Locale.ROOT)) {
            case "system":
                return Settings.System.getString(cr, key);
            case "secure":
                return Settings.Secure.getString(cr, key);
            case "global":
                return Settings.Global.getString(cr, key);
            default:
                return "";
        }
    }

    private static boolean writeSetting(String table, String key, String val) {
        if (sSystemContext == null) return false;
        ContentResolver cr = sSystemContext.getContentResolver();
        switch (table.toLowerCase(Locale.ROOT)) {
            case "system":
                return Settings.System.putString(cr, key, val);
            case "secure":
                return Settings.Secure.putString(cr, key, val);
            case "global":
                return Settings.Global.putString(cr, key, val);
            case "hvac": {
                ContentValues cv = new ContentValues();
                cv.put("name", key);
                cv.put("value", val);
                cr.insert(Uri.parse("content://com.skyworth.car.hvac.provider/hvac"), cv);
                return true;
            }
            case "aisettings": {
                ContentValues cv = new ContentValues();
                cv.put("name", key);
                cv.put("value", val);
                cr.insert(Uri.parse("content://com.skyworth.car.aisettings.provider/settings"), cv);
                return true;
            }
            case "recovery": {
                ContentValues cv = new ContentValues();
                cv.put("comfort", val);
                cr.update(Uri.parse("content://com.skyworth.car.aisettings.vehiclecontrol.database/recovery"), cv, null, null);
                return true;
            }
            default:
                return false;
        }
    }

    private static boolean writeAiSettingsPref(String category, String key, int val) {
        try {
            if (sSystemContext != null) {
                Context pkgCtx = sSystemContext.createPackageContext("com.skyworth.car.aisettings", Context.CONTEXT_IGNORE_SECURITY);
                SharedPreferences sp = pkgCtx.getSharedPreferences(category, Context.MODE_PRIVATE);
                sp.edit().putInt(key, val).apply();
                return true;
            }
        } catch (Throwable ignored) {
        }
        return writeSetting("aisettings", key, String.valueOf(val));
    }

    private static String readAllAiSettingsPrefs() {
        StringBuilder sb = new StringBuilder("PREFS ");
        String[] cats = new String[]{"assistance", "vehicle", "display", "sound"};
        try {
            if (sSystemContext != null) {
                Context pkgCtx = sSystemContext.createPackageContext("com.skyworth.car.aisettings", Context.CONTEXT_IGNORE_SECURITY);
                for (String cat : cats) {
                    SharedPreferences sp = pkgCtx.getSharedPreferences(cat, Context.MODE_PRIVATE);
                    for (Map.Entry<String, ?> entry : sp.getAll().entrySet()) {
                        if (entry.getValue() instanceof Number) {
                            sb.append(cat).append(":").append(entry.getKey()).append("=").append(entry.getValue()).append(";");
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return sb.toString();
    }

    private static boolean confirmBluetoothPairing(String macAddress, boolean confirm) {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) return false;
            BluetoothDevice dev = adapter.getRemoteDevice(macAddress);
            if (dev == null) return false;
            Method m = BluetoothDevice.class.getMethod("setPairingConfirmation", boolean.class);
            m.invoke(dev, confirm);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void sendMusicToCluster(int state, String title, String artist) {
        initCdsManager();
        if (sCdsManager == null) return;
        try {
            Method m = sCdsManager.getClass().getMethod("sendMessage", int.class, String.class);
            String json = "{\"state\":" + state + ",\"title\":\"" + title.replace("\"", "'") + "\",\"artist\":\"" + artist.replace("\"", "'") + "\"}";
            m.invoke(sCdsManager, 100, json);
        } catch (Throwable ignored) {
        }
    }

    private static String getSystemProperty(String key, String def) {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            Method get = sp.getMethod("get", String.class, String.class);
            return (String) get.invoke(null, key, def);
        } catch (Throwable t) {
            return def;
        }
    }

    private static boolean setSystemProperty(String key, String val) {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            Method set = sp.getMethod("set", String.class, String.class);
            set.invoke(null, key, val);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean invokeCdsInt(String methodName, int val) {
        initCdsManager();
        if (sCdsManager == null) return false;
        try {
            Method m = sCdsManager.getClass().getMethod(methodName, int.class);
            m.invoke(sCdsManager, val);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean invokeCdsFloat(String methodName, float val) {
        initCdsManager();
        if (sCdsManager == null) return false;
        try {
            Method m = sCdsManager.getClass().getMethod(methodName, float.class);
            m.invoke(sCdsManager, val);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
