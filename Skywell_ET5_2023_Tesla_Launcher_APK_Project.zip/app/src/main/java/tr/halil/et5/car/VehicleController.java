package tr.halil.et5.car;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import tr.halil.et5.helper.AdbRootBridge;
import tr.halil.et5.helper.AracYardimci;

/**
 * 2023 Skywell ET5 (Skyworth EV6) Gerçek Araç Kontrolcüsü.
 * Birebir DE.java, Pe0.java, Mg0.java, C0227Hf.java ve d4.smali mimarisiyle çalışır.
 * SIFIR DEMO VERİ: Tüm değerler AracYardimci (127.0.0.1:8724) ve ContentProvider üzerinden gerçek zamanlı okunur.
 */
public final class VehicleController {

    private static final String TAG = "Et5VehicleCtrl";
    public static final Uri URI_SKYHVAC_TEMP = Uri.parse(Et5PropertyCatalog.URI_SKYHVAC_TEMP);
    public static final Uri URI_RECOVERY = Uri.parse(Et5PropertyCatalog.URI_AISETTINGS_BASE + "recovery");

    public interface StateListener {
        void onVehicleStateChanged(VehicleState state);
        void onReverseGearChanged(boolean inReverse);
        default void onSteeringVoiceButtonPressed() {}
    }

    private final Context context;
    private final VehicleState state = new VehicleState();
    private final List<StateListener> listeners = new CopyOnWriteArrayList<>();
    private final ExecutorService ioPool = Executors.newCachedThreadPool();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private Socket cmdSocket;
    private BufferedReader cmdIn;
    private PrintWriter cmdOut;
    private final Object cmdLock = new Object();
    private volatile boolean running = false;

    public VehicleController(Context context) {
        this.context = context.getApplicationContext();
        this.state.loadRealCache(this.context);
        String sysVin = AdbRootBridge.getDetectedVin();
        if (sysVin != null && !sysVin.isEmpty()) {
            this.state.vin = sysVin;
        }
    }

    public VehicleState getState() {
        return state;
    }

    public void addListener(StateListener l) {
        if (!listeners.contains(l)) {
            listeners.add(l);
        }
    }

    public void removeListener(StateListener l) {
        listeners.remove(l);
    }

    public void notifyStateChanged() {
        mainHandler.post(() -> {
            for (StateListener l : listeners) {
                l.onVehicleStateChanged(state);
            }
        });
    }

    public void start() {
        if (running) return;
        running = true;

        registerContentObservers();

        Thread watchThread = new Thread(this::watchLoop, "et5-watch-loop");
        watchThread.setDaemon(true);
        watchThread.start();

        Thread pollThread = new Thread(this::pollLoop, "et5-poll-loop");
        pollThread.setDaemon(true);
        pollThread.start();
    }

    public void reconnectNow() {
        ioPool.execute(() -> {
            closeCmdSocket();
            AdbRootBridge.ensureHelperStarted(context);
            syncInitialVehicleState();
        });
    }

    private void registerContentObservers() {
        try {
            ContentResolver cr = context.getContentResolver();
            cr.registerContentObserver(URI_SKYHVAC_TEMP, true, new ContentObserver(mainHandler) {
                @Override
                public void onChange(boolean selfChange) {
                    ioPool.execute(() -> readSkyHvacTemp());
                }
            });
            cr.registerContentObserver(URI_RECOVERY, true, new ContentObserver(mainHandler) {
                @Override
                public void onChange(boolean selfChange) {
                    ioPool.execute(() -> readRecoveryProvider());
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private void readSkyHvacTemp() {
        // First try direct ContentResolver
        try (Cursor c = context.getContentResolver().query(URI_SKYHVAC_TEMP, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex("lefttemp");
                if (idx < 0) idx = 0;
                int raw = c.getInt(idx);
                float temp = Float.NaN;
                if (raw == 155) temp = 16.0f;
                else if (raw == 325) temp = 32.0f;
                else if (raw >= 160 && raw <= 320) temp = raw / 10.0f;
                if (!Float.isNaN(temp)) {
                    state.hvacTargetTemp = temp;
                    notifyStateChanged();
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
        // Fallback via AracYardimci (uid=1000)
        String resp = sendHelperCommand("HVAC_TEMP_GET");
        if (resp != null && resp.startsWith("VAL ")) {
            float t = parseFloatSafe(resp.substring(4), Float.NaN);
            if (!Float.isNaN(t)) {
                state.hvacTargetTemp = t;
                notifyStateChanged();
            }
        }
    }

    private void readRecoveryProvider() {
        try (Cursor c = context.getContentResolver().query(URI_RECOVERY, new String[]{"comfort"}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int val = c.getInt(0);
                if (val >= 0 && val <= 100) {
                    state.regenPercent = val;
                    notifyStateChanged();
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private void watchLoop() {
        while (running) {
            try {
                if (!AdbRootBridge.isHelperAlive() && AdbRootBridge.isSetupCompleted(context)) {
                    AdbRootBridge.ensureHelperStarted(context);
                }

                try (Socket watchSock = new Socket()) {
                    watchSock.connect(new InetSocketAddress("127.0.0.1", AracYardimci.PORT), 1800);
                    watchSock.setSoTimeout(0);
                    watchSock.setTcpNoDelay(true);

                    BufferedReader in = new BufferedReader(new InputStreamReader(watchSock.getInputStream(), StandardCharsets.UTF_8));
                    PrintWriter out = new PrintWriter(new OutputStreamWriter(watchSock.getOutputStream(), StandardCharsets.UTF_8), true);

                    out.println("AUTH " + AdbRootBridge.LOCAL_AUTH_KEY);
                    if (!"OK".equals(in.readLine())) {
                        Thread.sleep(2000);
                        continue;
                    }

                    StringBuilder watchCmd = new StringBuilder("WATCH");
                    for (int propId : Et5PropertyCatalog.WATCHED_PROPERTY_IDS) {
                        watchCmd.append(String.format(Locale.US, " 0x%08x", propId));
                    }
                    out.println(watchCmd.toString());

                    state.helperConnected = true;
                    notifyStateChanged();
                    syncInitialVehicleState();

                    String line;
                    while (running && (line = in.readLine()) != null) {
                        if (line.startsWith("EVT ")) {
                            parseWatchEvent(line);
                        }
                    }
                }
            } catch (Throwable t) {
                if (state.helperConnected) {
                    state.helperConnected = false;
                    notifyStateChanged();
                }
                try {
                    Thread.sleep(2500);
                } catch (InterruptedException ignored) {
                }
            }
        }
    }

    private void pollLoop() {
        try {
            Thread.sleep(1500);
        } catch (InterruptedException ignored) {
        }
        while (running) {
            try {
                if (state.helperConnected) {
                    readSkyHvacTemp();
                    readRecoveryProvider();
                    state.saveRealCache(context);
                }
                Thread.sleep(5000);
            } catch (Throwable ignored) {
            }
        }
    }

    public void syncInitialVehicleState() {
        ioPool.execute(() -> {
            String sysVin = AdbRootBridge.getDetectedVin();
            if (sysVin != null && !sysVin.isEmpty()) {
                state.vin = sysVin;
            }
            readSkyHvacTemp();
            readRecoveryProvider();

            String dashResp = sendHelperCommand("DASHGET");
            if (dashResp != null && dashResp.startsWith("OK ")) {
                String[] parts = dashResp.substring(3).trim().split(",");
                if (parts.length >= 2) {
                    state.clusterTheme = parseIntSafe(parts[0], state.clusterTheme);
                    state.clusterBrightness = parseIntSafe(parts[1], state.clusterBrightness);
                }
            }

            for (int propId : Et5PropertyCatalog.WATCHED_PROPERTY_IDS) {
                if (propId == Et5PropertyCatalog.PROP_HVAC_SEAT_TEMPERATURE) {
                    String s1 = getPropertyRaw(propId, 1);
                    if (s1 != null) applyPropertyUpdate(propId, 1, s1);
                    String s4 = getPropertyRaw(propId, 4);
                    if (s4 != null) applyPropertyUpdate(propId, 4, s4);
                } else {
                    String raw = getPropertyRaw(propId, 0);
                    if (raw != null) {
                        applyPropertyUpdate(propId, 0, raw);
                    }
                }
            }
            notifyStateChanged();
        });
    }

    private void parseWatchEvent(String line) {
        try {
            String[] parts = line.split("\\s+", 4);
            if (parts.length < 4) return;
            String hex = parts[1].startsWith("0x") || parts[1].startsWith("0X")
                    ? parts[1].substring(2) : parts[1];
            int propId = Integer.parseUnsignedInt(hex, 16);
            int areaId = Integer.parseInt(parts[2]);
            String val = parts[3].trim();
            applyPropertyUpdate(propId, areaId, val);
        } catch (Throwable ignored) {
        }
    }

    /**
     * Exact Skywell ET5 CAN-Bus property decoder (1:1 with Mg0.java).
     */
    public void applyPropertyUpdate(int propId, int areaId, String val) {
        if (val == null || val.isEmpty() || "null".equalsIgnoreCase(val)) return;
        boolean prevReverse = "R".equals(state.gear);

        switch (propId) {
            case Et5PropertyCatalog.PROP_SPEED_KMH: {
                float raw = parseFloatSafe(val, 0f);
                if (raw > 300f) raw = raw / 100f;
                state.speedKmh = Math.max(0, Math.round(raw));
                state.canDataReceived = true;
                break;
            }
            case Et5PropertyCatalog.PROP_GEAR_SELECTION: {
                int g = parseIntSafe(val, 4);
                if (g == 1) state.gear = "R";
                else if (g == 2) state.gear = "N";
                else if (g == 3) state.gear = "D";
                else state.gear = "P";
                state.canDataReceived = true;
                break;
            }
            case Et5PropertyCatalog.PROP_SOC_PERCENT: {
                int soc = parseIntSafe(val, -1);
                if (soc >= 0 && soc <= 100) {
                    state.socPercent = soc;
                    state.canDataReceived = true;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_SOC_FLOAT: {
                float socF = parseFloatSafe(val, Float.NaN);
                if (!Float.isNaN(socF) && socF >= 0f && socF <= 100f) {
                    state.socExact = socF;
                    if (state.socPercent < 0) state.socPercent = Math.round(socF);
                    state.canDataReceived = true;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_RANGE_KM: {
                int r = parseIntSafe(val, -1);
                if (r >= 0 && r <= 1200) {
                    state.rangeKm = r;
                    state.canDataReceived = true;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_HVAC_TEMP_CURRENT: {
                float t = parseFloatSafe(val, Float.NaN);
                if (!Float.isNaN(t) && t >= -40f && t <= 70f) {
                    state.cabinTempC = t;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_ENV_OUTSIDE_TEMP: {
                float t = parseFloatSafe(val, Float.NaN);
                if (!Float.isNaN(t) && t >= -50f && t <= 70f) {
                    state.outsideTempC = t;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_HVAC_POWER_ON:
                state.hvacPower = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_TEMP_SET: {
                float t = parseFloatSafe(val, Float.NaN);
                if (!Float.isNaN(t) && t >= 15.0f && t <= 33.0f) {
                    state.hvacTargetTemp = t;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_HVAC_FAN_SPEED:
                state.hvacFanSpeed = Math.max(0, Math.min(7, parseIntSafe(val, state.hvacFanSpeed)));
                break;
            case Et5PropertyCatalog.PROP_HVAC_AC_ON:
                state.hvacAc = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_AUTO_ON:
                state.hvacAuto = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_RECIRC_ON:
                state.hvacRecirc = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_DEFROSTER:
                if (areaId == 1) state.hvacFrontDefrost = parseBoolSafe(val);
                else if (areaId == 2) state.hvacRearDefrost = parseBoolSafe(val);
                else state.hvacFrontDefrost = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_SEAT_TEMPERATURE: {
                int lv = Math.max(0, Math.min(3, parseIntSafe(val, 0)));
                if (areaId == 4) state.passengerSeatHeat = lv;
                else state.driverSeatHeat = lv;
                break;
            }
            case Et5PropertyCatalog.PROP_DRIVER_SEAT_VENT:
                state.driverSeatVent = Math.max(0, Math.min(3, parseIntSafe(val, 0)));
                break;
            case Et5PropertyCatalog.PROP_PASSENGER_SEAT_VENT:
                state.passengerSeatVent = Math.max(0, Math.min(3, parseIntSafe(val, 0)));
                break;
            case Et5PropertyCatalog.PROP_DOOR_LOCK: {
                int v = parseIntSafe(val, 2);
                state.locked = (v != 1);
                break;
            }
            case Et5PropertyCatalog.PROP_TRUNK_OPEN_PERCENT: {
                int pct = parseIntSafe(val, 0);
                state.trunkOpenPercent = pct;
                state.trunkOpen = (pct > 5);
                break;
            }
            case Et5PropertyCatalog.PROP_PARKING_BRAKE:
                state.parkingBrake = (parseIntSafe(val, 1) == 1);
                break;
            case Et5PropertyCatalog.PROP_DRIVE_MODE:
                state.driveMode = Math.max(0, Math.min(2, parseIntSafe(val, 0)));
                break;
            case Et5PropertyCatalog.PROP_CHARGING_ACTIVE: {
                int c = parseIntSafe(val, 0);
                state.chargingActive = (c == 1 || c == 2);
                break;
            }
            case Et5PropertyCatalog.PROP_CHARGE_GUN_STATE:
                state.chargeCableConnected = (parseIntSafe(val, 0) > 0);
                break;
            case Et5PropertyCatalog.PROP_CHARGE_REMAIN_MIN:
                state.chargeRemainingMin = Math.max(0, parseIntSafe(val, 0));
                break;
            case Et5PropertyCatalog.PROP_AUTO_HOLD:
                state.autoHold = (parseIntSafe(val, 0) == 1);
                break;
            case Et5PropertyCatalog.PROP_ESC_OFF:
                state.escEnabled = (parseIntSafe(val, 0) == 0);
                break;
            case Et5PropertyCatalog.PROP_HAZARD_LIGHTS:
                state.hazardLights = (parseIntSafe(val, 0) == 1);
                break;
            case Et5PropertyCatalog.PROP_LOW_BEAM:
                state.lowBeam = (parseIntSafe(val, 0) == 1);
                break;
            case Et5PropertyCatalog.PROP_HIGH_BEAM:
                state.highBeam = (parseIntSafe(val, 0) == 1);
                break;
            case Et5PropertyCatalog.PROP_REAR_FOG:
                state.fogLight = (parseIntSafe(val, 0) == 1);
                break;
            case Et5PropertyCatalog.PROP_DOOR_STATES_ARRAY: {
                int[] arr = parseIntArray(val);
                if (arr.length >= 4) {
                    state.doorsOpen[0] = arr[0] == 1;
                    state.doorsOpen[1] = arr[1] == 1;
                    state.doorsOpen[2] = arr[2] == 1;
                    state.doorsOpen[3] = arr[3] == 1;
                }
                if (arr.length >= 5) state.trunkOpen = arr[4] == 1;
                if (arr.length >= 6) state.hoodOpen = arr[5] == 1;
                break;
            }
            case Et5PropertyCatalog.PROP_EXT_LIGHTS_ARRAY: {
                int[] arr = parseIntArray(val);
                if (arr.length >= 8) {
                    state.lowBeam = arr[0] == 1;
                    state.highBeam = arr[1] == 1;
                    state.fogLight = (arr[2] == 1 || arr[3] == 1);
                    state.turnLeft = arr[5] == 1;
                    state.turnRight = arr[6] == 1;
                    state.hazardLights = arr[7] == 1;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_BRAKE_PEDAL:
                state.brakeLight = (parseIntSafe(val, 0) > 0);
                break;
            case Et5PropertyCatalog.PROP_TURN_SIGNAL_STATE: {
                int ts = parseIntSafe(val, 0);
                state.turnLeft = (ts == 1 || ts == 3);
                state.turnRight = (ts == 2 || ts == 3);
                break;
            }
            case Et5PropertyCatalog.PROP_RADAR_FRONT_DIST:
                decodeRadarArray(val, state.radarFront);
                break;
            case Et5PropertyCatalog.PROP_RADAR_REAR_DIST:
                decodeRadarArray(val, state.radarRear);
                break;
            case Et5PropertyCatalog.PROP_SEAT_POS_4D: {
                int[] arr = parseIntArray(val);
                for (int i = 0; i < Math.min(4, arr.length); i++) {
                    if (arr[i] >= 1 && arr[i] <= 101) {
                        state.seatPos4D[i] = arr[i] - 1;
                    }
                }
                break;
            }
            case Et5PropertyCatalog.PROP_MIRROR_POS_4D: {
                int[] arr = parseIntArray(val);
                for (int i = 0; i < Math.min(4, arr.length); i++) {
                    if (arr[i] >= 1 && arr[i] <= 101) {
                        state.mirrorPos4D[i] = arr[i] - 1;
                    }
                }
                break;
            }
            case Et5PropertyCatalog.PROP_TIRE_PRESSURE_TEMP: {
                // Mg0.java: 8 ints [p0..p3, t0..t3], pressure = raw * 0.025f bar, temp = raw - 50 C
                int[] arr = parseIntArray(val);
                if (arr.length >= 8) {
                    for (int i = 0; i < 4; i++) {
                        int rawP = arr[i];
                        int rawT = arr[i + 4];
                        state.tirePressuresBar[i] = (rawP > 0 && rawP < 250) ? (rawP * 0.025f) : Float.NaN;
                        state.tireTempsC[i] = (rawT > 0 && rawT < 250) ? (float) (rawT - 50) : Float.NaN;
                    }
                }
                break;
            }
            case Et5PropertyCatalog.PROP_ODOMETER_KM: {
                float odo = parseFloatSafe(val, Float.NaN);
                if (!Float.isNaN(odo) && odo >= 0f && odo < 2000000f) {
                    state.odometerKm = odo;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_TOTAL_DISCHARGE_KWH: {
                float dis = parseFloatSafe(val, Float.NaN);
                if (!Float.isNaN(dis) && dis >= 0f) {
                    state.totalDischargeKwh = dis;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_CONSUMPTION_KWH: {
                int raw = parseIntSafe(val, -1);
                if (raw >= 0 && raw < 1000) {
                    state.avgConsumptionKwh = raw * 0.1f;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_BATTERY_POWER_KW: {
                int raw = parseIntSafe(val, -1);
                if (raw >= 0 && raw <= 20000) {
                    state.powerKw = raw * 0.1f - 1000.0f;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_WINDOW_POS_ARRAY: {
                int[] arr = parseIntArray(val);
                for (int i = 0; i < Math.min(4, arr.length); i++) {
                    state.windowPercent[i] = Math.max(0, Math.min(100, arr[i]));
                    state.windowsOpen[i] = arr[i] > 5;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_SUNROOF_POS: {
                int pos = parseIntSafe(val, 0);
                state.sunroofPercent = Math.max(0, Math.min(100, pos));
                state.sunroofOpen = (pos > 5);
                break;
            }
            case Et5PropertyCatalog.PROP_STEERING_WHEEL_KEY: {
                // Steering wheel voice key
                if (val.contains("231") || val.contains("VOICE")) {
                    mainHandler.post(() -> {
                        for (StateListener l : listeners) {
                            l.onSteeringVoiceButtonPressed();
                        }
                    });
                }
                break;
            }
            default:
                break;
        }

        boolean nowReverse = "R".equals(state.gear);
        if (nowReverse != prevReverse) {
            final boolean rev = nowReverse;
            if (rev) {
                AdbRootBridge.stopSkyworthEvsService(context);
            }
            mainHandler.post(() -> {
                for (StateListener l : listeners) {
                    l.onReverseGearChanged(rev);
                }
            });
        }
        notifyStateChanged();
    }

    private void decodeRadarArray(String val, float[] target) {
        int[] raw = parseIntArray(val);
        for (int i = 0; i < target.length; i++) {
            if (i < raw.length && raw[i] > 0 && raw[i] < 250) {
                target[i] = raw[i] / 100.0f;
            } else {
                target[i] = Float.NaN;
            }
        }
    }

    // ======================== COMMAND TRANSPORT (127.0.0.1:8724) ========================

    public String sendHelperCommand(String cmd) {
        synchronized (cmdLock) {
            for (int attempt = 0; attempt < 2; attempt++) {
                try {
                    if (cmdSocket == null || cmdSocket.isClosed() || !cmdSocket.isConnected()) {
                        cmdSocket = new Socket();
                        cmdSocket.connect(new InetSocketAddress("127.0.0.1", AracYardimci.PORT), 1000);
                        cmdSocket.setSoTimeout(2500);
                        cmdSocket.setTcpNoDelay(true);
                        cmdIn = new BufferedReader(new InputStreamReader(cmdSocket.getInputStream(), StandardCharsets.UTF_8));
                        cmdOut = new PrintWriter(new OutputStreamWriter(cmdSocket.getOutputStream(), StandardCharsets.UTF_8), true);
                        cmdOut.println("AUTH " + AdbRootBridge.LOCAL_AUTH_KEY);
                        if (!"OK".equals(cmdIn.readLine())) {
                            closeCmdSocket();
                            continue;
                        }
                    }
                    cmdOut.println(cmd);
                    String resp = cmdIn.readLine();
                    if (resp != null) return resp;
                    closeCmdSocket();
                } catch (Throwable t) {
                    closeCmdSocket();
                }
            }
            return null;
        }
    }

    private void closeCmdSocket() {
        try {
            if (cmdSocket != null) cmdSocket.close();
        } catch (Throwable ignored) {
        }
        cmdSocket = null;
        cmdIn = null;
        cmdOut = null;
    }

    public String getPropertyRaw(int propId, int areaId) {
        String direct = AracYardimci.readCarPropertyFormatted(propId, areaId);
        if (direct != null) return direct;
        String resp = sendHelperCommand(String.format(Locale.US, "GET 0x%08x %d", propId, areaId));
        if (resp != null && resp.startsWith("VAL ")) {
            return resp.substring(4).trim();
        }
        return null;
    }

    public boolean setProperty(int propId, int areaId, String type, String value) {
        boolean directOk = AracYardimci.writeCarProperty(propId, areaId, type, value);
        String resp = sendHelperCommand(String.format(Locale.US, "SET 0x%08x %d %s %s", propId, areaId, type, value));
        boolean socketOk = "OK".equals(resp);
        return directOk || socketOk;
    }

    public void writeAiDatabase(String table, String column, int value) {
        ioPool.execute(() -> {
            try {
                ContentValues cv = new ContentValues();
                cv.put(column, value);
                Uri uri = Uri.parse(Et5PropertyCatalog.URI_AISETTINGS_BASE + table);
                context.getContentResolver().update(uri, cv, null, null);
            } catch (Throwable ignored) {
            }
            sendHelperCommand("AI_DB " + table + " " + column + " " + value);
            sendHelperCommand("PREF " + table + " " + column + " " + value);
        });
    }

    // ======================== HIGH-LEVEL REAL VEHICLE CONTROLS ========================

    // 1. HVAC & Climate (C0227Hf.java + d4.smali)
    public void setHvacPower(boolean on) {
        state.hvacPower = on;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_POWER_ON, Et5PropertyCatalog.AREA_HVAC_ALL, "b", on ? "true" : "false"));
    }

    public void setHvacTemperature(float tempC) {
        final float clamped = Math.max(16.0f, Math.min(32.0f, Math.round(tempC * 2.0f) / 2.0f));
        state.hvacTargetTemp = clamped;
        state.hvacPower = true;
        notifyStateChanged();
        ioPool.execute(() -> {
            float carPropTemp = clamped;
            if (clamped <= 16.0f) carPropTemp = 15.5f;
            else if (clamped >= 32.0f) carPropTemp = 32.5f;
            setProperty(Et5PropertyCatalog.PROP_HVAC_POWER_ON, Et5PropertyCatalog.AREA_HVAC_ALL, "b", "true");
            setProperty(Et5PropertyCatalog.PROP_HVAC_TEMP_SET, Et5PropertyCatalog.AREA_HVAC_ALL, "f", String.valueOf(carPropTemp));
            sendHelperCommand(String.format(Locale.US, "HVAC_TEMP_SET %.1f", clamped));
            try {
                int raw = (clamped <= 16.0f) ? 155 : (clamped >= 32.0f ? 325 : Math.round(clamped * 2.0f) * 5);
                ContentValues cv = new ContentValues();
                cv.put("lefttemp", raw);
                cv.put("righttemp", raw);
                context.getContentResolver().update(URI_SKYHVAC_TEMP, cv, null, null);
            } catch (Throwable ignored) {
            }
        });
    }

    public void setHvacFanSpeed(int speed) {
        if (speed <= 0) {
            setHvacPower(false);
            return;
        }
        final int clamped = Math.max(1, Math.min(7, speed));
        state.hvacPower = true;
        state.hvacFanSpeed = clamped;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_HVAC_POWER_ON, Et5PropertyCatalog.AREA_HVAC_ALL, "b", "true");
            setProperty(Et5PropertyCatalog.PROP_HVAC_FAN_SPEED, Et5PropertyCatalog.AREA_HVAC_ALL, "i", String.valueOf(clamped));
        });
    }

    public void setHvacAc(boolean on) {
        state.hvacAc = on;
        if (on) state.hvacPower = true;
        notifyStateChanged();
        ioPool.execute(() -> {
            if (on) setProperty(Et5PropertyCatalog.PROP_HVAC_POWER_ON, Et5PropertyCatalog.AREA_HVAC_ALL, "b", "true");
            setProperty(Et5PropertyCatalog.PROP_HVAC_AC_ON, Et5PropertyCatalog.AREA_HVAC_ALL, "b", on ? "true" : "false");
        });
    }

    public void setHvacAuto(boolean on) {
        state.hvacAuto = on;
        if (on) state.hvacPower = true;
        notifyStateChanged();
        ioPool.execute(() -> {
            if (on) setProperty(Et5PropertyCatalog.PROP_HVAC_POWER_ON, Et5PropertyCatalog.AREA_HVAC_ALL, "b", "true");
            setProperty(Et5PropertyCatalog.PROP_HVAC_AUTO_ON, Et5PropertyCatalog.AREA_HVAC_ALL, "b", on ? "true" : "false");
        });
    }

    public void setHvacRecirc(boolean on) {
        state.hvacRecirc = on;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_RECIRC_ON, Et5PropertyCatalog.AREA_HVAC_ALL, "b", on ? "true" : "false"));
    }

    public void setHvacFrontDefrost(boolean on) {
        state.hvacFrontDefrost = on;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_HVAC_DEFROSTER, 1, "b", on ? "true" : "false");
            setProperty(Et5PropertyCatalog.PROP_HVAC_MAX_DEFROST_ON, Et5PropertyCatalog.AREA_HVAC_ALL, "b", on ? "true" : "false");
        });
    }

    public void setHvacRearDefrost(boolean on) {
        state.hvacRearDefrost = on;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_DEFROSTER, 2, "b", on ? "true" : "false"));
    }

    // 2. Seats & Mirrors (C0227Hf.java: heat & vent mutual exclusion)
    public void setSeatHeating(boolean isDriver, int level) {
        final int clamped = Math.max(0, Math.min(3, level));
        final int area = isDriver ? Et5PropertyCatalog.AREA_SEAT_DRIVER : Et5PropertyCatalog.AREA_SEAT_PASSENGER;
        if (isDriver) {
            state.driverSeatHeat = clamped;
            if (clamped > 0) state.driverSeatVent = 0;
        } else {
            state.passengerSeatHeat = clamped;
            if (clamped > 0) state.passengerSeatVent = 0;
        }
        notifyStateChanged();
        ioPool.execute(() -> {
            if (clamped > 0) {
                int ventProp = isDriver ? Et5PropertyCatalog.PROP_DRIVER_SEAT_VENT : Et5PropertyCatalog.PROP_PASSENGER_SEAT_VENT;
                setProperty(ventProp, 0, "i", "0");
            }
            setProperty(Et5PropertyCatalog.PROP_HVAC_SEAT_TEMPERATURE, area, "i", String.valueOf(clamped));
        });
    }

    public void setSeatVentilation(boolean isDriver, int level) {
        final int clamped = Math.max(0, Math.min(3, level));
        final int area = isDriver ? Et5PropertyCatalog.AREA_SEAT_DRIVER : Et5PropertyCatalog.AREA_SEAT_PASSENGER;
        final int ventProp = isDriver ? Et5PropertyCatalog.PROP_DRIVER_SEAT_VENT : Et5PropertyCatalog.PROP_PASSENGER_SEAT_VENT;
        if (isDriver) {
            state.driverSeatVent = clamped;
            if (clamped > 0) state.driverSeatHeat = 0;
        } else {
            state.passengerSeatVent = clamped;
            if (clamped > 0) state.passengerSeatHeat = 0;
        }
        notifyStateChanged();
        ioPool.execute(() -> {
            if (clamped > 0) {
                setProperty(Et5PropertyCatalog.PROP_HVAC_SEAT_TEMPERATURE, area, "i", "0");
            }
            setProperty(ventProp, 0, "i", String.valueOf(clamped));
        });
    }

    public void setDriverSeat4D(int horiz, int vert, int backrest, int tilt) {
        state.seatPos4D[0] = Math.max(0, Math.min(100, horiz));
        state.seatPos4D[1] = Math.max(0, Math.min(100, vert));
        state.seatPos4D[2] = Math.max(0, Math.min(100, backrest));
        state.seatPos4D[3] = Math.max(0, Math.min(100, tilt));
        notifyStateChanged();
        ioPool.execute(() -> {
            String ia = (state.seatPos4D[0] + 1) + "," + (state.seatPos4D[1] + 1) + ","
                    + (state.seatPos4D[2] + 1) + "," + (state.seatPos4D[3] + 1);
            setProperty(Et5PropertyCatalog.PROP_SEAT_POS_4D, 0, "ia", ia);
        });
    }

    public void applySeatMemorySlot(int slot1To3) {
        final int s = Math.max(1, Math.min(3, slot1To3));
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_DRIVER_SEAT_MEM, 0, "i", String.valueOf(s)));
    }

    public void setSeatRestMode(boolean on) {
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_SEAT_REST_MODE, 0, "i", on ? "1" : "2"));
    }

    public void foldMirrors(boolean fold) {
        state.mirrorsFolded = fold;
        notifyStateChanged();
        writeAiDatabase("mirror", "fold", fold ? 1 : 0);
    }

    // 3. Locks, Trunk, Windows, Sunroof, Charge Port (C0227Hf.java)
    public void setDoorLocks(boolean lock) {
        state.locked = lock;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_DOOR_LOCK, 0, "i", lock ? "2" : "1"));
    }

    public void setPowerTrunk(boolean open) {
        state.trunkOpen = open;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_TRUNK_COMMAND, 0, "i", open ? "1" : "2");
            writeAiDatabase("trunk", "open", open ? 1 : 0);
        });
    }

    public void setChargePort(boolean open) {
        state.chargePortOpen = open;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_CHARGE_PORT, 0, "i", open ? "1" : "2"));
    }

    public void controlAllWindows(int mode) {
        // mode: 1=Close, 2=Open, 3=Ventilate (20%)
        int targetPct = (mode == 2) ? 100 : (mode == 3 ? 20 : 0);
        for (int i = 0; i < 4; i++) {
            state.windowPercent[i] = targetPct;
            state.windowsOpen[i] = targetPct > 5;
        }
        notifyStateChanged();
        ioPool.execute(() -> {
            String arr = targetPct + "," + targetPct + "," + targetPct + "," + targetPct;
            setProperty(Et5PropertyCatalog.PROP_WINDOW_POS_ARRAY, 0, "ia", arr);
            writeAiDatabase("window", "ventilate", mode == 3 ? 1 : 0);
        });
    }

    public void setSunroofPercent(int pct0To100) {
        final int clamped = Math.max(0, Math.min(100, pct0To100));
        state.sunroofPercent = clamped;
        state.sunroofOpen = clamped > 5;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_SUNROOF_POS, 0, "i", String.valueOf(clamped)));
    }

    public void setSunroof(boolean open) {
        setSunroofPercent(open ? 100 : 0);
    }

    // 4. Drive Mode, Regen, Steering, Auto Hold, ESC (C0227Hf.java)
    public void setDriveMode(int mode0Normal1Eco2Sport) {
        final int m = Math.max(0, Math.min(2, mode0Normal1Eco2Sport));
        state.driveMode = m;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_DRIVE_MODE, 0, "i", String.valueOf(m));
            writeAiDatabase("energy", "mode", m);
        });
    }

    public void setRegenPercent(int pct0To100) {
        final int clamped = Math.max(0, Math.min(100, pct0To100));
        state.regenPercent = clamped;
        notifyStateChanged();
        writeAiDatabase("recovery", "comfort", clamped);
    }

    public void setSteeringMode(int mode0Comfort1Std2Sport) {
        final int clamped = Math.max(0, Math.min(2, mode0Comfort1Std2Sport));
        state.steeringMode = clamped;
        notifyStateChanged();
        writeAiDatabase("steering", "mode", clamped);
    }

    public void setAutoHold(boolean on) {
        state.autoHold = on;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_AUTO_HOLD, 0, "i", on ? "1" : "0");
            writeAiDatabase("brake", "autohold", on ? 1 : 0);
        });
    }

    public void setEscEnabled(boolean enabled) {
        state.escEnabled = enabled;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_ESC_OFF, 0, "i", enabled ? "0" : "1");
            writeAiDatabase("brake", "esc", enabled ? 1 : 0);
        });
    }

    // 5. Charging & 220V V2L Discharge
    public void setChargeLimit(int limitPercent) {
        final int clamped = Math.max(50, Math.min(100, limitPercent));
        state.chargeLimitPercent = clamped;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_CHARGE_LIMIT_ARRAY, 0, "ia", "1," + clamped);
            writeAiDatabase("energy", "charge_limit", clamped);
        });
    }

    public void setV2lDischargeLimit(int limitPercent) {
        final int clamped = Math.max(15, Math.min(80, limitPercent));
        state.v2lDischargeLimit = clamped;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_DISCHARGE_LIMIT, 0, "i", String.valueOf(clamped));
            writeAiDatabase("discharge", "limit", clamped);
        });
    }

    // 6. Ambient Light & Instrument Cluster
    public void setAmbientLight(boolean enabled, int colorIdx0To127, int brightness0To100) {
        state.ambientEnabled = enabled;
        state.ambientColorIndex = Math.max(0, Math.min(127, colorIdx0To127));
        state.ambientBrightness = Math.max(0, Math.min(100, brightness0To100));
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_AMBIENT_COLOR, 0, "i", String.valueOf(state.ambientColorIndex));
            setProperty(Et5PropertyCatalog.PROP_AMBIENT_BRIGHTNESS, 0, "i", String.valueOf(enabled ? state.ambientBrightness : 0));
            writeAiDatabase("ambientlight", "switch", enabled ? 1 : 0);
            writeAiDatabase("ambientlight", "color", state.ambientColorIndex);
            writeAiDatabase("ambientlight", "brightness", state.ambientBrightness);
        });
    }

    public void setClusterTheme(int theme0Classic1Road) {
        state.clusterTheme = theme0Classic1Road;
        notifyStateChanged();
        ioPool.execute(() -> sendHelperCommand("DASH theme " + theme0Classic1Road));
    }

    public void setClusterBrightness(int level1To100) {
        state.clusterBrightness = Math.max(1, Math.min(100, level1To100));
        notifyStateChanged();
        ioPool.execute(() -> sendHelperCommand("DASH brightness " + state.clusterBrightness));
    }

    public void sendMediaInfoToCluster(boolean playing, String title, String artist) {
        ioPool.execute(() -> {
            String t = title != null ? title : "";
            String a = artist != null ? artist : "";
            String b64Title = Base64.encodeToString(t.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            String b64Artist = Base64.encodeToString(a.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            sendHelperCommand("MUSIC " + (playing ? 1 : 2) + " " + b64Title + " " + b64Artist);
        });
    }

    // 7. Special Modes (Camp, Pet, Car Wash)
    public void setCampMode(boolean enabled) {
        state.campMode = enabled;
        if (enabled) {
            state.petMode = false;
            setHvacTemperature(22.0f);
            setHvacAuto(true);
        }
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_CAMP_MODE, 0, "i", enabled ? "1" : "0"));
    }

    public void setPetMode(boolean enabled) {
        state.petMode = enabled;
        if (enabled) {
            state.campMode = false;
            setHvacTemperature(21.0f);
            setHvacAc(true);
            controlAllWindows(1);
            setDoorLocks(true);
        }
        notifyStateChanged();
    }

    public void setCarWashMode(boolean enabled) {
        state.carWashMode = enabled;
        if (enabled) {
            controlAllWindows(1);
            setSunroof(false);
            foldMirrors(true);
            setDoorLocks(true);
            setHvacRecirc(true);
            setChargePort(false);
        }
        notifyStateChanged();
    }

    public void adjustSystemVolume(int delta) {
        try {
            AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                        delta > 0 ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI);
            }
        } catch (Throwable ignored) {
        }
    }

    // ======================== PARSERS ========================

    private static int parseIntSafe(String s, int def) {
        try {
            return (int) Float.parseFloat(s.trim().split(",")[0]);
        } catch (Throwable t) {
            return def;
        }
    }

    private static float parseFloatSafe(String s, float def) {
        try {
            return Float.parseFloat(s.trim().split(",")[0]);
        } catch (Throwable t) {
            return def;
        }
    }

    private static boolean parseBoolSafe(String s) {
        if (s == null) return false;
        String t = s.trim();
        return "true".equalsIgnoreCase(t) || "1".equals(t) || "1.0".equals(t);
    }

    private static int[] parseIntArray(String csv) {
        try {
            String[] parts = csv.trim().split(",");
            int[] res = new int[parts.length];
            for (int i = 0; i < parts.length; i++) {
                res[i] = (int) Float.parseFloat(parts[i].trim());
            }
            return res;
        } catch (Throwable t) {
            return new int[0];
        }
    }
}
