package tr.halil.et5.car;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import tr.halil.et5.helper.AdbRootBridge;
import tr.halil.et5.helper.AracYardimci;

/**
 * Master Vehicle Controller for 2023 Skywell ET5 (Skyworth EV6).
 * Combines:
 *  1) Direct android.car.Car (CarPropertyManager) in-process access
 *  2) AracYardimci UID 1000 TCP socket client (127.0.0.1:8724: GET, SET, WATCH, DASH, DASHGET, MUSIC, PREF)
 *  3) ContentProvider observers (skyhvac airconditioner & aisettings energy recovery)
 */
public final class VehicleController {

    private static final String TAG = "Et5VehicleCtrl";
    public static final Uri URI_SKYHVAC = Uri.parse("content://com.coolwell.ai.skyhvac.database/airconditioner");
    public static final Uri URI_RECOVERY = Uri.parse("content://com.skyworth.car.aisettings.vehiclecontrol.database/recovery");

    public interface StateListener {
        void onVehicleStateChanged(VehicleState state);
        void onReverseGearChanged(boolean inReverse);
    }

    private final Context context;
    private final VehicleState state = new VehicleState();
    private final List<StateListener> listeners = new CopyOnWriteArrayList<>();
    private final ExecutorService ioPool = Executors.newCachedThreadPool();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private Socket cmdSocket;
    private BufferedReader cmdIn;
    private PrintWriter cmdOut;
    private final Object cmdLock = new Object();
    private volatile boolean running = false;

    public VehicleController(Context context) {
        this.context = context.getApplicationContext();
    }

    public VehicleState getState() {
        return state;
    }

    public void addListener(StateListener l) {
        if (!listeners.contains(l)) {
            listeners.add(l);
        }
    }

    public void removeListener(StateListener l) {
        listeners.remove(l);
    }

    public void notifyStateChanged() {
        mainHandler.post(() -> {
            for (StateListener l : listeners) {
                l.onVehicleStateChanged(state);
            }
        });
    }

    public void start() {
        if (running) return;
        running = true;

        registerContentObservers();

        // Thread 1: Bootstrap AracYardimci & maintain WATCH stream on 127.0.0.1:8724
        Thread watchThread = new Thread(this::watchLoop, "et5-watch-loop");
        watchThread.setDaemon(true);
        watchThread.start();

        // Thread 2: Periodic poll of settings, volume, seats, mirrors, and cluster state
        Thread pollThread = new Thread(this::pollLoop, "et5-poll-loop");
        pollThread.setDaemon(true);
        pollThread.start();
    }

    private void registerContentObservers() {
        try {
            ContentResolver cr = context.getContentResolver();
            cr.registerContentObserver(URI_SKYHVAC, true, new ContentObserver(mainHandler) {
                @Override
                public void onChange(boolean selfChange) {
                    ioPool.execute(() -> readSkyHvacProvider());
                }
            });
            cr.registerContentObserver(URI_RECOVERY, true, new ContentObserver(mainHandler) {
                @Override
                public void onChange(boolean selfChange) {
                    ioPool.execute(() -> readRecoveryProvider());
                }
            });
        } catch (Throwable ignored) {}
    }

    private void readSkyHvacProvider() {
        try (Cursor c = context.getContentResolver().query(URI_SKYHVAC, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int valIdx = c.getColumnIndex("value");
                if (valIdx >= 0) {
                    notifyStateChanged();
                }
            }
        } catch (Throwable ignored) {}
    }

    private void readRecoveryProvider() {
        try (Cursor c = context.getContentResolver().query(URI_RECOVERY, new String[]{"comfort"}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int val = c.getInt(0);
                if (val >= 0 && val <= 100) {
                    state.regenPercent = val;
                    state.settings.put("geri_kazanim", val);
                    notifyStateChanged();
                }
            }
        } catch (Throwable ignored) {}
    }

    private void watchLoop() {
        while (running) {
            try {
                boolean started = AdbRootBridge.ensureHelperStarted(context);
                state.helperStatus = started ? "Bağlı (UID 1000 / CarAPI)" : "Yerel Mod";
                notifyStateChanged();

                try (Socket watchSock = new Socket()) {
                    watchSock.connect(new InetSocketAddress("127.0.0.1", AracYardimci.PORT), 2000);
                    watchSock.setSoTimeout(0);
                    BufferedReader in = new BufferedReader(new InputStreamReader(watchSock.getInputStream(), StandardCharsets.UTF_8));
                    PrintWriter out = new PrintWriter(new OutputStreamWriter(watchSock.getOutputStream(), StandardCharsets.UTF_8), true);

                    out.println("AUTH " + AdbRootBridge.LOCAL_AUTH_KEY);
                    if (!"OK".equals(in.readLine())) {
                        Thread.sleep(2000);
                        continue;
                    }

                    StringBuilder watchCmd = new StringBuilder("WATCH");
                    for (String spec : Et5PropertyCatalog.WATCHED_SPEC_LIST) {
                        watchCmd.append(" ").append(spec);
                    }
                    out.println(watchCmd.toString());
                    if (!"OK".equals(in.readLine())) {
                        Thread.sleep(2000);
                        continue;
                    }

                    state.helperSocketConnected = true;
                    state.helperStatus = "Bağlı (Canlı Veri Akışı)";
                    notifyStateChanged();

                    String line;
                    while (running && (line = in.readLine()) != null) {
                        if (line.startsWith("EVT ")) {
                            parseWatchEvent(line);
                        }
                    }
                }
            } catch (Throwable t) {
                state.helperSocketConnected = false;
                try {
                    Thread.sleep(2500);
                } catch (InterruptedException ignored) {}
            }
        }
    }

    private void pollLoop() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ignored) {}
        syncInitialVehicleState();
        while (running) {
            try {
                AdbRootBridge.preventStockLauncherMediaKeys(context);
                readRecoveryProvider();
                Thread.sleep(4000);
            } catch (Throwable ignored) {}
        }
    }

    public void syncInitialVehicleState() {
        ioPool.execute(() -> {
            // Read VIN
            String vin = getPropertyRaw(Et5PropertyCatalog.PROP_VIN, 0);
            if (vin != null && !vin.isEmpty() && !"null".equals(vin)) {
                state.vin = vin.trim();
            }
            // Read Audio Channel & Volume
            Integer ch = getPropertyInt(Et5PropertyCatalog.PROP_AUDIO_CHANNEL, 0);
            if (ch != null) state.audioChannel = ch;
            Integer vol = getPropertyInt(Et5PropertyCatalog.PROP_AUDIO_VOLUME, state.audioChannel);
            if (vol != null && vol >= 0 && vol <= 40) state.masterVolume = vol;

            // Read Seats & Mirrors
            Integer sFa = getPropertyInt(Et5PropertyCatalog.PROP_SEAT_FORE_AFT, 1);
            if (sFa != null) state.seatForeAft = sFa;
            Integer sH = getPropertyInt(Et5PropertyCatalog.PROP_SEAT_HEIGHT, 1);
            if (sH != null) state.seatHeight = sH;
            Integer sT = getPropertyInt(Et5PropertyCatalog.PROP_SEAT_TILT, 1);
            if (sT != null) state.seatTilt = sT;
            Integer sFoot = getPropertyInt(Et5PropertyCatalog.PROP_SEAT_FOOTREST, 1);
            if (sFoot != null) state.seatFootrest = sFoot;

            // Read Dash Cluster settings
            String dashResp = sendHelperCommand("DASHGET");
            if (dashResp != null && dashResp.startsWith("OK ")) {
                String[] parts = dashResp.substring(3).trim().split(",");
                if (parts.length >= 9) {
                    try {
                        state.clusterBrightness = Integer.parseInt(parts[0].trim());
                        state.clusterTone = Integer.parseInt(parts[1].trim());
                        state.clusterVolume = Integer.parseInt(parts[2].trim());
                        state.clusterNavDisplay = Integer.parseInt(parts[4].trim()) == 1;
                        state.clusterTheme = Integer.parseInt(parts[8].trim());
                    } catch (Throwable ignored) {}
                }
            }

            // Read all 37+ vehicle settings from CarPropertyManager
            for (Map.Entry<String, Et5PropertyCatalog.SettingSpec> entry : Et5PropertyCatalog.SETTINGS_MAP.entrySet()) {
                Et5PropertyCatalog.SettingSpec spec = entry.getValue();
                Integer raw = getPropertyInt(spec.propId, spec.areaId);
                if (raw != null) {
                    if (spec.isBool) {
                        boolean b = raw != 0;
                        if ("ayna_katla".equals(spec.key)) b = (raw == 1);
                        else if (spec.invertBool) b = !b;
                        state.settings.put(spec.key, b);
                    } else {
                        state.settings.put(spec.key, raw - spec.offset);
                    }
                }
            }
            notifyStateChanged();
        });
    }

    private void parseWatchEvent(String line) {
        try {
            // Format: EVT 0x<hexPropId> <areaId> <value>
            String[] parts = line.split("\\s+", 4);
            if (parts.length < 4) return;
            int propId = Integer.parseUnsignedInt(parts[1].substring(2), 16);
            int areaId = Integer.parseInt(parts[2]);
            String val = parts[3].trim();
            applyPropertyUpdate(propId, areaId, val);
        } catch (Throwable ignored) {}
    }

    public void applyPropertyUpdate(int propId, int areaId, String val) {
        if (val == null || val.isEmpty()) return;
        boolean prevReverse = "R".equals(state.gear);

        switch (propId) {
            case Et5PropertyCatalog.PROP_GEAR_SELECTION: {
                int g = parseIntSafe(val, 5);
                if (g == 1) { state.gear = "N"; state.autoHold = false; }
                else if (g == 2) { state.gear = "R"; state.autoHold = false; }
                else if (g == 3) { state.gear = "D"; state.autoHold = false; }
                else if (g == 4) { state.gear = "D"; state.autoHold = true; }
                else if (g == 5) { state.gear = "P"; state.autoHold = false; }
                break;
            }
            case Et5PropertyCatalog.PROP_GEAR_ALT: {
                int g = parseIntSafe(val, 0);
                if (g == 2) state.gear = "R";
                break;
            }
            case Et5PropertyCatalog.PROP_SPEED_KMH: {
                float spd = parseFloatSafe(val, 0f);
                if (spd >= 0f) state.speedKmh = Math.round(spd);
                break;
            }
            case Et5PropertyCatalog.PROP_SPEED_MS: {
                float ms = parseFloatSafe(val, 0f);
                if (ms >= 0f) state.speedKmh = Math.round(ms * 3.6f);
                break;
            }
            case Et5PropertyCatalog.PROP_BATTERY_SOC: {
                float soc = parseFloatSafe(val, state.socPercent);
                if (soc > 0f && soc <= 100f) state.socPercent = Math.round(soc);
                break;
            }
            case Et5PropertyCatalog.PROP_RANGE_KM:
            case Et5PropertyCatalog.PROP_RANGE_KM_ALT: {
                float r = parseFloatSafe(val, state.rangeKm);
                if (r > 0f) state.rangeKm = Math.round(r);
                break;
            }
            case Et5PropertyCatalog.PROP_ODOMETER_KM: {
                float odo = parseFloatSafe(val, state.odometerKm);
                if (odo > 0f) state.odometerKm = odo;
                break;
            }
            case Et5PropertyCatalog.PROP_TRIP_KM: {
                float tr = parseFloatSafe(val, state.tripKm);
                if (tr >= 0f) state.tripKm = tr;
                break;
            }
            case Et5PropertyCatalog.PROP_AVG_CONSUMPTION: {
                float c = parseFloatSafe(val, state.avgConsumptionKwh);
                if (c >= 1.0f && c <= 60.0f) state.avgConsumptionKwh = c;
                break;
            }
            case Et5PropertyCatalog.PROP_HV_VOLTAGE: {
                float v = parseFloatSafe(val, state.hvVoltage);
                if (v > 50.0f) {
                    state.hvVoltage = v;
                    state.powerKw = (state.hvVoltage * state.hvCurrent) / 1000.0f;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_HV_CURRENT: {
                float a = parseFloatSafe(val, state.hvCurrent);
                if (a > 400.0f) a -= 600.0f; // Skywell offset handling
                state.hvCurrent = a;
                state.powerKw = (state.hvVoltage * state.hvCurrent) / 1000.0f;
                break;
            }
            case Et5PropertyCatalog.PROP_BATTERY_12V: {
                int v12 = parseIntSafe(val, state.battery12v);
                if (v12 >= 5 && v12 < 200) state.battery12v = v12;
                break;
            }
            case Et5PropertyCatalog.PROP_TURN_SIGNAL: {
                int ts = parseIntSafe(val, 0);
                state.turnRight = (ts == 1 || ts == 3 || state.hazardLights);
                state.turnLeft = (ts == 2 || ts == 3 || state.hazardLights);
                break;
            }
            case Et5PropertyCatalog.PROP_HAZARD_LIGHTS: {
                state.hazardLights = parseIntSafe(val, 0) != 0;
                if (state.hazardLights) {
                    state.turnLeft = true;
                    state.turnRight = true;
                }
                break;
            }
            case Et5PropertyCatalog.PROP_BRAKE_LIGHT:
                state.brakeLight = parseIntSafe(val, 0) == 1;
                break;
            case Et5PropertyCatalog.PROP_LOW_BEAM:
                state.lowBeam = parseIntSafe(val, 0) == 1;
                break;
            case Et5PropertyCatalog.PROP_HIGH_BEAM:
                state.highBeam = parseIntSafe(val, 0) == 1;
                break;
            case Et5PropertyCatalog.PROP_FOG_LIGHT:
                state.fogLight = parseIntSafe(val, 0) == 1;
                break;
            case Et5PropertyCatalog.PROP_RADAR_FRONT:
                parseFloatArrayInto(val, state.radarFront);
                break;
            case Et5PropertyCatalog.PROP_RADAR_REAR:
                parseFloatArrayInto(val, state.radarRear);
                if (Build.VERSION.SDK_INT < 29 && state.radarRear.length >= 4) {
                    float t0 = state.radarRear[0], t1 = state.radarRear[1];
                    state.radarRear[0] = state.radarRear[3];
                    state.radarRear[1] = state.radarRear[2];
                    state.radarRear[2] = t1;
                    state.radarRear[3] = t0;
                }
                break;
            case Et5PropertyCatalog.PROP_RADAR_SIDE:
                parseFloatArrayInto(val, state.radarSide);
                break;
            case Et5PropertyCatalog.PROP_TIRE_PRESSURES:
                parseFloatArrayInto(val, state.tirePressuresBar);
                if (state.tirePressuresBar.length >= 4) {
                    float swap = state.tirePressuresBar[2];
                    state.tirePressuresBar[2] = state.tirePressuresBar[3];
                    state.tirePressuresBar[3] = swap;
                }
                break;
            case Et5PropertyCatalog.PROP_HVAC_POWER:
                state.hvacPower = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_TARGET_TEMP:
                state.hvacTargetTemp = parseFloatSafe(val, state.hvacTargetTemp);
                break;
            case Et5PropertyCatalog.PROP_HVAC_FAN_SPEED:
                state.hvacFanSpeed = parseIntSafe(val, state.hvacFanSpeed);
                break;
            case Et5PropertyCatalog.PROP_HVAC_AC:
                state.hvacAc = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_AUTO:
            case Et5PropertyCatalog.PROP_HVAC_AUTO_ALT:
                state.hvacAuto = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_RECIRC:
                state.hvacRecirc = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_DEFROST:
                if (areaId == 1) state.hvacFrontDefrost = parseBoolSafe(val);
                else if (areaId == 2) state.hvacRearDefrost = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_HVAC_CABIN_TEMP:
                state.cabinTempC = parseFloatSafe(val, state.cabinTempC);
                break;
            case Et5PropertyCatalog.PROP_HVAC_OUTSIDE_TEMP: {
                float outT = parseFloatSafe(val, state.outsideTempC);
                if (outT != 25.0f) state.outsideTempC = outT;
                break;
            }
            case Et5PropertyCatalog.PROP_SEAT_HEAT:
                if (areaId == 1) state.driverSeatHeat = parseIntSafe(val, 0);
                else if (areaId == 4) state.passengerSeatHeat = parseIntSafe(val, 0);
                break;
            case Et5PropertyCatalog.PROP_SEAT_VENT:
                if (areaId == 1) state.driverSeatVent = parseIntSafe(val, 0);
                else if (areaId == 4) state.passengerSeatVent = parseIntSafe(val, 0);
                break;
            case Et5PropertyCatalog.PROP_DOOR_TRUNK_HOOD_STATE: {
                boolean open = parseIntSafe(val, 0) != 0;
                if (areaId == Et5PropertyCatalog.AREA_TRUNK) state.trunkOpen = open;
                else if (areaId == Et5PropertyCatalog.AREA_HOOD) state.hoodOpen = open;
                else if (areaId == 1) state.doorsOpen[0] = open;
                else if (areaId == 4) state.doorsOpen[1] = open;
                else if (areaId == 16) state.doorsOpen[2] = open;
                else if (areaId == 64) state.doorsOpen[3] = open;
                break;
            }
            case Et5PropertyCatalog.PROP_WINDOW_POS: {
                boolean open = parseIntSafe(val, 0) > 2;
                if (areaId == 16) state.windowsOpen[0] = open;
                else if (areaId == 64) state.windowsOpen[1] = open;
                else if (areaId == 256) state.windowsOpen[2] = open;
                else if (areaId == 1024) state.windowsOpen[3] = open;
                break;
            }
            case Et5PropertyCatalog.PROP_LOCK_STATE:
                state.locked = parseBoolSafe(val);
                break;
            case Et5PropertyCatalog.PROP_CHARGE_CABLE:
                state.chargeCableConnected = parseIntSafe(val, 0) != 0;
                break;
            case Et5PropertyCatalog.PROP_CHARGE_STATUS:
            case Et5PropertyCatalog.PROP_CHARGE_INDICATOR:
                state.chargingActive = parseIntSafe(val, 0) == 1;
                break;
            case Et5PropertyCatalog.PROP_CHARGE_REMAINING_MIN:
                state.chargeRemainingMin = parseIntSafe(val, 0);
                break;
            default:
                break;
        }

        boolean nowReverse = "R".equals(state.gear);
        if (nowReverse != prevReverse) {
            final boolean rev = nowReverse;
            if (rev) {
                AdbRootBridge.stopSkyworthEvsService(context);
            }
            mainHandler.post(() -> {
                for (StateListener l : listeners) {
                    l.onReverseGearChanged(rev);
                }
            });
        }
        notifyStateChanged();
    }

    // ======================== LOW-LEVEL COMMAND TRANSPORT ========================

    public String sendHelperCommand(String cmd) {
        synchronized (cmdLock) {
            for (int attempt = 0; attempt < 2; attempt++) {
                try {
                    if (cmdSocket == null || cmdSocket.isClosed() || !cmdSocket.isConnected()) {
                        cmdSocket = new Socket();
                        cmdSocket.connect(new InetSocketAddress("127.0.0.1", AracYardimci.PORT), 1200);
                        cmdSocket.setSoTimeout(2500);
                        cmdIn = new BufferedReader(new InputStreamReader(cmdSocket.getInputStream(), StandardCharsets.UTF_8));
                        cmdOut = new PrintWriter(new OutputStreamWriter(cmdSocket.getOutputStream(), StandardCharsets.UTF_8), true);
                        cmdOut.println("AUTH " + AdbRootBridge.LOCAL_AUTH_KEY);
                        String authResp = cmdIn.readLine();
                        if (!"OK".equals(authResp)) {
                            closeCmdSocket();
                            continue;
                        }
                    }
                    cmdOut.println(cmd);
                    String resp = cmdIn.readLine();
                    if (resp != null) return resp;
                    closeCmdSocket();
                } catch (Throwable t) {
                    closeCmdSocket();
                }
            }
            return null;
        }
    }

    private void closeCmdSocket() {
        try {
            if (cmdSocket != null) cmdSocket.close();
        } catch (Throwable ignored) {}
        cmdSocket = null;
        cmdIn = null;
        cmdOut = null;
    }

    public String getPropertyRaw(int propId, int areaId) {
        String direct = AracYardimci.readCarPropertyFormatted(propId, areaId);
        if (direct != null) {
            state.directCarConnected = true;
            return direct;
        }
        String resp = sendHelperCommand("GET 0x" + Integer.toHexString(propId) + " " + areaId);
        if (resp != null && resp.startsWith("VAL ")) {
            return resp.substring(4).trim();
        }
        return null;
    }

    public Integer getPropertyInt(int propId, int areaId) {
        String raw = getPropertyRaw(propId, areaId);
        if (raw == null) return null;
        try {
            return (int) Float.parseFloat(raw.trim());
        } catch (Throwable t) {
            return null;
        }
    }

    public boolean setProperty(int propId, int areaId, String type, String value) {
        boolean directOk = AracYardimci.writeCarProperty(propId, areaId, type, value);
        String resp = sendHelperCommand("SET 0x" + Integer.toHexString(propId) + " " + areaId + " " + type + " " + value);
        boolean socketOk = "OK".equals(resp);
        applyPropertyUpdate(propId, areaId, value);
        return directOk || socketOk;
    }

    // ======================== HIGH-LEVEL VEHICLE CONTROLS ========================

    // 1. Climate / HVAC Controls
    public void setHvacPower(boolean on) {
        state.hvacPower = on;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_POWER, 0, "b", String.valueOf(on)));
    }

    public void setHvacTemperature(float tempC) {
        float clamped = Math.max(18.0f, Math.min(32.0f, Math.round(tempC * 2f) / 2f));
        state.hvacTargetTemp = clamped;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_TARGET_TEMP, 0, "f", String.valueOf(clamped)));
    }

    public void setHvacFanSpeed(int speed) {
        if (speed <= 0) {
            setHvacPower(false);
            return;
        }
        final int clamped = Math.max(1, Math.min(7, speed));
        state.hvacPower = true;
        state.hvacFanSpeed = clamped;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_HVAC_POWER, 0, "b", "true");
            setProperty(Et5PropertyCatalog.PROP_HVAC_FAN_SPEED, 0, "i", String.valueOf(clamped));
        });
    }

    public void setHvacAc(boolean on) {
        state.hvacAc = on;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_AC, 0, "b", String.valueOf(on)));
    }

    public void setHvacAuto(boolean on) {
        state.hvacAuto = on;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_AUTO, 0, "b", String.valueOf(on)));
    }

    public void setHvacRecirc(boolean on) {
        state.hvacRecirc = on;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_RECIRC, 0, "b", String.valueOf(on)));
    }

    public void setHvacFrontDefrost(boolean on) {
        state.hvacFrontDefrost = on;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_DEFROST, 1, "b", String.valueOf(on)));
    }

    public void setHvacRearDefrost(boolean on) {
        state.hvacRearDefrost = on;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_HVAC_DEFROST, 2, "b", String.valueOf(on)));
    }

    public void setHvacEco(boolean on) {
        state.hvacEco = on;
        notifyStateChanged();
        ioPool.execute(() -> {
            for (int area = 0; area <= 6; area++) {
                setProperty(Et5PropertyCatalog.PROP_HVAC_ECO_MUTE, area, "b", String.valueOf(on));
            }
        });
    }

    // 2. Seats & Mirrors (pg0.java, Yf0.java, Zf0.java)
    public void setSeatHeating(boolean isDriver, int level) {
        int clamped = Math.max(0, Math.min(3, level));
        int area = isDriver ? 1 : 4;
        if (isDriver) {
            state.driverSeatHeat = clamped;
            if (clamped > 0) state.driverSeatVent = 0;
        } else {
            state.passengerSeatHeat = clamped;
            if (clamped > 0) state.passengerSeatVent = 0;
        }
        notifyStateChanged();
        ioPool.execute(() -> {
            if (clamped > 0) {
                setProperty(Et5PropertyCatalog.PROP_SEAT_VENT, area, "i", "0");
            }
            setProperty(Et5PropertyCatalog.PROP_SEAT_HEAT, area, "i", String.valueOf(clamped));
        });
    }

    public void setSeatVentilation(boolean isDriver, int level) {
        int clamped = Math.max(0, Math.min(3, level));
        int area = isDriver ? 1 : 4;
        if (isDriver) {
            state.driverSeatVent = clamped;
            if (clamped > 0) state.driverSeatHeat = 0;
        } else {
            state.passengerSeatVent = clamped;
            if (clamped > 0) state.passengerSeatHeat = 0;
        }
        notifyStateChanged();
        ioPool.execute(() -> {
            if (clamped > 0) {
                setProperty(Et5PropertyCatalog.PROP_SEAT_HEAT, area, "i", "0");
            }
            setProperty(Et5PropertyCatalog.PROP_SEAT_VENT, area, "i", String.valueOf(clamped));
        });
    }

    public void moveDriverSeatPosition(int foreAft, int height, int tilt, int footrest) {
        state.seatForeAft = foreAft;
        state.seatHeight = height;
        state.seatTilt = tilt;
        state.seatFootrest = footrest;
        notifyStateChanged();
        ioPool.execute(() -> {
            String pkt = foreAft + "," + tilt + "," + height + ",0,0,0,0," + footrest;
            setProperty(Et5PropertyCatalog.PROP_SEAT_MEMORY_PACKET, 1, "ia", pkt);
        });
    }

    public void foldMirrors(boolean fold) {
        state.mirrorsFolded = fold;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_MIRROR_FOLD_CMD, 0, "i", fold ? "4" : "1"));
    }

    // 3. Trunk, Windows, Sunroof & Doors (rg0.java, Lg0.smali, Cg0.java, Dg0.java, Eg0.java)
    public void setPowerTrunk(boolean open) {
        state.trunkOpen = open;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_TRUNK_ACTION, Et5PropertyCatalog.AREA_TRUNK, "i", open ? "1" : "2"));
    }

    public void controlAllWindows(int mode) {
        // mode: 1=Close, 2=Open, 3=Ventilate
        boolean open = (mode == 2 || mode == 3);
        for (int i = 0; i < 4; i++) state.windowsOpen[i] = open;
        notifyStateChanged();
        ioPool.execute(() -> {
            if (mode == 3) {
                setProperty(Et5PropertyCatalog.PROP_WINDOW_CMD, Et5PropertyCatalog.AREA_ALL_WINDOWS_CMD, "i", "3");
            } else {
                for (int area : Et5PropertyCatalog.AREAS_WINDOWS) {
                    setProperty(Et5PropertyCatalog.PROP_WINDOW_POS, area, "i", open ? "10" : "0");
                }
                setProperty(Et5PropertyCatalog.PROP_WINDOW_CMD, Et5PropertyCatalog.AREA_ALL_WINDOWS_POS, "i", open ? "2" : "1");
                setProperty(Et5PropertyCatalog.PROP_WINDOW_CMD, Et5PropertyCatalog.AREA_ALL_WINDOWS_CMD, "i", open ? "2" : "1");
            }
        });
    }

    public void setSunroof(boolean open) {
        state.sunroofOpen = open;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_SUNROOF_CMD, 0, "i", open ? "2" : "1"));
    }

    // 4. Charging & Scheduled Charging (lg0.java, zg0.java, Mg0.M)
    public void setChargeLimit(int limitPercent) {
        final int clamped = Math.max(50, Math.min(100, limitPercent));
        state.chargeLimitPercent = clamped;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_CHARGE_LIMIT, 0, "f", String.valueOf((float) clamped));
            sendHelperCommand("PREF convenience subscribe_charge_electric " + clamped);
        });
    }

    public void startOrStopCharging(boolean start) {
        state.chargingActive = start;
        notifyStateChanged();
        ioPool.execute(() -> {
            if (start) {
                setProperty(Et5PropertyCatalog.PROP_CHARGE_START_STOP, 0, "i", "1");
                setProperty(Et5PropertyCatalog.PROP_CHARGE_STATUS, 0, "i", "1");
            } else {
                // 6-step smart charge stop sequence from Mg0.M()
                int currentSoc = Math.max(50, Math.min(100, state.socPercent));
                setProperty(Et5PropertyCatalog.PROP_CHARGE_LIMIT, 0, "f", String.valueOf((float) currentSoc));
                setProperty(Et5PropertyCatalog.PROP_CHARGE_START_STOP, 0, "i", "0");
                setProperty(Et5PropertyCatalog.PROP_CHARGE_START_STOP, 1, "i", "0");
                setProperty(Et5PropertyCatalog.PROP_CHARGE_STATUS, 0, "i", "0");
                setProperty(Et5PropertyCatalog.PROP_CHARGE_LIMIT, 0, "f", String.valueOf((float) state.chargeLimitPercent));
            }
        });
    }

    public void setScheduledCharging(boolean enabled, int startHour, int startMin, int endHour, int endMin) {
        state.schedChargeEnabled = enabled;
        state.schedChargeStart = String.format("%02d:%02d", startHour, startMin);
        state.schedChargeEnd = String.format("%02d:%02d", endHour, endMin);
        notifyStateChanged();
        ioPool.execute(() -> {
            if (!enabled) {
                setProperty(Et5PropertyCatalog.PROP_SCHED_CHARGE_SWITCH, 0, "i", "0");
            } else {
                Calendar now = Calendar.getInstance();
                int y = now.get(Calendar.YEAR);
                int m = now.get(Calendar.MONTH) + 1;
                int d = now.get(Calendar.DAY_OF_MONTH);
                String startArr = y + "," + m + "," + d + "," + startHour + "," + startMin;
                String endArr = y + "," + m + "," + d + "," + endHour + "," + endMin;
                setProperty(Et5PropertyCatalog.PROP_SCHED_CHARGE_START, 0, "ia", startArr);
                setProperty(Et5PropertyCatalog.PROP_SCHED_CHARGE_END, 0, "ia", endArr);
                setProperty(Et5PropertyCatalog.PROP_SCHED_CHARGE_SWITCH, 0, "i", "1");
            }
        });
    }

    // 5. Audio, Volume, Equalizer & FM Radio (sg0.java, tg0.java, gg0.java, hg0.java)
    public void setMasterVolume(int volume) {
        final int clamped = Math.max(0, Math.min(40, volume));
        state.masterVolume = clamped;
        notifyStateChanged();
        ioPool.execute(() -> {
            Integer ch = getPropertyInt(Et5PropertyCatalog.PROP_AUDIO_CHANNEL, 0);
            int area = ch != null ? ch : state.audioChannel;
            setProperty(Et5PropertyCatalog.PROP_AUDIO_VOLUME, area, "i", String.valueOf(clamped));
        });
    }

    public void setBalanceAndFader(int bal, int fad) {
        final int b = Math.max(-15, Math.min(15, bal));
        final int f = Math.max(-15, Math.min(15, fad));
        state.balance = b;
        state.fader = f;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_AUDIO_BALANCE_FADE, 0, "ia", b + "," + f));
    }

    public void setEqualizerBand(int bandIdx1To5, int levelMinus10To10) {
        final int b = Math.max(1, Math.min(5, bandIdx1To5));
        final int l = Math.max(-10, Math.min(10, levelMinus10To10));
        state.eqBands[b - 1] = l;
        notifyStateChanged();
        ioPool.execute(() -> setProperty(Et5PropertyCatalog.PROP_AUDIO_EQ_BAND, b, "i", String.valueOf(l)));
    }

    public void setFmRadioPower(boolean on) {
        state.fmRadioPower = on;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_RADIO_POWER, 0, "b", String.valueOf(on));
            setProperty(Et5PropertyCatalog.PROP_AUDIO_CHANNEL, 0, "i", on ? "0" : "1");
        });
    }

    public void setFmRadioFrequency(float freqMhz) {
        final float clamped = Math.max(87.5f, Math.min(108.0f, Math.round(freqMhz * 10f) / 10f));
        state.fmRadioFreq = clamped;
        state.fmRadioPower = true;
        notifyStateChanged();
        ioPool.execute(() -> {
            setProperty(Et5PropertyCatalog.PROP_RADIO_FREQ, 0, "f", String.valueOf(clamped));
            setProperty(Et5PropertyCatalog.PROP_RADIO_FREQ, 1, "f", String.valueOf(clamped));
        });
    }

    // 6. Instrument Cluster Controls (CDSManager / DASH)
    public void setClusterSetting(String type, int value) {
        ioPool.execute(() -> {
            if ("parlak".equals(type)) {
                state.clusterBrightness = Math.max(1, Math.min(3, value));
                sendHelperCommand("DASH sendInstrumentBright " + state.clusterBrightness);
            } else if ("tema".equals(type)) {
                state.clusterTheme = Math.max(0, Math.min(1, value));
                sendHelperCommand("DASH sendInstrumentTheme " + state.clusterTheme);
            } else if ("ton".equals(type)) {
                state.clusterTone = Math.max(0, Math.min(2, value));
                sendHelperCommand("DASH sendInstrumentBeatTip " + state.clusterTone);
            } else if ("ses".equals(type)) {
                state.clusterVolume = Math.max(0, Math.min(40, value));
                sendHelperCommand("DASH sendInstrumentVolume " + state.clusterVolume);
            } else if ("nav".equals(type)) {
                state.clusterNavDisplay = (value != 0);
                sendHelperCommand("DASH sendInstrumentNavDisplay " + (state.clusterNavDisplay ? 1 : 0));
            }
            notifyStateChanged();
        });
    }

    public void sendMediaInfoToCluster(boolean playing, String title, String artist) {
        state.mediaPlaying = playing;
        state.mediaTitle = title != null ? title : "";
        state.mediaArtist = artist != null ? artist : "";
        notifyStateChanged();
        ioPool.execute(() -> {
            String b64Title = Base64.encodeToString(state.mediaTitle.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            String b64Artist = Base64.encodeToString(state.mediaArtist.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            sendHelperCommand("MUSIC " + (playing ? 1 : 2) + " " + b64Title + " " + b64Artist + " -");
        });
    }

    // 7. Generic 37+ Vehicle Setting Writer (C0227Hf & C1328f8)
    public void setVehicleSetting(String key, Object value) {
        Et5PropertyCatalog.SettingSpec spec = Et5PropertyCatalog.SETTINGS_MAP.get(key);
        if (spec == null) return;
        if (spec.parkOnly && !"P".equals(state.gear)) {
            Log.w(TAG, key + " yalnız P vitesinde değiştirilebilir");
            return;
        }
        state.settings.put(key, value);
        if ("surus_modu".equals(key) && value instanceof Number) {
            state.driveMode = ((Number) value).intValue();
        }
        if ("geri_kazanim".equals(key) && value instanceof Number) {
            state.regenPercent = ((Number) value).intValue();
        }
        notifyStateChanged();

        ioPool.execute(() -> {
            String carVal = spec.toCarValue(value);
            setProperty(spec.propId, spec.areaId, spec.type, carVal);

            // Special handling for energy recovery (syncs with Skyworth aisettings ContentProvider)
            if ("geri_kazanim".equals(key)) {
                try {
                    int pct = Integer.parseInt(carVal);
                    ContentValues cv = new ContentValues();
                    cv.put("comfort", pct);
                    context.getContentResolver().update(URI_RECOVERY, cv, null, null);
                } catch (Throwable ignored) {}
            }
            // Special handling for ambient light mode (289410580 + 289410581 + 289410582)
            if ("ambiyans".equals(key)) {
                int mode = Integer.parseInt(carVal);
                if (mode == 0) {
                    setProperty(289410580, 0, "i", "2");
                } else {
                    setProperty(289410580, 0, "i", "1");
                    setProperty(289410581, 0, "i", String.valueOf(mode));
                }
            }
        });
    }

    // ======================== PARSING HELPERS ========================

    private static int parseIntSafe(String s, int def) {
        try {
            return (int) Float.parseFloat(s.trim());
        } catch (Throwable t) {
            return def;
        }
    }

    private static float parseFloatSafe(String s, float def) {
        try {
            return Float.parseFloat(s.trim());
        } catch (Throwable t) {
            return def;
        }
    }

    private static boolean parseBoolSafe(String s) {
        if (s == null) return false;
        String t = s.trim();
        return "true".equalsIgnoreCase(t) || "1".equals(t) || "1.0".equals(t);
    }

    private static void parseFloatArrayInto(String csv, float[] target) {
        try {
            String[] tokens = csv.split(",");
            for (int i = 0; i < Math.min(tokens.length, target.length); i++) {
                float v = Float.parseFloat(tokens[i].trim());
                target[i] = Math.round(v * 50.0f) / 50.0f;
            }
        } catch (Throwable ignored) {}
    }
}
