package tr.halil.et5.safety;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

import tr.halil.et5.helper.AdbRootBridge;

/**
 * HomeGate Activity-Alias Helper for switching between SkyOS Tesla Launcher
 * and the stock Skyworth Launcher (com.skyworth.car.launcher).
 */
public final class HomeGate {

    public static final ComponentName STOCK_LAUNCHER = new ComponentName(
            "com.skyworth.car.launcher",
            "com.skyworth.car.launcher.widget.CommonWidgetActivity"
    );

    public static void setTeslaHomeEnabled(Context context, boolean enableTeslaHome) {
        try {
            PackageManager pm = context.getPackageManager();
            pm.setComponentEnabledSetting(
                    new ComponentName(context, HomeGate.class),
                    enableTeslaHome ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                                    : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
            );
            if (enableTeslaHome) {
                AdbRootBridge.execRootOrAdb(4000,
                        "cmd role add-role-holder android.app.role.HOME " + context.getPackageName() + " 0; " +
                        "pm disable " + STOCK_LAUNCHER.flattenToShortString() + " 2>/dev/null; " +
                        "pm disable com.coolwell.ai.skysplash 2>/dev/null"
                );
            } else {
                AdbRootBridge.execRootOrAdb(4000,
                        "pm enable " + STOCK_LAUNCHER.flattenToShortString() + " 2>/dev/null; " +
                        "cmd role add-role-holder android.app.role.HOME com.skyworth.car.launcher 0; " +
                        "cmd package set-home-activity " + STOCK_LAUNCHER.flattenToShortString()
                );
                Intent stock = context.getPackageManager().getLaunchIntentForPackage("com.skyworth.car.launcher");
                if (stock != null) {
                    stock.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(stock);
                }
            }
        } catch (Throwable ignored) {}
    }
}
