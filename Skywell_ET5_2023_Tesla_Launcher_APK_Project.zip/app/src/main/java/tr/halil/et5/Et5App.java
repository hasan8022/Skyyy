package tr.halil.et5;

import android.app.Application;

import tr.halil.et5.car.VehicleController;
import tr.halil.et5.media.Et5MediaHub;
import tr.halil.et5.media.OemMediaRouter;
import tr.halil.et5.obd.ObdElm327Manager;
import tr.halil.et5.smart.Et5SmartFeatures;
import tr.halil.et5.store.Et5AppStore;
import tr.halil.et5.voice.Et5VoiceAssistant;

/**
 * SkyOS Tesla V12 Edition Application Singleton for 2023 Skywell ET5 (Android 9 & Android 12).
 */
public final class Et5App extends Application {

    private static Et5App instance;
    private VehicleController vehicleController;
    private ObdElm327Manager obdManager;
    private OemMediaRouter mediaRouter;
    private Et5VoiceAssistant voiceAssistant;
    private Et5MediaHub mediaHub;
    private Et5AppStore appStore;
    private Et5SmartFeatures smartFeatures;

    public static Et5App getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        vehicleController = new VehicleController(this);
        obdManager = new ObdElm327Manager(this, vehicleController);
        mediaRouter = new OemMediaRouter(this, vehicleController);
        voiceAssistant = new Et5VoiceAssistant(this, vehicleController);
        mediaHub = new Et5MediaHub(this);
        appStore = new Et5AppStore(this);
        smartFeatures = new Et5SmartFeatures(this, vehicleController);

        vehicleController.start();
        mediaRouter.registerSteeringWheelKeys();
        obdManager.startIfConfigured();
    }

    public VehicleController getVehicleController() {
        return vehicleController;
    }

    public ObdElm327Manager getObdManager() {
        return obdManager;
    }

    public OemMediaRouter getMediaRouter() {
        return mediaRouter;
    }

    public Et5VoiceAssistant getVoiceAssistant() {
        return voiceAssistant;
    }

    public Et5MediaHub getMediaHub() {
        return mediaHub;
    }

    public Et5AppStore getAppStore() {
        return appStore;
    }

    public Et5SmartFeatures getSmartFeatures() {
        return smartFeatures;
    }
}
