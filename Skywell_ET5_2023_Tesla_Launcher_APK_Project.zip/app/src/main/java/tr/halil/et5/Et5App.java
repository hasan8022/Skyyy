package tr.halil.et5;

import android.app.Application;

import tr.halil.et5.car.VehicleController;
import tr.halil.et5.media.Et5MediaHub;
import tr.halil.et5.media.OemMediaRouter;
import tr.halil.et5.obd.ObdElm327Manager;
import tr.halil.et5.store.Et5AppStore;
import tr.halil.et5.voice.Et5VoiceAssistant;

/**
 * Skywell ET5 (2023) Native 60 FPS Tesla Launcher Application Singleton (Android 9 - 12).
 */
public final class Et5App extends Application {

    private static Et5App instance;
    private VehicleController vehicleController;
    private ObdElm327Manager obdManager;
    private OemMediaRouter mediaRouter;
    private Et5VoiceAssistant voiceAssistant;
    private Et5MediaHub mediaHub;
    private Et5AppStore appStore;

    public static Et5App getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        vehicleController = new VehicleController(this);
        obdManager = new ObdElm327Manager(this, vehicleController);
        mediaRouter = new OemMediaRouter(this, vehicleController);
        voiceAssistant = new Et5VoiceAssistant(this, vehicleController);
        mediaHub = new Et5MediaHub(this);
        appStore = new Et5AppStore(this);

        vehicleController.start();
        mediaRouter.registerSteeringWheelKeys();
        obdManager.startIfConfigured();
    }

    public VehicleController getVehicleController() {
        return vehicleController;
    }

    public ObdElm327Manager getObdManager() {
        return obdManager;
    }

    public OemMediaRouter getMediaRouter() {
        return mediaRouter;
    }

    public Et5VoiceAssistant getVoiceAssistant() {
        return voiceAssistant;
    }

    public Et5MediaHub getMediaHub() {
        return mediaHub;
    }

    public Et5AppStore getAppStore() {
        return appStore;
    }
}
