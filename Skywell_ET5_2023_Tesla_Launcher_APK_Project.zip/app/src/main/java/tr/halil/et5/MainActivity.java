package tr.halil.et5;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import tr.halil.et5.camera.Et5ReverseCameraHelper;
import tr.halil.et5.car.VehicleController;
import tr.halil.et5.car.VehicleState;
import tr.halil.et5.helper.AdbRootBridge;
import tr.halil.et5.media.Et5MediaHub;
import tr.halil.et5.media.OemMediaRouter;
import tr.halil.et5.obd.ObdElm327Manager;
import tr.halil.et5.safety.HomeGate;
import tr.halil.et5.smart.Et5SmartFeatures;
import tr.halil.et5.store.Et5AppStore;
import tr.halil.et5.voice.Et5VoiceAssistant;

/**
 * MainActivity — 2023 Skywell ET5 (Skyworth EV6) Tesla V12 Split-Screen Launcher.
 * Android 9 (API 28) ve Android 12 (API 31/32) GMS-Free Tam Uyumlu Ana Ekran.
 */
public final class MainActivity extends Activity implements VehicleController.StateListener {

    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private WebView teslaWebView;
    private FrameLayout cameraOverlay;
    private SurfaceView cameraSurfaceView;
    private TextView cameraRadarText;
    private Et5ReverseCameraHelper cameraHelper;

    private VehicleController vehicleController;
    private ObdElm327Manager obdManager;
    private OemMediaRouter mediaRouter;
    private Et5VoiceAssistant voiceAssistant;
    private Et5MediaHub mediaHub;
    private Et5AppStore appStore;
    private Et5SmartFeatures smartFeatures;

    private volatile boolean pageLoaded = false;
    private double lastLat = 37.0662; // Gaziantep / Türkiye varsayılan merkez
    private double lastLon = 37.3833;

    // C2239nx.java: Direksiyon sesli komut tuşu 6 kez basılınca kurtarma modu sayacı
    private int voiceKeyBurstCount = 0;
    private long lastVoiceKeyTimeMs = 0L;

    @SuppressLint({"SetJavaScriptEnabled", "MissingPermission"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupFullscreenWindow();

        Et5App app = Et5App.getInstance();
        vehicleController = app.getVehicleController();
        obdManager = app.getObdManager();
        mediaRouter = app.getMediaRouter();
        voiceAssistant = app.getVoiceAssistant();
        mediaHub = app.getMediaHub();
        appStore = app.getAppStore();
        smartFeatures = app.getSmartFeatures();

        setupCallbacks();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#08090c"));

        teslaWebView = new WebView(this);
        teslaWebView.setBackgroundColor(Color.parseColor("#08090c"));
        WebSettings ws = teslaWebView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36 SkyOS/2.82");

        teslaWebView.addJavascriptInterface(new TeslaJsBridge(), "TeslaBridge");
        teslaWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    try {
                        request.grant(request.getResources());
                    } catch (Throwable ignored) {
                    }
                });
            }
        });

        teslaWebView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null
                        && ASSET_HOST.equalsIgnoreCase(request.getUrl().getHost())) {
                    String path = request.getUrl().getPath();
                    if (path != null && path.startsWith("/assets/")) {
                        String assetPath = path.substring("/assets/".length());
                        if ("car/et5.glb".equals(assetPath)) {
                            assetPath = "car/et5-hafif.glb";
                        }
                        try {
                            InputStream is = getAssets().open(assetPath);
                            String mime = guessMimeType(assetPath);
                            Map<String, String> headers = new HashMap<>();
                            headers.put("Access-Control-Allow-Origin", "*");
                            headers.put("Cache-Control", "no-cache");
                            return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, is);
                        } catch (Throwable ignored) {
                        }
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageLoaded = true;
                pushVehicleStateToUi(vehicleController.getState());
                refreshWeatherAsync();
            }
        });

        root.addView(teslaWebView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        buildCameraOverlay(root);
        setContentView(root);

        teslaWebView.loadUrl("https://" + ASSET_HOST + "/assets/tesla/index.html");
        startGpsTracking();
    }

    private void setupCallbacks() {
        voiceAssistant.setCallback(new Et5VoiceAssistant.AssistantCallback() {
            @Override
            public void onStateChanged(String state, String transcript, String reply, float audioLevel) {
                if (!pageLoaded || teslaWebView == null) return;
                try {
                    JSONObject o = new JSONObject();
                    o.put("state", state);
                    o.put("transcript", transcript != null ? transcript : "");
                    o.put("reply", reply != null ? reply : "");
                    o.put("level", audioLevel);
                    final String js = "window.onVoiceAssistantState && window.onVoiceAssistantState(" + o.toString() + ");";
                    runOnUiThread(() -> teslaWebView.evaluateJavascript(js, null));
                } catch (Exception ignored) {
                }
            }

            @Override
            public void onUiAction(String actionType, String target, String param) {
                if ("SCREEN".equals(actionType) && "camera".equals(target)) {
                    showReverseCamera(true);
                } else if ("SCREEN".equals(actionType) && "restore_stock".equals(target)) {
                    HomeGate.setTeslaHomeEnabled(MainActivity.this, false);
                } else if ("MEDIA_KEY".equals(actionType)) {
                    mediaRouter.dispatchMediaAction(target);
                }
                if (!pageLoaded || teslaWebView == null) return;
                try {
                    JSONObject o = new JSONObject();
                    o.put("type", actionType);
                    o.put("target", target != null ? target : "");
                    o.put("param", param != null ? param : "");
                    final String js = "window.onVoiceUiAction && window.onVoiceUiAction(" + o.toString() + ");";
                    runOnUiThread(() -> teslaWebView.evaluateJavascript(js, null));
                } catch (Exception ignored) {
                }
            }
        });

        appStore.setCallback((pkg, percent, statusText) -> {
            if (!pageLoaded || teslaWebView == null) return;
            try {
                JSONObject o = new JSONObject();
                o.put("pkg", pkg);
                o.put("percent", percent);
                o.put("status", statusText);
                final String js = "window.onStoreProgress && window.onStoreProgress(" + o.toString() + ");";
                runOnUiThread(() -> teslaWebView.evaluateJavascript(js, null));
            } catch (Exception ignored) {
            }
        });
    }

    private void buildCameraOverlay(FrameLayout root) {
        cameraOverlay = new FrameLayout(this);
        cameraOverlay.setBackgroundColor(Color.BLACK);
        cameraOverlay.setVisibility(View.GONE);

        cameraSurfaceView = new SurfaceView(this);
        cameraHelper = new Et5ReverseCameraHelper(this);
        cameraHelper.attachToSurfaceView(cameraSurfaceView);
        cameraOverlay.addView(cameraSurfaceView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        cameraRadarText = new TextView(this);
        cameraRadarText.setTextColor(Color.WHITE);
        cameraRadarText.setTextSize(16f);
        cameraRadarText.setPadding(28, 16, 28, 16);
        cameraRadarText.setBackgroundColor(Color.argb(180, 15, 17, 22));
        FrameLayout.LayoutParams radarLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.START
        );
        radarLp.setMargins(24, 24, 24, 24);
        cameraOverlay.addView(cameraRadarText, radarLp);

        Button closeBtn = new Button(this);
        closeBtn.setText("✕ Kamerayı Kapat");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setBackgroundColor(Color.argb(210, 220, 38, 38));
        closeBtn.setPadding(32, 16, 32, 16);
        closeBtn.setOnClickListener(v -> showReverseCamera(false));
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END
        );
        closeLp.setMargins(24, 24, 24, 24);
        cameraOverlay.addView(closeBtn, closeLp);

        root.addView(cameraOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
    }

    public void showReverseCamera(final boolean show) {
        runOnUiThread(() -> {
            if (show) {
                AdbRootBridge.stopSkyworthEvsService(MainActivity.this);
                cameraOverlay.setVisibility(View.VISIBLE);
                updateCameraRadarBanner(vehicleController.getState());
            } else {
                cameraHelper.closeCamera();
                cameraOverlay.setVisibility(View.GONE);
            }
        });
    }

    private void updateCameraRadarBanner(VehicleState st) {
        if (cameraOverlay.getVisibility() != View.VISIBLE) return;
        float minRear = 9.9f;
        for (float d : st.radarRear) if (d > 0.05f && d < minRear) minRear = d;
        float minFront = 9.9f;
        for (float d : st.radarFront) if (d > 0.05f && d < minFront) minFront = d;
        String rearStr = minRear < 5.0f ? String.format("%.2f m", minRear) : "Temiz";
        String frontStr = minFront < 5.0f ? String.format("%.2f m", minFront) : "Temiz";
        cameraRadarText.setText("360° AVM / Geri Görüş Kamerası (" + st.gear + ")  |  Arka Radar: " + rearStr + "  ·  Ön Radar: " + frontStr);
    }

    private void refreshWeatherAsync() {
        new Thread(() -> {
            final String weatherJson = smartFeatures.fetchLiveWeatherJson(lastLat, lastLon);
            if (pageLoaded && teslaWebView != null) {
                runOnUiThread(() -> teslaWebView.evaluateJavascript(
                        "window.onWeatherUpdate && window.onWeatherUpdate(" + weatherJson + ");", null));
            }
        }, "Et5-Weather").start();
    }

    @SuppressLint("MissingPermission")
    private void startGpsTracking() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return;
            LocationListener ll = new LocationListener() {
                @Override
                public void onLocationChanged(Location loc) {
                    if (loc != null) {
                        lastLat = loc.getLatitude();
                        lastLon = loc.getLongitude();
                        if (pageLoaded && teslaWebView != null) {
                            final double lat = lastLat;
                            final double lon = lastLon;
                            runOnUiThread(() -> teslaWebView.evaluateJavascript(
                                    "window.updateGpsLocation && window.updateGpsLocation(" + lat + "," + lon + ");", null));
                        }
                    }
                }
                @Override public void onStatusChanged(String p, int s, Bundle b) {}
                @Override public void onProviderEnabled(String p) {}
                @Override public void onProviderDisabled(String p) {}
            };
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 2.0f, ll);
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 5.0f, ll);
            }
        } catch (Throwable ignored) {
        }
    }

    /**
     * C2239nx.java: Direksiyon Sesli Komut Tuşu Yakalayıcı + 6 Kez Basınca Kurtarma Modu.
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST
                || keyCode == KeyEvent.KEYCODE_SEARCH
                || keyCode == KeyEvent.KEYCODE_ASSIST) {
            long now = System.currentTimeMillis();
            if (now - lastVoiceKeyTimeMs < 1500) {
                voiceKeyBurstCount++;
                if (voiceKeyBurstCount >= 6) {
                    voiceKeyBurstCount = 0;
                    voiceAssistant.speak("Kurtarma moduna geçiliyor, aracın orijinal ekranı açılıyor.");
                    HomeGate.setTeslaHomeEnabled(this, false);
                    return true;
                }
            } else {
                voiceKeyBurstCount = 1;
            }
            lastVoiceKeyTimeMs = now;

            if (pageLoaded && teslaWebView != null) {
                teslaWebView.evaluateJavascript("window.openVoiceModal && window.openVoiceModal();", null);
            }
            voiceAssistant.startMicrophoneVadListening("");
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupFullscreenWindow();
        vehicleController.addListener(this);
        AdbRootBridge.preventStockLauncherMediaKeys(this);
        pushVehicleStateToUi(vehicleController.getState());
    }

    @Override
    protected void onPause() {
        vehicleController.removeListener(this);
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (cameraOverlay != null && cameraOverlay.getVisibility() == View.VISIBLE) {
            showReverseCamera(false);
        }
    }

    @Override
    public void onVehicleStateChanged(VehicleState state) {
        pushVehicleStateToUi(state);
        updateCameraRadarBanner(state);
    }

    @Override
    public void onReverseGearChanged(boolean inReverse) {
        showReverseCamera(inReverse);
    }

    private void pushVehicleStateToUi(final VehicleState state) {
        if (!pageLoaded || teslaWebView == null || state == null) return;
        final String json = state.toJson().toString();
        runOnUiThread(() -> teslaWebView.evaluateJavascript(
                "window.onVehicleStateJson && window.onVehicleStateJson(" + json + ");", null));
    }

    private void setupFullscreenWindow() {
        try {
            Window w = getWindow();
            if (w == null) return;
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            View decor = w.getDecorView();
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        } catch (Throwable ignored) {
        }
    }

    private static String guessMimeType(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "text/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".glb")) return "model/gltf-binary";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }

    // ======================== JAVASCRIPT BRIDGE FOR TESLA V12 UI ========================

    public final class TeslaJsBridge {

        @JavascriptInterface
        public int getAndroidSdkInt() {
            return Build.VERSION.SDK_INT;
        }

        @JavascriptInterface
        public void setProperty(int propId, int areaId, String typeAndVal) {
            if (typeAndVal == null || !typeAndVal.contains(":")) return;
            String[] p = typeAndVal.split(":", 2);
            vehicleController.setProperty(propId, areaId, p[0], p[1]);
        }

        @JavascriptInterface
        public void setPowerTrunk(boolean open) {
            vehicleController.setPowerTrunk(open);
        }

        @JavascriptInterface
        public void controlAllWindows(int mode) {
            vehicleController.controlAllWindows(mode);
        }

        @JavascriptInterface
        public void setSunroof(boolean open) {
            vehicleController.setSunroof(open);
        }

        @JavascriptInterface
        public void foldMirrors(boolean fold) {
            vehicleController.foldMirrors(fold);
        }

        @JavascriptInterface
        public void setHvacPower(boolean on) {
            vehicleController.setHvacPower(on);
        }

        @JavascriptInterface
        public void setHvacTemperature(float tempC) {
            vehicleController.setHvacTemperature(tempC);
        }

        @JavascriptInterface
        public void setHvacFanSpeed(int speed) {
            vehicleController.setHvacFanSpeed(speed);
        }

        @JavascriptInterface
        public void toggleHvacFlag(String flag) {
            VehicleState s = vehicleController.getState();
            if ("ac".equals(flag)) vehicleController.setHvacAc(!s.hvacAc);
            else if ("auto".equals(flag)) vehicleController.setHvacAuto(!s.hvacAuto);
            else if ("recirc".equals(flag)) vehicleController.setHvacRecirc(!s.hvacRecirc);
            else if ("eco".equals(flag)) vehicleController.setHvacEco(!s.hvacEco);
            else if ("fdef".equals(flag)) vehicleController.setHvacFrontDefrost(!s.hvacFrontDefrost);
            else if ("rdef".equals(flag)) vehicleController.setHvacRearDefrost(!s.hvacRearDefrost);
        }

        @JavascriptInterface
        public void setSeatHeating(boolean isDriver, int level) {
            vehicleController.setSeatHeating(isDriver, level);
        }

        @JavascriptInterface
        public void setSeatVentilation(boolean isDriver, int level) {
            vehicleController.setSeatVentilation(isDriver, level);
        }

        @JavascriptInterface
        public void moveSeatPreset(int foreAft, int height, int tilt, int footrest) {
            vehicleController.moveDriverSeatPosition(foreAft, height, tilt, footrest);
        }

        @JavascriptInterface
        public void setChargeLimit(int pct) {
            vehicleController.setChargeLimit(pct);
        }

        @JavascriptInterface
        public void startOrStopCharging(boolean start) {
            vehicleController.startOrStopCharging(start);
        }

        @JavascriptInterface
        public void setMasterVolume(int vol) {
            vehicleController.setMasterVolume(vol);
        }

        @JavascriptInterface
        public void selectMediaSource(String source) {
            mediaRouter.selectMediaSource(source);
        }

        @JavascriptInterface
        public void dispatchMediaAction(String action) {
            mediaRouter.dispatchMediaAction(action);
        }

        @JavascriptInterface
        public void launchApp(String pkg) {
            mediaRouter.launchPackageOrService(pkg);
        }

        @JavascriptInterface
        public void dialPhone(String number) {
            mediaRouter.dialPhoneNumber(number);
        }

        @JavascriptInterface
        public void openReverseCamera(boolean show) {
            showReverseCamera(show);
        }

        @JavascriptInterface
        public void setVehicleSetting(String key, String rawVal) {
            if ("true".equalsIgnoreCase(rawVal) || "false".equalsIgnoreCase(rawVal)) {
                vehicleController.setVehicleSetting(key, Boolean.parseBoolean(rawVal));
            } else {
                try {
                    vehicleController.setVehicleSetting(key, Integer.parseInt(rawVal));
                } catch (NumberFormatException ignored) {
                }
            }
        }

        @JavascriptInterface
        public void setClusterSetting(String type, int val) {
            vehicleController.setClusterSetting(type, val);
        }

        @JavascriptInterface
        public void restartHelper(boolean force) {
            new Thread(() -> {
                AdbRootBridge.ensureHelperStarted(MainActivity.this);
                vehicleController.syncInitialVehicleState();
            }).start();
        }

        @JavascriptInterface
        public void scanDtcs(boolean trigger) {
            obdManager.requestDtcScan();
        }

        @JavascriptInterface
        public void switchToStockLauncher(boolean confirm) {
            HomeGate.setTeslaHomeEnabled(MainActivity.this, false);
        }

        // ======================== YENİ GMS-FREE MODÜLLER (SESLİ ASİSTAN, YOUTUBE, SPOTIFY, RADYO, MAĞAZA, AKILLI MODLAR) ========================

        @JavascriptInterface
        public void startVoiceListening(String apiKey) {
            voiceAssistant.startMicrophoneVadListening(apiKey != null ? apiKey : "");
        }

        @JavascriptInterface
        public void stopVoiceListening() {
            voiceAssistant.stopListening();
        }

        @JavascriptInterface
        public String runVoiceCommand(String text) {
            return voiceAssistant.processVoiceCommand(text);
        }

        @JavascriptInterface
        public void speakText(String text) {
            voiceAssistant.speak(text);
        }

        @JavascriptInterface
        public String getMediaSourcesJson() {
            return mediaHub.getMediaSourcesJson().toString();
        }

        @JavascriptInterface
        public void searchYouTubeAsync(final String query, final String filter) {
            new Thread(() -> {
                final String res = mediaHub.searchYouTubeGmsFree(query, filter);
                runOnUiThread(() -> {
                    if (teslaWebView != null) {
                        teslaWebView.evaluateJavascript("window.onYouTubeResults && window.onYouTubeResults(" + res + ");", null);
                    }
                });
            }, "Et5-YT-Search").start();
        }

        @JavascriptInterface
        public String getSpotifyCuratedJson() {
            return mediaHub.getSpotifyPlaylistsAndCurated();
        }

        @JavascriptInterface
        public void searchSpotifyAsync(final String query) {
            new Thread(() -> {
                final String res = mediaHub.searchSpotifyWebApi(query);
                runOnUiThread(() -> {
                    if (teslaWebView != null) {
                        teslaWebView.evaluateJavascript("window.onSpotifyResults && window.onSpotifyResults(" + res + ");", null);
                    }
                });
            }, "Et5-Spot-Search").start();
        }

        @JavascriptInterface
        public void saveSpotifyToken(String token) {
            mediaHub.saveSpotifyToken(token);
        }

        @JavascriptInterface
        public String getPresetRadioJson() {
            return mediaHub.getPresetRadioStationsJson();
        }

        @JavascriptInterface
        public void searchRadioAsync(final String query, final String tag, final String country) {
            new Thread(() -> {
                final String res = mediaHub.searchInternetRadio(query, tag, country);
                runOnUiThread(() -> {
                    if (teslaWebView != null) {
                        teslaWebView.evaluateJavascript("window.onRadioResults && window.onRadioResults(" + res + ");", null);
                    }
                });
            }, "Et5-Radio-Search").start();
        }

        @JavascriptInterface
        public void playInternetRadio(String name, String subtitle, String url) {
            mediaHub.playInternetRadioStream(name, subtitle, url);
            vehicleController.sendMediaInfoToCluster(true, name, subtitle);
        }

        @JavascriptInterface
        public void stopInternetRadio() {
            mediaHub.stopInternetRadioStream();
        }

        @JavascriptInterface
        public void scanUsbAudioAsync() {
            new Thread(() -> {
                final String res = mediaHub.scanUsbAudioFilesJson();
                runOnUiThread(() -> {
                    if (teslaWebView != null) {
                        teslaWebView.evaluateJavascript("window.onUsbAudioResults && window.onUsbAudioResults(" + res + ");", null);
                    }
                });
            }, "Et5-Usb-Scan").start();
        }

        @JavascriptInterface
        public boolean launchMediaSourceApp(String sourceId, String query) {
            return mediaHub.launchOrPlaySource(sourceId, query);
        }

        @JavascriptInterface
        public String getAppStoreCatalogJson() {
            return appStore.getCatalogJson();
        }

        @JavascriptInterface
        public void installStoreApp(String pkg, String url) {
            appStore.downloadAndInstallApp(pkg, url);
        }

        @JavascriptInterface
        public String getProfilesJson() {
            return smartFeatures.getProfilesJson();
        }

        @JavascriptInterface
        public void selectDriverProfile(String name) {
            smartFeatures.selectDriverProfile(name);
        }

        @JavascriptInterface
        public void setCarBodyColor(String hex, String colorName) {
            smartFeatures.setCarBodyColor(hex, colorName);
        }

        @JavascriptInterface
        public String getEnergyAndSavingsJson() {
            return smartFeatures.getEnergyAndSavingsJson();
        }

        @JavascriptInterface
        public void updateEnergyPrices(float homeTl, float stationTl, float petrolTl) {
            smartFeatures.updateEnergyPrices(homeTl, stationTl, petrolTl);
        }

        @JavascriptInterface
        public void resetTripCounter() {
            smartFeatures.resetTripCounter();
        }

        @JavascriptInterface
        public String getSmartModesJson() {
            return smartFeatures.getSmartModesJson();
        }

        @JavascriptInterface
        public boolean activateSmartMode(String mode, String param) {
            return smartFeatures.activateSmartMode(mode, param);
        }

        @JavascriptInterface
        public void saveParkingNote(String note) {
            smartFeatures.saveParkingNote(note);
        }

        @JavascriptInterface
        public String calculateEvRouteSummaryJson(double distKm, double durMin) {
            return smartFeatures.calculateEvRouteSummaryJson(distKm, durMin);
        }

        @JavascriptInterface
        public String getMaintenanceAndSmartHomeJson() {
            return smartFeatures.getMaintenanceAndSmartHomeJson();
        }

        @JavascriptInterface
        public void saveSmartHomeWebhooks(String arrivalUrl, String departureUrl) {
            smartFeatures.saveSmartHomeWebhooks(arrivalUrl, departureUrl);
        }

        @JavascriptInterface
        public void triggerSmartHomeWebhook(boolean isArrival) {
            smartFeatures.triggerSmartHomeWebhook(isArrival);
        }
    }
}
