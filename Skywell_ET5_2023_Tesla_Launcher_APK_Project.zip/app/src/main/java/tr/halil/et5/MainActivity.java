package tr.halil.et5;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import tr.halil.et5.camera.Et5ReverseCameraHelper;
import tr.halil.et5.car.VehicleController;
import tr.halil.et5.car.VehicleState;
import tr.halil.et5.helper.AdbRootBridge;
import tr.halil.et5.media.Et5MediaHub;
import tr.halil.et5.media.OemMediaRouter;
import tr.halil.et5.setup.SetupWizardDialog;
import tr.halil.et5.store.Et5AppStore;
import tr.halil.et5.ui.NativeDialogs;
import tr.halil.et5.voice.Et5VoiceAssistant;

/**
 * MainActivity — 2023 Skywell ET5 (Skyworth EV6) 100% Native 60 FPS Tesla Split-Screen Launcher.
 *
 * - SIFIR DEMO VERİ: CAN-Bus (AracYardimci 127.0.0.1:8724) bağlanana kadar sahte değer göstermez (--%, -- km, --.-°C).
 * - ZORUNLU KURULUM SİHİRBAZI: İlk açılışta Coocaa OS Geliştirici Şifresini hesaplar ve 127.0.0.1:5555 ADB yetkilerini otomatik kurar.
 * - SIFIR KASMA (60 FPS NATIVE UI): Tam ekran WebView kabuğu yerine donanım hızlandırmalı Native Android View mimarisi kullanır.
 * - GERÇEK HARİTA, SPOTIFY VE YOUTUBE: Orijinal map-lite Leaflet + GPS/OSRM haritası ve gerçek Spotify/Metrolist/SmartTube/NewPipe entegrasyonu.
 */
public final class MainActivity extends Activity implements VehicleController.StateListener {

    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private VehicleController vehicleController;
    private OemMediaRouter mediaRouter;
    private Et5VoiceAssistant voiceAssistant;
    private Et5MediaHub mediaHub;
    private Et5AppStore appStore;

    // Top Status Bar Views
    private final TextView[] gearPills = new TextView[4]; // P, R, N, D
    private TextView autoHoldBadge;
    private TextView signalsBadge;
    private TextView batteryRangeTopText;
    private TextView tempTopText;
    private Button bridgeStatusBtn;
    private TextView clockText;

    // Left 38% Tesla Vehicle Stage Views
    private TextView speedValueText;
    private TextView driveModeBadge;
    private TextView odoAndConsText;
    private WebView car3dWebView;
    private volatile boolean car3dReady = false;
    private String lastCar3dJson = "";
    private final TextView[] tpmsBadges = new TextView[4];
    private Button lockQuickBtn;
    private Button trunkQuickBtn;
    private Button chargePortQuickBtn;

    // Right 62% Map & Real Media Panel Views
    private EditText mapSearchInput;
    private TextView navBannerText;
    private WebView mapLiteWebView;
    private volatile boolean mapLiteReady = false;
    private TextView mediaTitleText;
    private TextView mediaArtistText;
    private Button playPauseBtn;

    // Bottom Dock Views
    private Button dockClimateBtn;
    private Button dockSeatBtn;

    // Reverse Camera Overlay
    private FrameLayout cameraOverlay;
    private SurfaceView cameraSurfaceView;
    private TextView cameraRadarText;
    private Et5ReverseCameraHelper cameraHelper;

    // Real GPS State
    private volatile boolean hasRealGpsFix = false;
    private volatile double currentLat = 39.9208; // Türkiye genel merkez (GPS kilidi gelene kadar)
    private volatile double currentLon = 32.8541;
    private volatile float currentBearing = 0f;

    // Steering wheel 6-tap stock recovery counter
    private int voiceKeyBurstCount = 0;
    private long lastVoiceKeyTimeMs = 0L;
    private SetupWizardDialog activeSetupDialog;

    private final Runnable periodicTicker = new Runnable() {
        @Override
        public void run() {
            updateClockAndMediaUi();
            mainHandler.postDelayed(this, 2000);
        }
    };

    @SuppressLint({"SetJavaScriptEnabled", "MissingPermission"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enableImmersiveFullscreen();

        Et5App app = Et5App.getInstance();
        vehicleController = app.getVehicleController();
        mediaRouter = app.getMediaRouter();
        voiceAssistant = app.getVoiceAssistant();
        mediaHub = app.getMediaHub();
        appStore = app.getAppStore();

        buildNativeSplitScreenUi();

        vehicleController.addListener(this);
        onVehicleStateChanged(vehicleController.getState());
        startRealGpsTracking();

        // Mandatory Setup Wizard check on first run or when ADB/AracYardimci is not yet set up
        mainHandler.postDelayed(() -> {
            if (!AdbRootBridge.isSetupCompleted(this) && !AdbRootBridge.isHelperAlive()) {
                openSetupWizard();
            } else if (!AdbRootBridge.isHelperAlive()) {
                AdbRootBridge.bootstrapHelperAsync(this);
            }
        }, 600);
    }

    private void buildNativeSplitScreenUi() {
        FrameLayout rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(Color.parseColor("#080B10"));

        LinearLayout mainVertical = new LinearLayout(this);
        mainVertical.setOrientation(LinearLayout.VERTICAL);
        rootFrame.addView(mainVertical, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 1. TOP STATUS BAR (Native)
        mainVertical.addView(buildTopStatusBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        // 2. CENTER SPLIT-SCREEN (Left 38% Vehicle Stage | Right 62% Map + Real Media Card)
        LinearLayout splitRow = new LinearLayout(this);
        splitRow.setOrientation(LinearLayout.HORIZONTAL);
        splitRow.setPadding(dp(10), dp(4), dp(10), dp(6));
        mainVertical.addView(splitRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));

        LinearLayout leftStage = buildLeftVehicleStage();
        LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.38f);
        leftLp.rightMargin = dp(8);
        splitRow.addView(leftStage, leftLp);

        LinearLayout rightStage = buildRightMapAndMediaStage();
        LinearLayout.LayoutParams rightLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.62f);
        splitRow.addView(rightStage, rightLp);

        // 3. BOTTOM TESLA DOCK BAR (Native)
        mainVertical.addView(buildBottomTeslaDock(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(62)));

        // 4. REVERSE / 360 CAMERA OVERLAY (Hidden until R gear or user tap)
        cameraOverlay = buildReverseCameraOverlay();
        rootFrame.addView(cameraOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(rootFrame);
    }

    private View buildTopStatusBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#0D121B"));
        bar.setPadding(dp(14), dp(4), dp(14), dp(4));

        // Gear Selector Strip (P R N D)
        String[] gears = new String[]{"P", "R", "N", "D"};
        for (int i = 0; i < 4; i++) {
            TextView gp = new TextView(this);
            gp.setText(gears[i]);
            gp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            gp.setTypeface(Typeface.DEFAULT_BOLD);
            gp.setPadding(dp(8), dp(2), dp(8), dp(2));
            gearPills[i] = gp;
            bar.addView(gp);
        }

        autoHoldBadge = new TextView(this);
        autoHoldBadge.setText("(H)");
        autoHoldBadge.setTextColor(Color.parseColor("#4ADE80"));
        autoHoldBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        autoHoldBadge.setTypeface(Typeface.DEFAULT_BOLD);
        autoHoldBadge.setPadding(dp(6), 0, dp(10), 0);
        autoHoldBadge.setVisibility(View.GONE);
        bar.addView(autoHoldBadge);

        signalsBadge = new TextView(this);
        signalsBadge.setText("");
        signalsBadge.setTextColor(Color.parseColor("#4ADE80"));
        signalsBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        signalsBadge.setTypeface(Typeface.DEFAULT_BOLD);
        signalsBadge.setPadding(dp(4), 0, dp(10), 0);
        bar.addView(signalsBadge);

        // Battery SOC + Range + Power Pill
        batteryRangeTopText = new TextView(this);
        batteryRangeTopText.setText("🔋 --%  •  -- km  •  -- kW");
        batteryRangeTopText.setTextColor(Color.WHITE);
        batteryRangeTopText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        batteryRangeTopText.setTypeface(Typeface.DEFAULT_BOLD);
        batteryRangeTopText.setBackground(makeRoundedBg("#161F2E", "#26334A", 8));
        batteryRangeTopText.setPadding(dp(12), dp(4), dp(12), dp(4));
        bar.addView(batteryRangeTopText);

        View spacer = new View(this);
        bar.addView(spacer, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        // Cabin & Outside Temps
        tempTopText = new TextView(this);
        tempTopText.setText("İç: --.-°C  |  Dış: --.-°C");
        tempTopText.setTextColor(Color.parseColor("#CBD5E1"));
        tempTopText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tempTopText.setPadding(dp(10), 0, dp(12), 0);
        bar.addView(tempTopText);

        // CAN-Bus / Setup Wizard Status Button
        bridgeStatusBtn = new Button(this);
        bridgeStatusBtn.setText("▲ Kurulum / ADB Sihirbazı");
        bridgeStatusBtn.setAllCaps(false);
        bridgeStatusBtn.setTextColor(Color.WHITE);
        bridgeStatusBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        bridgeStatusBtn.setTypeface(Typeface.DEFAULT_BOLD);
        bridgeStatusBtn.setBackground(makeRoundedBg("#D97706", "#F59E0B", 8));
        bridgeStatusBtn.setPadding(dp(10), dp(3), dp(10), dp(3));
        bridgeStatusBtn.setOnClickListener(v -> openSetupWizard());
        bar.addView(bridgeStatusBtn);

        // Clock
        clockText = new TextView(this);
        clockText.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
        clockText.setTextColor(Color.WHITE);
        clockText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        clockText.setTypeface(Typeface.DEFAULT_BOLD);
        clockText.setPadding(dp(14), 0, dp(4), 0);
        bar.addView(clockText);

        return bar;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private LinearLayout buildLeftVehicleStage() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(makeRoundedBg("#101622", "#1E293B", 16));
        card.setPadding(dp(14), dp(10), dp(14), dp(10));

        // Row 1: Speedometer + Drive Mode + Odometer
        LinearLayout speedRow = new LinearLayout(this);
        speedRow.setOrientation(LinearLayout.HORIZONTAL);
        speedRow.setGravity(Gravity.CENTER_VERTICAL);

        speedValueText = new TextView(this);
        speedValueText.setText("0");
        speedValueText.setTextColor(Color.WHITE);
        speedValueText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 44);
        speedValueText.setTypeface(Typeface.DEFAULT_BOLD);
        speedRow.addView(speedValueText);

        LinearLayout unitCol = new LinearLayout(this);
        unitCol.setOrientation(LinearLayout.VERTICAL);
        unitCol.setPadding(dp(8), 0, 0, 0);

        TextView kmhLabel = new TextView(this);
        kmhLabel.setText("km/s");
        kmhLabel.setTextColor(Color.parseColor("#94A3B8"));
        kmhLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        kmhLabel.setTypeface(Typeface.DEFAULT_BOLD);
        unitCol.addView(kmhLabel);

        driveModeBadge = new TextView(this);
        driveModeBadge.setText("NORMAL");
        driveModeBadge.setTextColor(Color.parseColor("#38BDF8"));
        driveModeBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        driveModeBadge.setTypeface(Typeface.DEFAULT_BOLD);
        driveModeBadge.setOnClickListener(v -> {
            int nextMode = (vehicleController.getState().driveMode + 1) % 3;
            vehicleController.setDriveMode(nextMode);
        });
        unitCol.addView(driveModeBadge);
        speedRow.addView(unitCol);

        View sp = new View(this);
        speedRow.addView(sp, new LinearLayout.LayoutParams(0, 1, 1f));

        odoAndConsText = new TextView(this);
        odoAndConsText.setText("Sayaç: -- km\nTük: --.- kWh/100km");
        odoAndConsText.setTextColor(Color.parseColor("#94A3B8"));
        odoAndConsText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        odoAndConsText.setGravity(Gravity.END);
        speedRow.addView(odoAndConsText);

        card.addView(speedRow);

        // Row 2: 3D Skywell ET5 Interactive Viewer (assets/car/index.html with et5-hafif.glb)
        FrameLayout carContainer = new FrameLayout(this);
        LinearLayout.LayoutParams carLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f);
        carLp.topMargin = dp(4);
        carLp.bottomMargin = dp(4);
        carContainer.setLayoutParams(carLp);

        car3dWebView = new WebView(this);
        car3dWebView.setBackgroundColor(Color.TRANSPARENT);
        car3dWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        configureAssetWebView(car3dWebView, new Car3dBridge(), "Et5", () -> {
            car3dReady = true;
            pushStateToCar3d(vehicleController.getState());
        });
        car3dWebView.loadUrl("https://" + ASSET_HOST + "/assets/car/index.html");
        carContainer.addView(car3dWebView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Camera Angle Switcher Overlay (Top-Right of 3D Stage)
        LinearLayout camAngles = new LinearLayout(this);
        camAngles.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout.LayoutParams angleLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        camAngles.setLayoutParams(angleLp);
        String[][] views = new String[][]{{"Park", "parked"}, {"Üst", "top"}, {"Ön", "front"}, {"Arka", "rear"}};
        for (final String[] vw : views) {
            Button b = makeMiniPillButton(vw[0], () -> {
                if (car3dReady && car3dWebView != null) {
                    car3dWebView.evaluateJavascript("window.CAR && window.CAR.view('" + vw[1] + "', 650);", null);
                }
            });
            camAngles.addView(b);
        }
        carContainer.addView(camAngles);

        card.addView(carContainer);

        // Row 3: Live 4-Wheel TPMS Tire Pressure & Temp Strip
        LinearLayout tpmsRow = new LinearLayout(this);
        tpmsRow.setOrientation(LinearLayout.HORIZONTAL);
        tpmsRow.setBackground(makeRoundedBg("#0B0F17", "#1E293B", 8));
        tpmsRow.setPadding(dp(8), dp(5), dp(8), dp(5));
        String[] wheelNames = new String[]{"Ön Sol", "Ön Sağ", "Arka Sol", "Arka Sağ"};
        for (int i = 0; i < 4; i++) {
            TextView tv = new TextView(this);
            tv.setText(wheelNames[i] + "\n-- bar");
            tv.setTextColor(Color.parseColor("#CBD5E1"));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            tv.setGravity(Gravity.CENTER);
            tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            tpmsBadges[i] = tv;
            tpmsRow.addView(tv);
        }
        card.addView(tpmsRow);

        // Row 4: Quick Body Hardware Action Buttons
        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams qLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        qLp.topMargin = dp(6);
        quickRow.setLayoutParams(qLp);

        lockQuickBtn = makeQuickStageButton("🔒 Kilit", () -> {
            VehicleState st = vehicleController.getState();
            vehicleController.setDoorLocks(!st.locked);
        });
        trunkQuickBtn = makeQuickStageButton("🚗 Bagaj", () -> {
            VehicleState st = vehicleController.getState();
            vehicleController.setPowerTrunk(!st.trunkOpen);
        });
        chargePortQuickBtn = makeQuickStageButton("⚡ Şarj", () -> {
            VehicleState st = vehicleController.getState();
            vehicleController.setChargePort(!st.chargePortOpen);
        });
        Button camQuickBtn = makeQuickStageButton("🪟 Camlar", () -> {
            VehicleState st = vehicleController.getState();
            boolean anyOpen = st.windowsOpen[0] || st.windowsOpen[1] || st.windowsOpen[2] || st.windowsOpen[3];
            vehicleController.controlAllWindows(anyOpen ? 1 : 3);
        });

        quickRow.addView(lockQuickBtn, new LinearLayout.LayoutParams(0, dp(38), 1f));
        quickRow.addView(trunkQuickBtn, new LinearLayout.LayoutParams(0, dp(38), 1f));
        quickRow.addView(chargePortQuickBtn, new LinearLayout.LayoutParams(0, dp(38), 1f));
        quickRow.addView(camQuickBtn, new LinearLayout.LayoutParams(0, dp(38), 1f));
        card.addView(quickRow);

        return card;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private LinearLayout buildRightMapAndMediaStage() {
        LinearLayout rightCol = new LinearLayout(this);
        rightCol.setOrientation(LinearLayout.VERTICAL);

        // 1. MAP CONTAINER (Top 74% of Right Pane)
        FrameLayout mapCard = new FrameLayout(this);
        mapCard.setBackground(makeRoundedBg("#101622", "#1E293B", 16));
        LinearLayout.LayoutParams mapCardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 0.73f);
        mapCardLp.bottomMargin = dp(8);
        mapCard.setLayoutParams(mapCardLp);

        mapLiteWebView = new WebView(this);
        mapLiteWebView.setBackgroundColor(Color.parseColor("#0D1117"));
        mapLiteWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        configureAssetWebView(mapLiteWebView, new MapLiteBridge(), "Et5Map", () -> {
            mapLiteReady = true;
            // Enable dark mode and set initial position on real Leaflet map
            String js = String.format(Locale.US,
                    "if(window.LITE){window.LITE.setDark(true);window.LITE.setPos(%.6f,%.6f,%.1f,true);}",
                    currentLat, currentLon, currentBearing);
            mapLiteWebView.evaluateJavascript(js, null);
        });
        mapLiteWebView.loadUrl("https://" + ASSET_HOST + "/assets/map-lite/index.html");
        mapCard.addView(mapLiteWebView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Top Floating Search & POI Bar over Map
        LinearLayout mapTopOverlay = new LinearLayout(this);
        mapTopOverlay.setOrientation(LinearLayout.VERTICAL);
        mapTopOverlay.setPadding(dp(10), dp(10), dp(10), dp(4));

        LinearLayout searchBar = new LinearLayout(this);
        searchBar.setOrientation(LinearLayout.HORIZONTAL);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setBackground(makeRoundedBg("#E6111827", "#334155", 10));
        searchBar.setPadding(dp(10), dp(4), dp(8), dp(4));

        mapSearchInput = new EditText(this);
        mapSearchInput.setHint("Haritada adres, şarj istasyonu veya hedef ara...");
        mapSearchInput.setHintTextColor(Color.parseColor("#94A3B8"));
        mapSearchInput.setTextColor(Color.WHITE);
        mapSearchInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        mapSearchInput.setSingleLine(true);
        mapSearchInput.setBackgroundColor(Color.TRANSPARENT);
        searchBar.addView(mapSearchInput, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button goSearchBtn = makeMiniPillButton("🔍 Rota Çiz", () -> {
            String q = mapSearchInput.getText().toString().trim();
            if (!q.isEmpty()) searchAndRouteOnMap(q);
        });
        Button chargersBtn = makeMiniPillButton("⚡ Şarj İstasyonları", () -> searchAndRouteOnMap("Elektrikli Araç Şarj İstasyonu"));
        Button myLocBtn = makeMiniPillButton("📍 Konumum", () -> {
            if (mapLiteReady && mapLiteWebView != null) {
                mapLiteWebView.evaluateJavascript("window.LITE && window.LITE.recenter();", null);
            }
        });
        Button clearRouteBtn = makeMiniPillButton("✕", () -> {
            navBannerText.setVisibility(View.GONE);
            if (mapLiteReady && mapLiteWebView != null) {
                mapLiteWebView.evaluateJavascript("window.LITE && window.LITE.setRoute([]);", null);
            }
        });

        searchBar.addView(goSearchBtn);
        searchBar.addView(chargersBtn);
        searchBar.addView(myLocBtn);
        searchBar.addView(clearRouteBtn);
        mapTopOverlay.addView(searchBar);

        navBannerText = new TextView(this);
        navBannerText.setTextColor(Color.parseColor("#4ADE80"));
        navBannerText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        navBannerText.setTypeface(Typeface.DEFAULT_BOLD);
        navBannerText.setBackground(makeRoundedBg("#E60F172A", "#22C55E", 8));
        navBannerText.setPadding(dp(12), dp(6), dp(12), dp(6));
        navBannerText.setVisibility(View.GONE);
        mapTopOverlay.addView(navBannerText);

        mapCard.addView(mapTopOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        rightCol.addView(mapCard);

        // 2. NATIVE REAL MEDIA & APP PLAYER CARD (Bottom 27% of Right Pane)
        LinearLayout mediaCard = new LinearLayout(this);
        mediaCard.setOrientation(LinearLayout.VERTICAL);
        mediaCard.setBackground(makeRoundedBg("#101622", "#1E293B", 16));
        mediaCard.setPadding(dp(14), dp(8), dp(14), dp(8));
        mediaCard.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 0.27f));

        // Top row of Media Card: Track Title/Artist + Transport Controls
        LinearLayout trackRow = new LinearLayout(this);
        trackRow.setOrientation(LinearLayout.HORIZONTAL);
        trackRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout metaCol = new LinearLayout(this);
        metaCol.setOrientation(LinearLayout.VERTICAL);
        metaCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        mediaTitleText = new TextView(this);
        mediaTitleText.setText("Medya Hazır — Kaynak Seçin");
        mediaTitleText.setTextColor(Color.WHITE);
        mediaTitleText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        mediaTitleText.setTypeface(Typeface.DEFAULT_BOLD);
        mediaTitleText.setSingleLine(true);
        metaCol.addView(mediaTitleText);

        mediaArtistText = new TextView(this);
        mediaArtistText.setText("Spotify • YouTube • YT Music • FM Radyo • Bluetooth");
        mediaArtistText.setTextColor(Color.parseColor("#94A3B8"));
        mediaArtistText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        mediaArtistText.setSingleLine(true);
        metaCol.addView(mediaArtistText);
        trackRow.addView(metaCol);

        Button prevBtn = makeMiniPillButton("⏮", () -> mediaRouter.dispatchMediaAction("PREV"));
        playPauseBtn = makeMiniPillButton("⏯ Oynat/Duraklat", () -> mediaRouter.dispatchMediaAction("PLAY_PAUSE"));
        Button nextBtn = makeMiniPillButton("⏭", () -> mediaRouter.dispatchMediaAction("NEXT"));
        Button volDownBtn = makeMiniPillButton("🔉 -", () -> vehicleController.adjustSystemVolume(-1));
        Button volUpBtn = makeMiniPillButton("🔊 +", () -> vehicleController.adjustSystemVolume(1));

        trackRow.addView(prevBtn);
        trackRow.addView(playPauseBtn);
        trackRow.addView(nextBtn);
        trackRow.addView(volDownBtn);
        trackRow.addView(volUpBtn);
        mediaCard.addView(trackRow);

        // Bottom row of Media Card: One-Tap Real Media & Video App Launchers
        HorizontalScrollView mediaSourcesScroll = new HorizontalScrollView(this);
        mediaSourcesScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout srcRow = new LinearLayout(this);
        srcRow.setOrientation(LinearLayout.HORIZONTAL);
        srcRow.setPadding(0, dp(6), 0, 0);

        srcRow.addView(makeMediaAppButton("🎵 Spotify", "#1DB954", () -> {
            if (!mediaRouter.openSpotify()) {
                Toast.makeText(this, "Spotify kurulu değil — GMS-Free Uygulama Merkezi açılıyor", Toast.LENGTH_SHORT).show();
                NativeDialogs.showAppHubSheet(this, mediaHub, mediaRouter, appStore);
            }
        }));
        srcRow.addView(makeMediaAppButton("▶️ YouTube (SmartTube/NewPipe)", "#DC2626", () -> {
            if (!mediaRouter.openYouTubeVideo()) {
                Toast.makeText(this, "SmartTube/NewPipe kurulu değil — GMS-Free Uygulama Merkezi açılıyor", Toast.LENGTH_SHORT).show();
                NativeDialogs.showAppHubSheet(this, mediaHub, mediaRouter, appStore);
            }
        }));
        srcRow.addView(makeMediaAppButton("🎧 YT Music (Metrolist)", "#E11D48", () -> {
            if (!mediaRouter.openYouTubeMusic()) {
                Toast.makeText(this, "Metrolist YT Music kurulu değil — GMS-Free Uygulama Merkezi açılıyor", Toast.LENGTH_SHORT).show();
                NativeDialogs.showAppHubSheet(this, mediaHub, mediaRouter, appStore);
            }
        }));
        srcRow.addView(makeMediaAppButton("📻 OEM FM Radyo", "#0284C7", () -> mediaRouter.openFmRadio()));
        srcRow.addView(makeMediaAppButton("🌐 Canlı TRT FM", "#2563EB", () -> {
            mediaHub.playInternetRadioStream("TRT FM", "91.4 MHz • Canlı Yayın",
                    "https://trtcanlifm-lh.akamaihd.net/i/TRTFM_1@181846/master.m3u8");
            updateClockAndMediaUi();
        }));
        srcRow.addView(makeMediaAppButton("🌐 PowerTürk", "#2563EB", () -> {
            mediaHub.playInternetRadioStream("PowerTürk FM", "99.8 MHz • Türkçe Pop",
                    "https://live.powerapp.com.tr/powerturk/mpeg/icecast.audio");
            updateClockAndMediaUi();
        }));
        srcRow.addView(makeMediaAppButton("📱 BT Müzik", "#334155", () -> mediaRouter.openBluetoothMusic()));
        srcRow.addView(makeMediaAppButton("💾 USB Müzik", "#334155", () -> mediaRouter.openUsbLocalMusic()));

        mediaSourcesScroll.addView(srcRow);
        mediaCard.addView(mediaSourcesScroll);

        rightCol.addView(mediaCard);
        return rightCol;
    }

    private View buildBottomTeslaDock() {
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setBackgroundColor(Color.parseColor("#0D121B"));
        dock.setPadding(dp(12), dp(6), dp(12), dp(6));

        dock.addView(makeDockButton("🚗 Araç & ADAS", "#1E293B",
                () -> NativeDialogs.showVehicleControlSheet(this, vehicleController, this::openSetupWizard)));

        dock.addView(makeDockButton("—", "#1E293B", () -> {
            float cur = Float.isNaN(vehicleController.getState().hvacTargetTemp) ? 22.0f : vehicleController.getState().hvacTargetTemp;
            vehicleController.setHvacTemperature(cur - 0.5f);
        }));

        dockClimateBtn = makeDockButton("❄️ Klima: --.-°C", "#0284C7",
                () -> NativeDialogs.showClimateSheet(this, vehicleController));
        dock.addView(dockClimateBtn);

        dock.addView(makeDockButton("+", "#1E293B", () -> {
            float cur = Float.isNaN(vehicleController.getState().hvacTargetTemp) ? 22.0f : vehicleController.getState().hvacTargetTemp;
            vehicleController.setHvacTemperature(cur + 0.5f);
        }));

        dockSeatBtn = makeDockButton("💺 Koltuk: Kapalı", "#1E293B",
                () -> NativeDialogs.showClimateSheet(this, vehicleController));
        dock.addView(dockSeatBtn);

        dock.addView(makeDockButton("📱 Uygulamalar & APK", "#1E293B",
                () -> NativeDialogs.showAppHubSheet(this, mediaHub, mediaRouter, appStore)));

        dock.addView(makeDockButton("📞 Telefon", "#1E293B",
                () -> NativeDialogs.showPhoneSheet(this)));

        dock.addView(makeDockButton("🎙 Sesli Asistan", "#1E293B",
                () -> NativeDialogs.showVoiceSheet(this, voiceAssistant)));

        dock.addView(makeDockButton("📷 Kamera", "#1E293B",
                () -> showReverseCameraOverlay(true)));

        dock.addView(makeDockButton("🔑 Kurulum", "#1E293B",
                this::openSetupWizard));

        return dock;
    }

    private FrameLayout buildReverseCameraOverlay() {
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.BLACK);
        overlay.setVisibility(View.GONE);

        cameraSurfaceView = new SurfaceView(this);
        overlay.addView(cameraSurfaceView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        cameraHelper = new Et5ReverseCameraHelper(this);
        cameraHelper.attachToSurfaceView(cameraSurfaceView);

        cameraRadarText = new TextView(this);
        cameraRadarText.setText("360° AVM / GERİ GÖRÜŞ KAMERASI AKTİF");
        cameraRadarText.setTextColor(Color.WHITE);
        cameraRadarText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        cameraRadarText.setTypeface(Typeface.DEFAULT_BOLD);
        cameraRadarText.setBackgroundColor(0xAA000000);
        cameraRadarText.setPadding(dp(18), dp(10), dp(18), dp(10));
        FrameLayout.LayoutParams radarLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        radarLp.topMargin = dp(18);
        overlay.addView(cameraRadarText, radarLp);

        Button closeCamBtn = new Button(this);
        closeCamBtn.setText("✕ Kamerayı Kapat");
        closeCamBtn.setAllCaps(false);
        closeCamBtn.setTextColor(Color.WHITE);
        closeCamBtn.setBackground(makeRoundedBg("#DC2626", "#EF4444", 10));
        closeCamBtn.setPadding(dp(20), dp(10), dp(20), dp(10));
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        closeLp.topMargin = dp(18);
        closeLp.rightMargin = dp(20);
        closeCamBtn.setOnClickListener(v -> showReverseCameraOverlay(false));
        overlay.addView(closeCamBtn, closeLp);

        return overlay;
    }

    public void openSetupWizard() {
        if (activeSetupDialog != null && activeSetupDialog.isShowing()) {
            return;
        }
        activeSetupDialog = new SetupWizardDialog(this, vehicleController, () -> {
            onVehicleStateChanged(vehicleController.getState());
        });
        activeSetupDialog.show();
    }

    @Override
    public void onVehicleStateChanged(final VehicleState st) {
        mainHandler.post(() -> {
            // 1. Update Gear Strip
            String[] gears = new String[]{"P", "R", "N", "D"};
            for (int i = 0; i < 4; i++) {
                boolean active = gears[i].equals(st.gear);
                gearPills[i].setTextColor(active ? Color.parseColor("#38BDF8") : Color.parseColor("#475569"));
                gearPills[i].setTextSize(TypedValue.COMPLEX_UNIT_SP, active ? 18 : 14);
            }
            autoHoldBadge.setVisibility(st.autoHold ? View.VISIBLE : View.GONE);

            // 2. Signals & Lights
            StringBuilder sig = new StringBuilder();
            if (st.turnLeft || st.hazardLights) sig.append("◄ ");
            if (st.turnRight || st.hazardLights) sig.append("► ");
            if (st.lowBeam) sig.append("💡 ");
            if (st.highBeam) sig.append("🔵 ");
            signalsBadge.setText(sig.toString());

            // 3. Top Battery, Range, Power & Temps (Zero fake numbers)
            batteryRangeTopText.setText("🔋 " + st.formatSoc() + "  •  " + st.formatRange()
                    + (st.chargingActive ? " ⚡ ŞARJ OLUYOR" : ("  •  " + st.formatPowerKw())));
            tempTopText.setText("İç: " + st.formatCabinTemp() + "  |  Dış: " + st.formatOutsideTemp());

            // 4. Bridge Status Pill
            if (st.helperConnected) {
                bridgeStatusBtn.setText("● CAN-Bus Aktif (8724)");
                bridgeStatusBtn.setBackground(makeRoundedBg("#15803D", "#22C55E", 8));
            } else {
                bridgeStatusBtn.setText("▲ Kurulum / ADB Sihirbazı");
                bridgeStatusBtn.setBackground(makeRoundedBg("#D97706", "#F59E0B", 8));
            }

            // 5. Left Stage Speed, Drive Mode, Odometer & TPMS
            speedValueText.setText(String.valueOf(st.speedKmh));
            String modeStr = st.driveMode == 2 ? "SPORT" : (st.driveMode == 1 ? "ECO" : "NORMAL");
            driveModeBadge.setText(modeStr + " • %" + st.regenPercent);
            odoAndConsText.setText("Sayaç: " + st.formatOdometer() + "\nTük: " + st.formatConsumption());

            String[] wheelLabels = new String[]{"Ön Sol", "Ön Sağ", "Arka Sol", "Arka Sağ"};
            for (int i = 0; i < 4; i++) {
                tpmsBadges[i].setText(wheelLabels[i] + "\n" + st.formatTireBar(i) + " (" + st.formatTireTemp(i) + ")");
            }

            lockQuickBtn.setText(st.locked ? "🔒 Kilitli" : "🔓 Açık");
            trunkQuickBtn.setText(st.trunkOpen ? "🚗 Bagaj Açık" : "🚗 Bagaj");
            chargePortQuickBtn.setText(st.chargePortOpen ? "⚡ Kapak Açık" : "⚡ Şarj");

            // 6. Bottom Dock Climate & Seat Summaries
            dockClimateBtn.setText("❄️ Klima: " + (st.hvacPower ? st.formatHvacTargetTemp() : "Kapalı (" + st.formatHvacTargetTemp() + ")"));
            String seatSummary = (st.driverSeatHeat > 0 ? "🔥S:" + st.driverSeatHeat : "")
                    + (st.driverSeatVent > 0 ? " ❄️S:" + st.driverSeatVent : "")
                    + (st.passengerSeatHeat > 0 ? " 🔥Y:" + st.passengerSeatHeat : "")
                    + (st.passengerSeatVent > 0 ? " ❄️Y:" + st.passengerSeatVent : "");
            dockSeatBtn.setText(seatSummary.trim().isEmpty() ? "💺 Koltuk" : "💺 " + seatSummary.trim());

            // 7. Push Door/Hood/Trunk/Light State to 3D Car View
            pushStateToCar3d(st);
        });
    }

    @Override
    public void onReverseGearChanged(boolean inReverse) {
        showReverseCameraOverlay(inReverse);
    }

    @Override
    public void onSteeringVoiceButtonPressed() {
        NativeDialogs.showVoiceSheet(this, voiceAssistant);
    }

    private void pushStateToCar3d(VehicleState st) {
        if (!car3dReady || car3dWebView == null) return;
        String json = st.toCar3dStateJson().toString();
        if (json.equals(lastCar3dJson)) return;
        lastCar3dJson = json;
        car3dWebView.evaluateJavascript("window.CAR && window.CAR.state(" + json + ");", null);
    }

    private void updateClockAndMediaUi() {
        if (clockText != null) {
            clockText.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
        }
        if (mediaHub != null && mediaTitleText != null) {
            JSONObject info = mediaHub.getActiveMediaInfo();
            String title = info.optString("title", "Medya Hazır");
            String artist = info.optString("artist", "");
            boolean playing = info.optBoolean("playing", false);
            mediaTitleText.setText((playing ? "▶ " : "⏸ ") + title);
            mediaArtistText.setText(artist);
        }
    }

    /**
     * Real Nominatim Geocoding + OSRM Turn-by-Turn Route Calculation for Map-Lite.
     */
    private void searchAndRouteOnMap(final String query) {
        Toast.makeText(this, "\"" + query + "\" aranıyor ve rota hesaplanıyor...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String nomUrl = "https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=tr&q="
                        + URLEncoder.encode(query, "UTF-8");
                conn = (HttpURLConnection) new URL(nomUrl).openConnection();
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(7000);
                conn.setRequestProperty("User-Agent", "SkywellET5-TeslaLauncher/3.0 (Android Automotive)");
                if (conn.getResponseCode() != 200) return;

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                conn.disconnect();

                JSONArray results = new JSONArray(sb.toString());
                if (results.length() == 0) {
                    mainHandler.post(() -> Toast.makeText(this, "Konum bulunamadı: " + query, Toast.LENGTH_SHORT).show());
                    return;
                }
                JSONObject first = results.getJSONObject(0);
                final double destLat = Double.parseDouble(first.getString("lat"));
                final double destLon = Double.parseDouble(first.getString("lon"));
                final String dispName = first.optString("display_name", query).split(",")[0];

                // Query OSRM for road geometry, distance, and duration
                String osrmUrl = String.format(Locale.US,
                        "https://router.project-osrm.org/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full&geometries=geojson",
                        currentLon, currentLat, destLon, destLat);
                conn = (HttpURLConnection) new URL(osrmUrl).openConnection();
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(8000);
                conn.setRequestProperty("User-Agent", "SkywellET5-TeslaLauncher/3.0");

                final JSONArray latLonArray = new JSONArray();
                double distKm = 0;
                int durMin = 0;
                if (conn.getResponseCode() == 200) {
                    BufferedReader r2 = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder sb2 = new StringBuilder();
                    String l2;
                    while ((l2 = r2.readLine()) != null) sb2.append(l2);
                    JSONObject osrmRoot = new JSONObject(sb2.toString());
                    JSONArray routes = osrmRoot.optJSONArray("routes");
                    if (routes != null && routes.length() > 0) {
                        JSONObject rt = routes.getJSONObject(0);
                        distKm = rt.optDouble("distance", 0) / 1000.0;
                        durMin = (int) Math.round(rt.optDouble("duration", 0) / 60.0);
                        JSONObject geom = rt.optJSONObject("geometry");
                        if (geom != null) {
                            JSONArray coords = geom.optJSONArray("coordinates");
                            if (coords != null) {
                                for (int i = 0; i < coords.length(); i++) {
                                    JSONArray pt = coords.getJSONArray(i);
                                    JSONArray latLon = new JSONArray();
                                    latLon.put(pt.getDouble(1));
                                    latLon.put(pt.getDouble(0));
                                    latLonArray.put(latLon);
                                }
                            }
                        }
                    }
                }
                final double finalDistKm = distKm;
                final int finalDurMin = durMin;
                mainHandler.post(() -> {
                    navBannerText.setVisibility(View.VISIBLE);
                    navBannerText.setText(String.format(Locale.getDefault(),
                            "🧭 Hedef: %s  •  %.1f km  •  ~%d dk", dispName, finalDistKm, finalDurMin));
                    if (mapLiteReady && mapLiteWebView != null && latLonArray.length() > 0) {
                        mapLiteWebView.evaluateJavascript("window.LITE && window.LITE.setRoute(" + latLonArray + ");", null);
                    }
                });
            } catch (Throwable ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
        }, "Et5-MapRoute").start();
    }

    public void showReverseCameraOverlay(final boolean show) {
        mainHandler.post(() -> {
            if (cameraOverlay == null) return;
            if (show) {
                AdbRootBridge.stopSkyworthEvsService(this);
                cameraOverlay.setVisibility(View.VISIBLE);
                VehicleState st = vehicleController.getState();
                float minRear = Float.NaN;
                for (float d : st.radarRear) {
                    if (!Float.isNaN(d) && (Float.isNaN(minRear) || d < minRear)) minRear = d;
                }
                cameraRadarText.setText(Float.isNaN(minRear)
                        ? "360° AVM / GERİ GÖRÜŞ KAMERASI AKTİF"
                        : String.format(Locale.US, "GERİ GÖRÜŞ — Arka Engel Mesafesi: %.2f m", minRear));
            } else {
                cameraOverlay.setVisibility(View.GONE);
            }
        });
    }

    @SuppressLint("MissingPermission")
    private void startRealGpsTracking() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return;
            LocationListener listener = new LocationListener() {
                @Override
                public void onLocationChanged(Location loc) {
                    if (loc == null) return;
                    hasRealGpsFix = true;
                    currentLat = loc.getLatitude();
                    currentLon = loc.getLongitude();
                    if (loc.hasBearing()) currentBearing = loc.getBearing();
                    if (mapLiteReady && mapLiteWebView != null) {
                        final String js = String.format(Locale.US,
                                "window.LITE && window.LITE.setPos(%.6f,%.6f,%.1f,false);",
                                currentLat, currentLon, currentBearing);
                        mainHandler.post(() -> mapLiteWebView.evaluateJavascript(js, null));
                    }
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            };
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1.0f, listener);
                Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last != null) listener.onLocationChanged(last);
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2500L, 5.0f, listener);
                if (!hasRealGpsFix) {
                    Location lastNet = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (lastNet != null) listener.onLocationChanged(lastNet);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureAssetWebView(WebView wv, Object jsBridge, String jsName, Runnable onPageFinished) {
        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        wv.addJavascriptInterface(jsBridge, jsName);
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                String prefix = "https://" + ASSET_HOST + "/assets/";
                if (url.startsWith(prefix)) {
                    String assetPath = url.substring(prefix.length());
                    int qIdx = assetPath.indexOf('?');
                    if (qIdx >= 0) assetPath = assetPath.substring(0, qIdx);
                    try {
                        InputStream is = getAssets().open(assetPath);
                        String mime = guessMimeType(assetPath);
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Access-Control-Allow-Origin", "*");
                        return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, is);
                    } catch (Exception ignored) {
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (onPageFinished != null) onPageFinished.run();
            }
        });
    }

    public final class Car3dBridge {
        @JavascriptInterface
        public void onPart(String part) {
            mainHandler.post(() -> {
                VehicleState st = vehicleController.getState();
                if ("trunk".equals(part)) vehicleController.setPowerTrunk(!st.trunkOpen);
                else if ("charge".equals(part)) vehicleController.setChargePort(!st.chargePortOpen);
                else if (part != null && part.startsWith("d")) vehicleController.setDoorLocks(!st.locked);
            });
        }

        @JavascriptInterface
        public void onLabel(String side, float x, float y, float dist) {
        }

        @JavascriptInterface
        public void ready() {
            car3dReady = true;
            mainHandler.post(() -> pushStateToCar3d(vehicleController.getState()));
        }
    }

    public final class MapLiteBridge {
        @JavascriptInterface
        public void onTap(double lat, double lon) {
        }

        @JavascriptInterface
        public void onFollow(boolean follow) {
        }

        @JavascriptInterface
        public void onPois(String json) {
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST
                || keyCode == KeyEvent.KEYCODE_SEARCH
                || keyCode == 231) {
            long now = System.currentTimeMillis();
            if (now - lastVoiceKeyTimeMs < 1500L) {
                voiceKeyBurstCount++;
            } else {
                voiceKeyBurstCount = 1;
            }
            lastVoiceKeyTimeMs = now;
            if (voiceKeyBurstCount >= 6) {
                voiceKeyBurstCount = 0;
                AdbRootBridge.restoreStockLauncher(this);
                return true;
            }
            NativeDialogs.showVoiceSheet(this, voiceAssistant);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        enableImmersiveFullscreen();
        mainHandler.removeCallbacks(periodicTicker);
        mainHandler.post(periodicTicker);
    }

    @Override
    protected void onPause() {
        mainHandler.removeCallbacks(periodicTicker);
        vehicleController.getState().saveRealCache(this);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        vehicleController.removeListener(this);
        if (cameraHelper != null) cameraHelper.closeCamera();
        super.onDestroy();
    }

    private void enableImmersiveFullscreen() {
        try {
            Window w = getWindow();
            if (w == null) return;
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            View decor = w.getDecorView();
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        } catch (Throwable ignored) {
        }
    }

    private Button makeQuickStageButton(String text, Runnable onClick) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(makeRoundedBg("#1E293B", "#334155", 8));
        b.setPadding(dp(4), dp(2), dp(4), dp(2));
        b.setOnClickListener(v -> onClick.run());
        return b;
    }

    private Button makeMiniPillButton(String text, Runnable onClick) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(makeRoundedBg("#1E293B", "#334155", 8));
        b.setPadding(dp(10), dp(4), dp(10), dp(4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(32));
        lp.leftMargin = dp(4);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> onClick.run());
        return b;
    }

    private Button makeMediaAppButton(String text, String bgHex, Runnable onClick) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(makeRoundedBg(bgHex, "#334155", 8));
        b.setPadding(dp(12), dp(5), dp(12), dp(5));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.rightMargin = dp(6);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> onClick.run());
        return b;
    }

    private Button makeDockButton(String text, String bgHex, Runnable onClick) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(makeRoundedBg(bgHex, "#26334A", 10));
        b.setPadding(dp(11), dp(6), dp(11), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        lp.leftMargin = dp(4);
        lp.rightMargin = dp(4);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> onClick.run());
        return b;
    }

    private GradientDrawable makeRoundedBg(String fillHex, String strokeHex, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(fillHex));
        gd.setCornerRadius(dp(radiusDp));
        if (strokeHex != null) {
            gd.setStroke(Math.max(1, dp(1)), Color.parseColor(strokeHex));
        }
        return gd;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static String guessMimeType(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js") || path.endsWith(".mjs")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".json")) return "application/json";
        if (path.endsWith(".glb")) return "model/gltf-binary";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }
}
