package tr.halil.et5;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import tr.halil.et5.camera.Et5ReverseCameraHelper;
import tr.halil.et5.car.VehicleController;
import tr.halil.et5.car.VehicleState;
import tr.halil.et5.helper.AdbRootBridge;
import tr.halil.et5.media.Et5MediaHub;
import tr.halil.et5.media.OemMediaRouter;
import tr.halil.et5.setup.SetupWizardDialog;
import tr.halil.et5.store.Et5AppStore;
import tr.halil.et5.ui.NativeDialogs;
import tr.halil.et5.voice.Et5VoiceAssistant;

/**
 * MainActivity — 2023 Skywell ET5 (Skyworth EV6)
 * Birebir 109697.jpg Ana Ekran ve 109695.jpg Kurulum Ekranı Tasarımı (AbstractC1344fH + C3420zG + Mw0.a).
 *
 * - Sol Panel (%34): P R N D, Dış/İç Sıcaklık, Wi-Fi/BT/Batarya, Üstten Görünüm 3D Beyaz ET5 + Park Radarı (cm),
 *   Şarj Durum Çubuğu, [Bagaj | (H) Hold | Saat | Ayarlar] Hapları ve Albüm Kapaklı Spotify/Medya Kartı.
 * - Sağ Panel (%66):
 *   1) Açık Kaynak Harita (CartoDB / OpenStreetMap — anında yüklenen, 100m dönüş kartı ve Bitir rota çubuğu ile)
 *   2) Gerçek Çalışan YouTube (Tam m.youtube.com + Otomatik Reklam Atlama + Arama + SmartTube/NewPipe Köprüsü)
 *   3) Gerçek Çalışan Spotify (Spotify APK MediaSession + open.spotify.com + Sürüş Listeleri + Tek Tıkla APK Kurucu)
 * - Alt Dock Bar (54dp): [🚗] [< 22,0° >] [💨 1] [💺] | [🧭 Harita] [🟢 Spotify] [▶️ YouTube] [📞] [🎵] [📷] [⚡] [田] [🔑] | [< 🔊 12 >]
 */
public final class MainActivity extends Activity implements VehicleController.StateListener {

    private static final String ASSET_HOST = "appassets.androidplatform.net";

    // Exact SkyOS Dark Theme Colors (Mw0.a)
    private static final String COL_BG = "#000000";
    private static final String COL_LEFT_PANEL = "#16181E";
    private static final String COL_DOCK = "#111318";
    private static final String COL_CARD = "#1E222B";
    private static final String COL_CARD_ACTIVE = "#2B3240";
    private static final String COL_TEXT = "#F4F5F7";
    private static final String COL_TEXT2 = "#9BA1A4";
    private static final String COL_TEXT3 = "#5C6266";
    private static final String COL_BLUE = "#3E6AE1";
    private static final String COL_GREEN = "#34C759";
    private static final String COL_AMBER = "#FFB020";
    private static final String COL_RED = "#FF3B30";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private VehicleController vehicleController;
    private OemMediaRouter mediaRouter;
    private Et5VoiceAssistant voiceAssistant;
    private Et5MediaHub mediaHub;
    private Et5AppStore appStore;

    // Left Panel Views (109697.jpg exact structure)
    private final TextView[] gearViews = new TextView[4]; // P, R, N, D
    private TextView topStatusRightText; // 📶 ᛒ 🔋 46% ⚡ · 261 km
    private TextView tempHeaderText; // Dış 14°   İç 21°
    private TextView speedHeaderText; // 0 km/s
    private WebView car3dWebView;
    private volatile boolean car3dReady = false;
    private String lastCar3dJson = "";
    private TextView radarDistanceBadge; // 85 cm amber badge above car
    private boolean carTopView = true;

    // Left Panel Bottom Stack (Charging + 4 Pills + Media Card)
    private LinearLayout chargingBannerRow;
    private TextView chargingBannerText;
    private TextView pillTrunkView;
    private TextView pillHoldView;
    private TextView pillClockView;
    private TextView mediaCoverBadge;
    private TextView mediaSongTitle;
    private TextView mediaSongArtist;
    private TextView mediaPlayPauseBtn;

    // Right Pane Multi-Layer Stage (0 = Map, 1 = Spotify, 2 = YouTube)
    private int activeRightTab = 0;
    private FrameLayout mapLayer;
    private LinearLayout spotifyLayer;
    private LinearLayout youtubeLayer;

    // Map Layer Floating Views (109697.jpg exact match)
    private WebView mapLiteWebView;
    private volatile boolean mapLiteReady = false;
    private boolean mapDarkStyle = true;
    private LinearLayout mapSearchPill;
    private EditText mapSearchInput;
    private LinearLayout navTurnCard;
    private TextView navTurnDistText;
    private TextView navTurnStreetText;
    private LinearLayout navBottomEtaBar;
    private TextView navEtaText;

    // Voice Assistant Floating Overlay on Map (109697.jpg exact match)
    private LinearLayout voiceFloatingOverlay;
    private TextView voiceTranscriptText;
    private TextView voiceReplyText;

    // Built-in Real Spotify Layer Views
    private WebView spotifyWebView;
    private boolean spotifyWebLoaded = false;
    private EditText spotifySearchInput;
    private TextView spotifyStatusText;

    // Built-in Real YouTube Layer Views
    private WebView youtubeWebView;
    private boolean youtubeWebLoaded = false;
    private EditText youtubeSearchInput;

    // Bottom Dock Bar Views (109697.jpg exact match)
    private TextView dockTempText;
    private TextView dockFanText;
    private TextView dockSeatText;
    private final TextView[] dockCenterIcons = new TextView[9];
    private TextView dockVolumeText;

    // Reverse Camera Overlay
    private FrameLayout cameraOverlay;
    private SurfaceView cameraSurfaceView;
    private TextView cameraRadarText;
    private Et5ReverseCameraHelper cameraHelper;

    // Real GPS State (Default Mersin, Türkiye until GPS lock)
    private volatile boolean hasRealGpsFix = false;
    private volatile double currentLat = 36.8000;
    private volatile double currentLon = 34.6333;
    private volatile float currentBearing = 0f;

    private int voiceKeyBurstCount = 0;
    private long lastVoiceKeyTimeMs = 0L;
    private SetupWizardDialog activeSetupDialog;

    private final Runnable clockAndMediaTicker = new Runnable() {
        @Override
        public void run() {
            refreshClockVolumeAndMedia();
            mainHandler.postDelayed(this, 2000);
        }
    };

    @SuppressLint({"SetJavaScriptEnabled", "MissingPermission"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enableImmersiveFullscreen();

        Et5App app = Et5App.getInstance();
        vehicleController = app.getVehicleController();
        mediaRouter = app.getMediaRouter();
        voiceAssistant = app.getVoiceAssistant();
        mediaHub = app.getMediaHub();
        appStore = app.getAppStore();

        setupVoiceCallback();
        buildExactSkyOsUi();

        vehicleController.addListener(this);
        onVehicleStateChanged(vehicleController.getState());
        startRealGpsTracking();

        // Mandatory SkyOS Kurulum Wizard on first launch (109695.jpg)
        mainHandler.postDelayed(() -> {
            if (!AdbRootBridge.isSetupCompleted(this) && !AdbRootBridge.isHelperAlive()) {
                openSetupWizard();
            } else if (!AdbRootBridge.isHelperAlive()) {
                AdbRootBridge.bootstrapHelperAsync(this);
            }
        }, 500);
    }

    private void buildExactSkyOsUi() {
        FrameLayout rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(Color.parseColor(COL_BG));

        LinearLayout mainVertical = new LinearLayout(this);
        mainVertical.setOrientation(LinearLayout.VERTICAL);
        rootFrame.addView(mainVertical, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 1. UPPER SPLIT STAGE (Left 34% Vehicle Column | Right 66% Map / Spotify / YouTube)
        LinearLayout splitStage = new LinearLayout(this);
        splitStage.setOrientation(LinearLayout.HORIZONTAL);
        mainVertical.addView(splitStage, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));

        LinearLayout leftVehiclePanel = buildLeftVehiclePanel();
        splitStage.addView(leftVehiclePanel, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 0.34f));

        FrameLayout rightStage = buildRightMultiStage();
        splitStage.addView(rightStage, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 0.66f));

        // 2. BOTTOM FULL-WIDTH DOCK BAR (54dp height, #111318 — exact 109697.jpg)
        mainVertical.addView(buildBottomDockBar(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        // 3. REVERSE / 360 CAMERA OVERLAY
        cameraOverlay = buildReverseCameraOverlay();
        rootFrame.addView(cameraOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(rootFrame);
    }

    // =========================================================================
    // LEFT VEHICLE PANEL (34% WIDTH — EXACT 109697.jpg LAYOUT)
    // =========================================================================
    @SuppressLint("SetJavaScriptEnabled")
    private LinearLayout buildLeftVehiclePanel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.parseColor(COL_LEFT_PANEL));
        panel.setPadding(dp(14), dp(12), dp(14), dp(10));

        // Header Row 1: P R N D on left | 📶 ᛒ 🔋 46% ⚡ · 261 km on right
        LinearLayout headerRow1 = new LinearLayout(this);
        headerRow1.setOrientation(LinearLayout.HORIZONTAL);
        headerRow1.setGravity(Gravity.CENTER_VERTICAL);

        String[] gears = new String[]{"P", "R", "N", "D"};
        for (int i = 0; i < 4; i++) {
            TextView gv = new TextView(this);
            gv.setText(gears[i]);
            gv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            gv.setTypeface(Typeface.DEFAULT_BOLD);
            gv.setPadding(0, 0, dp(10), 0);
            gearViews[i] = gv;
            headerRow1.addView(gv);
        }

        View hSpacer = new View(this);
        headerRow1.addView(hSpacer, new LinearLayout.LayoutParams(0, 1, 1f));

        topStatusRightText = new TextView(this);
        topStatusRightText.setText("📶  ᛒ  🔋 --% · -- km");
        topStatusRightText.setTextColor(Color.parseColor(COL_TEXT));
        topStatusRightText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        topStatusRightText.setTypeface(Typeface.DEFAULT_BOLD);
        topStatusRightText.setOnClickListener(v -> {
            if (!vehicleController.getState().helperConnected) {
                openSetupWizard();
            } else {
                NativeDialogs.showVehicleControlSheet(this, vehicleController, this::openSetupWizard);
            }
        });
        headerRow1.addView(topStatusRightText);
        panel.addView(headerRow1);

        // Header Row 2: Dış 14°  İç 21° on left | Speed on right
        LinearLayout headerRow2 = new LinearLayout(this);
        headerRow2.setOrientation(LinearLayout.HORIZONTAL);
        headerRow2.setGravity(Gravity.CENTER_VERTICAL);
        headerRow2.setPadding(0, dp(2), 0, dp(2));

        tempHeaderText = new TextView(this);
        tempHeaderText.setText("Dış --°   İç --°");
        tempHeaderText.setTextColor(Color.parseColor(COL_TEXT2));
        tempHeaderText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        headerRow2.addView(tempHeaderText);

        View hSpacer2 = new View(this);
        headerRow2.addView(hSpacer2, new LinearLayout.LayoutParams(0, 1, 1f));

        speedHeaderText = new TextView(this);
        speedHeaderText.setText("");
        speedHeaderText.setTextColor(Color.parseColor(COL_TEXT));
        speedHeaderText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        speedHeaderText.setTypeface(Typeface.DEFAULT_BOLD);
        headerRow2.addView(speedHeaderText);
        panel.addView(headerRow2);

        // Center: 3D White Skywell ET5 Stage + Ultrasonic Distance Badge (85 cm)
        FrameLayout carStage = new FrameLayout(this);
        carStage.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));

        car3dWebView = new WebView(this);
        car3dWebView.setBackgroundColor(Color.TRANSPARENT);
        car3dWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        configureAssetWebView(car3dWebView, new Car3dBridge(), "Et5", () -> {
            car3dReady = true;
            car3dWebView.evaluateJavascript("window.CAR && window.CAR.view('park', 0);", null);
            pushStateToCar3d(vehicleController.getState());
        });
        car3dWebView.loadUrl("https://" + ASSET_HOST + "/assets/car/index.html");
        carStage.addView(car3dWebView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Radar distance label (e.g., "85 cm" in amber right above the front bumper like 109697.jpg)
        radarDistanceBadge = new TextView(this);
        radarDistanceBadge.setText("85 cm");
        radarDistanceBadge.setTextColor(Color.parseColor(COL_AMBER));
        radarDistanceBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        radarDistanceBadge.setTypeface(Typeface.DEFAULT_BOLD);
        radarDistanceBadge.setBackground(makeBox("#CC1A1B1E", COL_AMBER, 8));
        radarDistanceBadge.setPadding(dp(8), dp(2), dp(8), dp(2));
        radarDistanceBadge.setVisibility(View.GONE);
        FrameLayout.LayoutParams radLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        radLp.topMargin = dp(6);
        carStage.addView(radarDistanceBadge, radLp);

        // Subtle view angle toggle button in top-right of 3D stage
        TextView angleToggle = new TextView(this);
        angleToggle.setText("3D / Üst");
        angleToggle.setTextColor(Color.parseColor(COL_TEXT2));
        angleToggle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        angleToggle.setBackground(makeBox("#881E222B", null, 8));
        angleToggle.setPadding(dp(8), dp(3), dp(8), dp(3));
        angleToggle.setOnClickListener(v -> {
            carTopView = !carTopView;
            if (car3dReady && car3dWebView != null) {
                car3dWebView.evaluateJavascript("window.CAR && window.CAR.view('"
                        + (carTopView ? "park" : "parked") + "', 550);", null);
            }
        });
        FrameLayout.LayoutParams angLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        angLp.topMargin = dp(4);
        carStage.addView(angleToggle, angLp);

        panel.addView(carStage);

        // Charging Status Pill (109697.jpg: "⚡ Şarj oluyor · %46 · 11 kW" + "Şarjı bitir")
        chargingBannerRow = new LinearLayout(this);
        chargingBannerRow.setOrientation(LinearLayout.HORIZONTAL);
        chargingBannerRow.setGravity(Gravity.CENTER_VERTICAL);
        chargingBannerRow.setBackground(makeBox(COL_CARD, null, 12));
        chargingBannerRow.setPadding(dp(12), dp(7), dp(8), dp(7));
        LinearLayout.LayoutParams chLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chLp.bottomMargin = dp(6);
        chargingBannerRow.setLayoutParams(chLp);
        chargingBannerRow.setVisibility(View.GONE);

        chargingBannerText = new TextView(this);
        chargingBannerText.setText("⚡ Şarj oluyor");
        chargingBannerText.setTextColor(Color.parseColor(COL_TEXT));
        chargingBannerText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        chargingBannerText.setTypeface(Typeface.DEFAULT_BOLD);
        chargingBannerRow.addView(chargingBannerText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView stopChargeBtn = new TextView(this);
        stopChargeBtn.setText("Şarjı bitir");
        stopChargeBtn.setTextColor(Color.WHITE);
        stopChargeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        stopChargeBtn.setTypeface(Typeface.DEFAULT_BOLD);
        stopChargeBtn.setBackground(makeBox(COL_RED, null, 8));
        stopChargeBtn.setPadding(dp(10), dp(4), dp(10), dp(4));
        stopChargeBtn.setOnClickListener(v -> vehicleController.setChargePort(false));
        chargingBannerRow.addView(stopChargeBtn);
        panel.addView(chargingBannerRow);

        // 4 Quick Pills Row (109697.jpg: [🚗 Bagaj] [(H) Hold] [01:15] [⚙️])
        LinearLayout quickPillsRow = new LinearLayout(this);
        quickPillsRow.setOrientation(LinearLayout.HORIZONTAL);
        quickPillsRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams qpLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        qpLp.bottomMargin = dp(8);
        quickPillsRow.setLayoutParams(qpLp);

        pillTrunkView = makeLeftQuickPill("🚗 Bagaj", () -> {
            VehicleState st = vehicleController.getState();
            vehicleController.setPowerTrunk(!st.trunkOpen);
        });
        pillHoldView = makeLeftQuickPill("Hold", () -> {
            VehicleState st = vehicleController.getState();
            vehicleController.setAutoHold(!st.autoHold);
        });
        pillClockView = makeLeftQuickPill(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()), null);
        TextView pillSettingsView = makeLeftQuickPill("⚙️", () ->
                NativeDialogs.showVehicleControlSheet(this, vehicleController, this::openSetupWizard));

        quickPillsRow.addView(pillTrunkView, makeWeightedPillLp(1.15f, 6));
        quickPillsRow.addView(pillHoldView, makeWeightedPillLp(1.05f, 6));
        quickPillsRow.addView(pillClockView, makeWeightedPillLp(0.95f, 6));
        quickPillsRow.addView(pillSettingsView, makeWeightedPillLp(0.65f, 0));
        panel.addView(quickPillsRow);

        // Media Player Card at bottom of Left Panel (109697.jpg: Album Art + Porselen Kalbim / Sena Şener · Spotify + ⏮ ▷ ⏭)
        LinearLayout mediaCard = new LinearLayout(this);
        mediaCard.setOrientation(LinearLayout.HORIZONTAL);
        mediaCard.setGravity(Gravity.CENTER_VERTICAL);
        mediaCard.setBackground(makeBox(COL_CARD, null, 14));
        mediaCard.setPadding(dp(10), dp(8), dp(10), dp(8));
        mediaCard.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(62)));
        mediaCard.setOnClickListener(v -> switchRightTab(1)); // Tap media card -> open Spotify / Music pane

        mediaCoverBadge = new TextView(this);
        mediaCoverBadge.setText("♫");
        mediaCoverBadge.setTextColor(Color.WHITE);
        mediaCoverBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        mediaCoverBadge.setTypeface(Typeface.DEFAULT_BOLD);
        mediaCoverBadge.setGravity(Gravity.CENTER);
        mediaCoverBadge.setBackground(makeBox("#1DB954", null, 10));
        LinearLayout.LayoutParams covLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        covLp.rightMargin = dp(10);
        mediaCard.addView(mediaCoverBadge, covLp);

        LinearLayout songCol = new LinearLayout(this);
        songCol.setOrientation(LinearLayout.VERTICAL);
        songCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        mediaSongTitle = new TextView(this);
        mediaSongTitle.setText("Spotify · Medya Hazır");
        mediaSongTitle.setTextColor(Color.parseColor(COL_TEXT));
        mediaSongTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        mediaSongTitle.setTypeface(Typeface.DEFAULT_BOLD);
        mediaSongTitle.setSingleLine(true);
        songCol.addView(mediaSongTitle);

        mediaSongArtist = new TextView(this);
        mediaSongArtist.setText("Dinlemek için dokunun · Spotify / Radyo");
        mediaSongArtist.setTextColor(Color.parseColor(COL_TEXT2));
        mediaSongArtist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        mediaSongArtist.setSingleLine(true);
        songCol.addView(mediaSongArtist);
        mediaCard.addView(songCol);

        TextView prevBtn = makeTransportIcon("⏮", () -> mediaRouter.dispatchMediaAction("PREV"));
        mediaPlayPauseBtn = makeTransportIcon("▷", () -> mediaRouter.dispatchMediaAction("PLAY_PAUSE"));
        TextView nextBtn = makeTransportIcon("⏭", () -> mediaRouter.dispatchMediaAction("NEXT"));
        mediaCard.addView(prevBtn);
        mediaCard.addView(mediaPlayPauseBtn);
        mediaCard.addView(nextBtn);

        panel.addView(mediaCard);
        return panel;
    }

    // =========================================================================
    // RIGHT MULTI-LAYER STAGE (66% WIDTH: MAP + SPOTIFY + YOUTUBE)
    // =========================================================================
    private FrameLayout buildRightMultiStage() {
        FrameLayout stage = new FrameLayout(this);
        stage.setBackgroundColor(Color.parseColor("#1C1F26"));

        mapLayer = buildOpenSourceMapLayer();
        spotifyLayer = buildRealSpotifyLayer();
        youtubeLayer = buildRealYouTubeLayer();

        stage.addView(mapLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        stage.addView(spotifyLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        stage.addView(youtubeLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        spotifyLayer.setVisibility(View.GONE);
        youtubeLayer.setVisibility(View.GONE);
        return stage;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private FrameLayout buildOpenSourceMapLayer() {
        FrameLayout container = new FrameLayout(this);

        mapLiteWebView = new WebView(this);
        mapLiteWebView.setBackgroundColor(Color.parseColor("#1C1F26"));
        mapLiteWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        configureAssetWebView(mapLiteWebView, new MapLiteBridge(), "Et5Map", () -> {
            mapLiteReady = true;
            String js = String.format(Locale.US,
                    "if(window.LITE){window.LITE.setPos(%.6f,%.6f,%.1f,true);}",
                    currentLat, currentLon, currentBearing);
            mapLiteWebView.evaluateJavascript(js, null);
        });
        mapLiteWebView.loadUrl("https://" + ASSET_HOST + "/assets/map-lite/index.html");
        container.addView(mapLiteWebView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 1. Top-Left Floating Search Pill ("🔍 Nereye?") & Turn-by-Turn Card (109697.jpg)
        LinearLayout topLeftStack = new LinearLayout(this);
        topLeftStack.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams tlLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.START);
        tlLp.leftMargin = dp(16);
        tlLp.topMargin = dp(16);
        container.addView(topLeftStack, tlLp);

        // Turn-by-turn card (109697.jpg: blue [↱] + "100 m" + "Röneva yönünde sağa dönün")
        navTurnCard = new LinearLayout(this);
        navTurnCard.setOrientation(LinearLayout.HORIZONTAL);
        navTurnCard.setGravity(Gravity.CENTER_VERTICAL);
        navTurnCard.setBackground(makeBox("#E61A1E26", "#2B3240", 14));
        navTurnCard.setPadding(dp(12), dp(10), dp(16), dp(10));
        navTurnCard.setVisibility(View.GONE);

        TextView turnArrowBox = new TextView(this);
        turnArrowBox.setText("↱");
        turnArrowBox.setTextColor(Color.WHITE);
        turnArrowBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        turnArrowBox.setTypeface(Typeface.DEFAULT_BOLD);
        turnArrowBox.setGravity(Gravity.CENTER);
        turnArrowBox.setBackground(makeBox(COL_BLUE, null, 10));
        LinearLayout.LayoutParams taLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        taLp.rightMargin = dp(12);
        navTurnCard.addView(turnArrowBox, taLp);

        LinearLayout turnTextCol = new LinearLayout(this);
        turnTextCol.setOrientation(LinearLayout.VERTICAL);
        navTurnDistText = new TextView(this);
        navTurnDistText.setText("100 m");
        navTurnDistText.setTextColor(Color.parseColor(COL_TEXT));
        navTurnDistText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        navTurnDistText.setTypeface(Typeface.DEFAULT_BOLD);
        turnTextCol.addView(navTurnDistText);

        navTurnStreetText = new TextView(this);
        navTurnStreetText.setText("Hedef yönünde ilerleyin");
        navTurnStreetText.setTextColor(Color.parseColor(COL_TEXT2));
        navTurnStreetText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        turnTextCol.addView(navTurnStreetText);
        navTurnCard.addView(turnTextCol);
        topLeftStack.addView(navTurnCard);

        // Search Pill ("🔍 Nereye?" — AbstractC1344fH.I exact match)
        mapSearchPill = new LinearLayout(this);
        mapSearchPill.setOrientation(LinearLayout.HORIZONTAL);
        mapSearchPill.setGravity(Gravity.CENTER_VERTICAL);
        mapSearchPill.setBackground(makeBox("#D916181E", "#2B3240", 12));
        mapSearchPill.setPadding(dp(12), dp(4), dp(8), dp(4));
        LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(dp(340), dp(42));
        spLp.topMargin = dp(6);
        mapSearchPill.setLayoutParams(spLp);

        TextView searchIcon = new TextView(this);
        searchIcon.setText("🔍 ");
        searchIcon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        mapSearchPill.addView(searchIcon);

        mapSearchInput = new EditText(this);
        mapSearchInput.setHint("Nereye?");
        mapSearchInput.setHintTextColor(Color.parseColor(COL_TEXT2));
        mapSearchInput.setTextColor(Color.parseColor(COL_TEXT));
        mapSearchInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        mapSearchInput.setSingleLine(true);
        mapSearchInput.setBackgroundColor(Color.TRANSPARENT);
        mapSearchPill.addView(mapSearchInput, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView routeGoBtn = new TextView(this);
        routeGoBtn.setText("Git");
        routeGoBtn.setTextColor(Color.WHITE);
        routeGoBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        routeGoBtn.setTypeface(Typeface.DEFAULT_BOLD);
        routeGoBtn.setBackground(makeBox(COL_BLUE, null, 8));
        routeGoBtn.setPadding(dp(10), dp(5), dp(10), dp(5));
        routeGoBtn.setOnClickListener(v -> {
            String q = mapSearchInput.getText().toString().trim();
            if (!q.isEmpty()) searchAndRouteOnMap(q);
        });
        mapSearchPill.addView(routeGoBtn);

        TextView evChargePoiBtn = new TextView(this);
        evChargePoiBtn.setText("⚡");
        evChargePoiBtn.setTextColor(Color.parseColor(COL_GREEN));
        evChargePoiBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        evChargePoiBtn.setPadding(dp(8), dp(4), dp(4), dp(4));
        evChargePoiBtn.setOnClickListener(v -> searchAndRouteOnMap("Elektrikli Araç Şarj İstasyonu"));
        mapSearchPill.addView(evChargePoiBtn);

        topLeftStack.addView(mapSearchPill);

        // 2. Bottom-Left Floating Navigation ETA Bar (109697.jpg: "07:33  6 dk · 3,2 km  🔊  [Bitir]")
        navBottomEtaBar = new LinearLayout(this);
        navBottomEtaBar.setOrientation(LinearLayout.HORIZONTAL);
        navBottomEtaBar.setGravity(Gravity.CENTER_VERTICAL);
        navBottomEtaBar.setBackground(makeBox("#E61A1E26", "#2B3240", 14));
        navBottomEtaBar.setPadding(dp(14), dp(8), dp(10), dp(8));
        navBottomEtaBar.setVisibility(View.GONE);
        FrameLayout.LayoutParams blLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        blLp.leftMargin = dp(16);
        blLp.bottomMargin = dp(14);

        navEtaText = new TextView(this);
        navEtaText.setText("07:33   6 dk · 3,2 km");
        navEtaText.setTextColor(Color.parseColor(COL_TEXT));
        navEtaText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        navEtaText.setTypeface(Typeface.DEFAULT_BOLD);
        navBottomEtaBar.addView(navEtaText);

        TextView endRouteBtn = new TextView(this);
        endRouteBtn.setText("Bitir");
        endRouteBtn.setTextColor(Color.WHITE);
        endRouteBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        endRouteBtn.setTypeface(Typeface.DEFAULT_BOLD);
        endRouteBtn.setBackground(makeBox(COL_RED, null, 10));
        endRouteBtn.setPadding(dp(12), dp(5), dp(12), dp(5));
        LinearLayout.LayoutParams endLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        endLp.leftMargin = dp(12);
        endRouteBtn.setLayoutParams(endLp);
        endRouteBtn.setOnClickListener(v -> cancelNavigationRoute());
        navBottomEtaBar.addView(endRouteBtn);
        container.addView(navBottomEtaBar, blLp);

        // 3. Right Floating Compass / Recenter & Map Style Buttons (109697.jpg)
        LinearLayout rightMapBtns = new LinearLayout(this);
        rightMapBtns.setOrientation(LinearLayout.VERTICAL);
        FrameLayout.LayoutParams rmLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL | Gravity.END);
        rmLp.rightMargin = dp(14);

        TextView recenterBtn = new TextView(this);
        recenterBtn.setText("🧭");
        recenterBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        recenterBtn.setGravity(Gravity.CENTER);
        recenterBtn.setBackground(makeBox("#D91A1E26", "#2B3240", 20));
        LinearLayout.LayoutParams rcLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        rcLp.bottomMargin = dp(8);
        recenterBtn.setLayoutParams(rcLp);
        recenterBtn.setOnClickListener(v -> {
            if (mapLiteReady && mapLiteWebView != null) {
                mapLiteWebView.evaluateJavascript("window.LITE && window.LITE.recenter();", null);
            }
        });
        rightMapBtns.addView(recenterBtn);

        TextView styleBtn = new TextView(this);
        styleBtn.setText("🌙");
        styleBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        styleBtn.setGravity(Gravity.CENTER);
        styleBtn.setBackground(makeBox("#D91A1E26", "#2B3240", 20));
        styleBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        styleBtn.setOnClickListener(v -> {
            mapDarkStyle = !mapDarkStyle;
            styleBtn.setText(mapDarkStyle ? "🌙" : "☀️");
            if (mapLiteReady && mapLiteWebView != null) {
                mapLiteWebView.evaluateJavascript("window.LITE && window.LITE.setDark(" + mapDarkStyle + ");", null);
            }
        });
        rightMapBtns.addView(styleBtn);
        container.addView(rightMapBtns, rmLp);

        // 4. Center-Bottom Floating Voice Assistant Overlay (109697.jpg exact match!)
        voiceFloatingOverlay = new LinearLayout(this);
        voiceFloatingOverlay.setOrientation(LinearLayout.VERTICAL);
        voiceFloatingOverlay.setGravity(Gravity.CENTER_HORIZONTAL);
        voiceFloatingOverlay.setBackground(makeBox("#D9111318", "#3E6AE1", 18));
        voiceFloatingOverlay.setPadding(dp(24), dp(14), dp(24), dp(14));
        voiceFloatingOverlay.setVisibility(View.GONE);
        FrameLayout.LayoutParams vfLp = new FrameLayout.LayoutParams(
                dp(520), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        vfLp.bottomMargin = dp(64);

        voiceTranscriptText = new TextView(this);
        voiceTranscriptText.setTextColor(Color.parseColor(COL_TEXT2));
        voiceTranscriptText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        voiceTranscriptText.setGravity(Gravity.CENTER);
        voiceFloatingOverlay.addView(voiceTranscriptText);

        voiceReplyText = new TextView(this);
        voiceReplyText.setTextColor(Color.WHITE);
        voiceReplyText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        voiceReplyText.setTypeface(Typeface.DEFAULT_BOLD);
        voiceReplyText.setGravity(Gravity.CENTER);
        voiceReplyText.setPadding(0, dp(4), 0, 0);
        voiceFloatingOverlay.addView(voiceReplyText);

        container.addView(voiceFloatingOverlay, vfLp);
        return container;
    }

    // =========================================================================
    // LAYER 2: GERÇEK ÇALIŞAN SPOTIFY PANELİ (SPOTIFY APK + WEB PLAYER + LİSTELER)
    // =========================================================================
    @SuppressLint("SetJavaScriptEnabled")
    private LinearLayout buildRealSpotifyLayer() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0E1015"));

        // Top Bar
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(Color.parseColor(COL_DOCK));
        topBar.setPadding(dp(12), dp(8), dp(12), dp(8));

        TextView closeBtn = makeTopBarButton("✕ Haritaya Dön", COL_CARD, () -> switchRightTab(0));
        topBar.addView(closeBtn);

        spotifySearchInput = new EditText(this);
        spotifySearchInput.setHint("Spotify'da şarkı, sanatçı veya liste ara...");
        spotifySearchInput.setHintTextColor(Color.parseColor(COL_TEXT2));
        spotifySearchInput.setTextColor(Color.WHITE);
        spotifySearchInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        spotifySearchInput.setSingleLine(true);
        spotifySearchInput.setBackground(makeBox(COL_CARD, null, 8));
        spotifySearchInput.setPadding(dp(12), dp(6), dp(12), dp(6));
        LinearLayout.LayoutParams sInLp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        sInLp.leftMargin = dp(8);
        sInLp.rightMargin = dp(8);
        topBar.addView(spotifySearchInput, sInLp);

        topBar.addView(makeTopBarButton("🔍 Çal", "#1DB954", () -> {
            String q = spotifySearchInput.getText().toString().trim();
            if (!q.isEmpty()) playOrSearchSpotify(q);
        }));

        topBar.addView(makeTopBarButton("🟢 Spotify APK Aç / Kur", COL_BLUE, () -> {
            if (!mediaRouter.openSpotify()) {
                Toast.makeText(this, "Spotify APK indiriliyor ve kuruluyor...", Toast.LENGTH_SHORT).show();
                appStore.downloadAndInstallApp("com.spotify.music", "https://skyos.my/indir/spotify-9-1-92-3058.apk");
            }
        }));
        root.addView(topBar);

        // Quick Playlist & Mode Strip
        HorizontalScrollView playlistScroll = new HorizontalScrollView(this);
        playlistScroll.setHorizontalScrollBarEnabled(false);
        playlistScroll.setBackgroundColor(Color.parseColor("#14171F"));
        LinearLayout plRow = new LinearLayout(this);
        plRow.setOrientation(LinearLayout.HORIZONTAL);
        plRow.setPadding(dp(10), dp(6), dp(10), dp(6));

        plRow.addView(makeTopBarButton("🌐 Tam Spotify Web (Giriş Yap)", "#1DB954", () -> {
            spotifyWebView.loadUrl("https://open.spotify.com");
        }));
        String[][] curated = new String[][]{
                {"🔥 Türkçe Pop Hitleri", "37i9dQZF1DWY4lFlS4Pnso"},
                {"🎸 Türkçe Rock", "37i9dQZF1DX4Wsb4d7NKfP"},
                {"🚗 Gece Sürüşü", "37i9dQZF1DX6VdMW310YC7"},
                {"🎧 Rap & Hip-Hop", "37i9dQZF1DX0XUsuxWHRQd"},
                {"🌍 Global Top 50", "37i9dQZF1DXcBWIGoYBM5M"},
                {"☕ Akustik & Chill", "37i9dQZF1DWWQRwui0ExPn"}
        };
        for (final String[] pl : curated) {
            plRow.addView(makeTopBarButton(pl[0], COL_CARD, () -> {
                spotifyWebView.loadUrl("https://open.spotify.com/embed/playlist/" + pl[1] + "?utm_source=generator&theme=0");
            }));
        }
        playlistScroll.addView(plRow);
        root.addView(playlistScroll);

        spotifyStatusText = new TextView(this);
        spotifyStatusText.setText("Spotify hazır — Üstten liste seçebilir, şarkı arayabilir veya 'Spotify APK Aç / Kur' ile tam arka plan ses modunu kullanabilirsiniz.");
        spotifyStatusText.setTextColor(Color.parseColor(COL_TEXT2));
        spotifyStatusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        spotifyStatusText.setPadding(dp(14), dp(4), dp(14), dp(4));
        root.addView(spotifyStatusText);

        spotifyWebView = new WebView(this);
        spotifyWebView.setBackgroundColor(Color.parseColor("#0E1015"));
        spotifyWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        configureRichMediaWebView(spotifyWebView, true);
        root.addView(spotifyWebView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        return root;
    }

    private void playOrSearchSpotify(String query) {
        // 1. If com.spotify.music is installed on the car, trigger direct playback via MEDIA_PLAY_FROM_SEARCH
        if (mediaHub.launchOrPlaySource("SPOTIFY", query)) {
            spotifyStatusText.setText("✓ Spotify uygulamasında çalınıyor: " + query);
        }
        // 2. Also load search results in the embedded Spotify WebView
        try {
            spotifyWebView.loadUrl("https://open.spotify.com/search/" + URLEncoder.encode(query, "UTF-8"));
        } catch (Exception ignored) {
        }
    }

    // =========================================================================
    // LAYER 3: GERÇEK ÇALIŞAN YOUTUBE PANELİ (TAM YOUTUBE + REKLAM ATLAMA + APK)
    // =========================================================================
    @SuppressLint("SetJavaScriptEnabled")
    private LinearLayout buildRealYouTubeLayer() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0F0F0F"));

        // Top Bar
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(Color.parseColor(COL_DOCK));
        topBar.setPadding(dp(12), dp(8), dp(12), dp(8));

        topBar.addView(makeTopBarButton("✕ Haritaya Dön", COL_CARD, () -> switchRightTab(0)));
        topBar.addView(makeTopBarButton("🏠 YouTube Ana Sayfa", "#FF0000", () -> {
            youtubeWebView.loadUrl("https://m.youtube.com");
        }));

        youtubeSearchInput = new EditText(this);
        youtubeSearchInput.setHint("YouTube'da video, şarkı veya kanal ara...");
        youtubeSearchInput.setHintTextColor(Color.parseColor(COL_TEXT2));
        youtubeSearchInput.setTextColor(Color.WHITE);
        youtubeSearchInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        youtubeSearchInput.setSingleLine(true);
        youtubeSearchInput.setBackground(makeBox(COL_CARD, null, 8));
        youtubeSearchInput.setPadding(dp(12), dp(6), dp(12), dp(6));
        LinearLayout.LayoutParams yInLp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        yInLp.leftMargin = dp(8);
        yInLp.rightMargin = dp(8);
        topBar.addView(youtubeSearchInput, yInLp);

        topBar.addView(makeTopBarButton("🔍 Video Ara", "#FF0000", () -> {
            String q = youtubeSearchInput.getText().toString().trim();
            if (!q.isEmpty()) {
                try {
                    youtubeWebView.loadUrl("https://m.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8"));
                } catch (Exception ignored) {
                }
            }
        }));

        topBar.addView(makeTopBarButton("📺 SmartTube / NewPipe APK", COL_BLUE, () -> {
            if (!mediaRouter.openYouTubeVideo()) {
                Toast.makeText(this, "SmartTube (Reklamsız 4K Araç YouTube) indiriliyor ve kuruluyor...", Toast.LENGTH_SHORT).show();
                appStore.downloadAndInstallApp("org.smarttube.stable",
                        "https://github.com/yuliskov/SmartTube/releases/latest/download/SmartTube_stable_arm64-v8a.apk");
            }
        }));
        root.addView(topBar);

        youtubeWebView = new WebView(this);
        youtubeWebView.setBackgroundColor(Color.parseColor("#0F0F0F"));
        youtubeWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        configureRichMediaWebView(youtubeWebView, false);
        root.addView(youtubeWebView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        return root;
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureRichMediaWebView(WebView wv, boolean desktopMode) {
        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        if (desktopMode) {
            ws.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
        } else {
            ws.setUserAgentString("Mozilla/5.0 (Linux; Android 12; Skywell ET5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36");
        }

        try {
            CookieManager cm = CookieManager.getInstance();
            cm.setAcceptCookie(true);
            cm.setAcceptThirdPartyCookies(wv, true);
        } catch (Throwable ignored) {
        }

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                try {
                    request.grant(request.getResources());
                } catch (Throwable ignored) {
                }
            }
        });

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.contains("youtube.com")) {
                    // Inject automatic YouTube ad-skipper & unmuter for smooth in-car playback
                    String adSkipJs = "setInterval(function(){"
                            + "var s=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button');"
                            + "if(s)s.click();"
                            + "var v=document.querySelector('video');"
                            + "if(v&&document.querySelector('.ad-showing')){v.currentTime=v.duration||999;}"
                            + "},1000);";
                    view.evaluateJavascript(adSkipJs, null);
                }
            }
        });
    }

    private void switchRightTab(int tabIdx) {
        this.activeRightTab = tabIdx;
        mapLayer.setVisibility(tabIdx == 0 ? View.VISIBLE : View.GONE);
        spotifyLayer.setVisibility(tabIdx == 1 ? View.VISIBLE : View.GONE);
        youtubeLayer.setVisibility(tabIdx == 2 ? View.VISIBLE : View.GONE);

        if (tabIdx == 1 && !spotifyWebLoaded) {
            spotifyWebLoaded = true;
            spotifyWebView.loadUrl("https://open.spotify.com/embed/playlist/37i9dQZF1DWY4lFlS4Pnso?utm_source=generator&theme=0");
        } else if (tabIdx == 2 && !youtubeWebLoaded) {
            youtubeWebLoaded = true;
            youtubeWebView.loadUrl("https://m.youtube.com");
        }

        for (int i = 0; i < 3; i++) {
            if (dockCenterIcons[i] != null) {
                dockCenterIcons[i].setBackground(makeBox(i == tabIdx ? COL_CARD_ACTIVE : "transparent", null, 10));
            }
        }
    }

    // =========================================================================
    // BOTTOM FULL-WIDTH DOCK BAR (54dp — EXACT 109697.jpg)
    // =========================================================================
    private View buildBottomDockBar() {
        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER_VERTICAL);
        dock.setBackgroundColor(Color.parseColor(COL_DOCK));
        dock.setPadding(dp(14), 0, dp(14), 0);

        // 1. Left Climate & Seat Strip: [🚗]  [<  28,0°  >]  [💨 1]  [💺]
        TextView carMenuIcon = makeDockIcon("🚗", () ->
                NativeDialogs.showVehicleControlSheet(this, vehicleController, this::openSetupWizard));
        dock.addView(carMenuIcon);

        TextView tempDownBtn = makeDockStepArrow("‹", () -> {
            float cur = Float.isNaN(vehicleController.getState().hvacTargetTemp) ? 22.0f : vehicleController.getState().hvacTargetTemp;
            vehicleController.setHvacTemperature(cur - 0.5f);
        });
        dock.addView(tempDownBtn);

        dockTempText = new TextView(this);
        dockTempText.setText("--.-°");
        dockTempText.setTextColor(Color.parseColor(COL_TEXT));
        dockTempText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        dockTempText.setTypeface(Typeface.DEFAULT_BOLD);
        dockTempText.setPadding(dp(6), dp(4), dp(6), dp(4));
        dockTempText.setOnClickListener(v -> NativeDialogs.showClimateSheet(this, vehicleController));
        dock.addView(dockTempText);

        TextView tempUpBtn = makeDockStepArrow("›", () -> {
            float cur = Float.isNaN(vehicleController.getState().hvacTargetTemp) ? 22.0f : vehicleController.getState().hvacTargetTemp;
            vehicleController.setHvacTemperature(cur + 0.5f);
        });
        dock.addView(tempUpBtn);

        dockFanText = new TextView(this);
        dockFanText.setText("💨 0");
        dockFanText.setTextColor(Color.parseColor(COL_TEXT2));
        dockFanText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        dockFanText.setPadding(dp(10), dp(6), dp(8), dp(6));
        dockFanText.setOnClickListener(v -> NativeDialogs.showClimateSheet(this, vehicleController));
        dock.addView(dockFanText);

        dockSeatText = new TextView(this);
        dockSeatText.setText("💺");
        dockSeatText.setTextColor(Color.parseColor(COL_TEXT2));
        dockSeatText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        dockSeatText.setPadding(dp(8), dp(6), dp(12), dp(6));
        dockSeatText.setOnClickListener(v -> {
            VehicleState st = vehicleController.getState();
            controllerCycleSeatComfort(st);
        });
        dock.addView(dockSeatText);

        View leftSpace = new View(this);
        dock.addView(leftSpace, new LinearLayout.LayoutParams(0, 1, 1f));

        // 2. Center App Icons (109697.jpg: Harita, Spotify, YouTube, Telefon, Müzik/Radyo, Kamera, Enerji, Uygulamalar, Kurulum)
        String[] icons = new String[]{"🧭", "🟢", "▶️", "📞", "🎵", "📷", "⚡", "田", "🔑"};
        Runnable[] actions = new Runnable[]{
                () -> switchRightTab(0), // Harita
                () -> switchRightTab(1), // Spotify
                () -> switchRightTab(2), // YouTube
                () -> NativeDialogs.showPhoneSheet(this), // Telefon
                () -> { // Radyo / Müzik
                    mediaHub.playInternetRadioStream("TRT FM", "91.4 MHz · Canlı Radyo",
                            "https://trtcanlifm-lh.akamaihd.net/i/TRTFM_1@181846/master.m3u8");
                    refreshClockVolumeAndMedia();
                    Toast.makeText(this, "Canlı Radyo: TRT FM çalınıyor", Toast.LENGTH_SHORT).show();
                },
                () -> showReverseCameraOverlay(true), // Kamera
                () -> NativeDialogs.showVehicleControlSheet(this, vehicleController, this::openSetupWizard), // Enerji & Araç
                () -> NativeDialogs.showAppHubSheet(this, mediaHub, mediaRouter, appStore), // Uygulama Mağazası & APK Kurucu
                this::openSetupWizard // SkyOS Kurulum Sihirbazı (109695.jpg)
        };

        for (int i = 0; i < icons.length; i++) {
            TextView ic = makeDockIcon(icons[i], actions[i]);
            if (i == 0) {
                ic.setBackground(makeBox(COL_CARD_ACTIVE, null, 10));
            }
            dockCenterIcons[i] = ic;
            dock.addView(ic);
        }

        View rightSpace = new View(this);
        dock.addView(rightSpace, new LinearLayout.LayoutParams(0, 1, 1f));

        // 3. Right Volume Control: [<  🔊 12  >]
        dock.addView(makeDockStepArrow("‹", () -> {
            vehicleController.adjustSystemVolume(-1);
            refreshClockVolumeAndMedia();
        }));

        dockVolumeText = new TextView(this);
        dockVolumeText.setText("🔊 10");
        dockVolumeText.setTextColor(Color.parseColor(COL_TEXT));
        dockVolumeText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        dockVolumeText.setTypeface(Typeface.DEFAULT_BOLD);
        dockVolumeText.setPadding(dp(6), dp(4), dp(6), dp(4));
        dock.addView(dockVolumeText);

        dock.addView(makeDockStepArrow("›", () -> {
            vehicleController.adjustSystemVolume(1);
            refreshClockVolumeAndMedia();
        }));

        return dock;
    }

    private void controllerCycleSeatComfort(VehicleState st) {
        if (st.driverSeatHeat == 0 && st.driverSeatVent == 0) {
            vehicleController.setSeatHeating(true, 3);
        } else if (st.driverSeatHeat > 0) {
            vehicleController.setSeatHeating(true, 0);
            vehicleController.setSeatVentilation(true, 3);
        } else {
            vehicleController.setSeatVentilation(true, 0);
        }
    }

    // =========================================================================
    // LIVE VEHICLE STATE UPDATES (ZERO DEMO DATA)
    // =========================================================================
    @Override
    public void onVehicleStateChanged(final VehicleState st) {
        mainHandler.post(() -> {
            // 1. Gear P R N D
            String[] gears = new String[]{"P", "R", "N", "D"};
            for (int i = 0; i < 4; i++) {
                boolean active = gears[i].equals(st.gear);
                gearViews[i].setTextColor(Color.parseColor(active ? COL_TEXT : COL_TEXT3));
                gearViews[i].setTextSize(TypedValue.COMPLEX_UNIT_SP, active ? 18 : 15);
            }

            // 2. Top-Right Battery + Range + Charging Bolt
            String socStr = st.socPercent >= 0 ? (st.socPercent + "%") : "--%";
            String rngStr = st.rangeKm >= 0 ? (st.rangeKm + " km") : "-- km";
            String bolt = st.chargingActive ? " ⚡" : "";
            topStatusRightText.setText("📶  ᛒ  🔋 " + socStr + bolt + " · " + rngStr);
            topStatusRightText.setTextColor(Color.parseColor(st.chargingActive ? COL_GREEN : COL_TEXT));

            // 3. Temperatures & Speed
            String outT = Float.isNaN(st.outsideTempC) ? "--°" : (Math.round(st.outsideTempC) + "°");
            String inT = Float.isNaN(st.cabinTempC) ? "--°" : (Math.round(st.cabinTempC) + "°");
            tempHeaderText.setText("Dış " + outT + "   İç " + inT);
            speedHeaderText.setText(st.speedKmh > 0 ? (st.speedKmh + " km/s") : "");

            // 4. Ultrasonic Parking Radar Distance Label (e.g., "85 cm" like 109697.jpg)
            float minDistM = Float.NaN;
            for (float d : st.radarFront) {
                if (!Float.isNaN(d) && d > 0.05f && (Float.isNaN(minDistM) || d < minDistM)) minDistM = d;
            }
            for (float d : st.radarRear) {
                if (!Float.isNaN(d) && d > 0.05f && (Float.isNaN(minDistM) || d < minDistM)) minDistM = d;
            }
            if (!Float.isNaN(minDistM) && minDistM <= 1.50f) {
                int cm = Math.round(minDistM * 100f);
                radarDistanceBadge.setText(cm + " cm");
                radarDistanceBadge.setVisibility(View.VISIBLE);
            } else {
                radarDistanceBadge.setVisibility(View.GONE);
            }

            // 5. Charging Banner Pill
            if (st.chargingActive || st.chargeCableConnected) {
                chargingBannerRow.setVisibility(View.VISIBLE);
                String kwPart = (!Float.isNaN(st.powerKw) && Math.abs(st.powerKw) >= 0.3f)
                        ? String.format(Locale.getDefault(), " · %.1f kW", Math.abs(st.powerKw)) : "";
                String remPart = st.chargeRemainingMin > 0
                        ? (" · " + (st.chargeRemainingMin / 60) + " sa " + (st.chargeRemainingMin % 60) + " dk") : "";
                chargingBannerText.setText("⚡ " + (st.chargingActive ? "Şarj oluyor · " : "Kablo takılı · ")
                        + socStr + kwPart + remPart);
            } else {
                chargingBannerRow.setVisibility(View.GONE);
            }

            // 6. Quick Pills: Bagaj & Hold
            pillTrunkView.setText(st.trunkOpen ? "🚗 Bagaj açık" : "🚗 Bagaj");
            pillTrunkView.setBackground(makeBox(st.trunkOpen ? COL_BLUE : COL_CARD, null, 11));

            pillHoldView.setText(st.autoHold ? "(H) Hold" : "Hold");
            pillHoldView.setBackground(makeBox(st.autoHold ? COL_BLUE : COL_CARD, null, 11));

            // 7. Bottom Dock Climate & Seat
            if (Float.isNaN(st.hvacTargetTemp) || st.hvacTargetTemp <= 0f) {
                dockTempText.setText("--,-°");
            } else {
                dockTempText.setText(String.format(Locale.getDefault(), "%.1f°", st.hvacTargetTemp).replace('.', ','));
            }
            dockFanText.setText("💨 " + (st.hvacPower ? st.hvacFanSpeed : 0));
            if (st.driverSeatHeat > 0) {
                dockSeatText.setText("💺🔥" + st.driverSeatHeat);
                dockSeatText.setTextColor(Color.parseColor("#E8563F"));
            } else if (st.driverSeatVent > 0) {
                dockSeatText.setText("💺❄️" + st.driverSeatVent);
                dockSeatText.setTextColor(Color.parseColor("#3A8BFF"));
            } else {
                dockSeatText.setText("💺");
                dockSeatText.setTextColor(Color.parseColor(COL_TEXT2));
            }

            // 8. Push state to 3D Car
            pushStateToCar3d(st);
        });
    }

    private void refreshClockVolumeAndMedia() {
        String nowStr = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        if (pillClockView != null) pillClockView.setText(nowStr);

        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null && dockVolumeText != null) {
                int curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC);
                dockVolumeText.setText("🔊 " + curVol);
            }
        } catch (Throwable ignored) {
        }

        if (mediaHub != null && mediaSongTitle != null) {
            JSONObject info = mediaHub.getActiveMediaInfo();
            String title = info.optString("title", "Spotify · Medya Hazır");
            String artist = info.optString("artist", "Sena Şener · Spotify");
            String pkg = info.optString("package", "");
            boolean playing = info.optBoolean("playing", false);

            mediaSongTitle.setText(title);
            if (pkg.contains("spotify") && !artist.toLowerCase(Locale.ROOT).contains("spotify")) {
                mediaSongArtist.setText(artist + " · Spotify");
                mediaCoverBadge.setBackground(makeBox("#1DB954", null, 10));
            } else {
                mediaSongArtist.setText(artist);
            }
            mediaPlayPauseBtn.setText(playing ? "⏸" : "▷");
        }
    }

    private void setupVoiceCallback() {
        voiceAssistant.setCallback(new Et5VoiceAssistant.AssistantCallback() {
            @Override
            public void onStateChanged(String state, String transcript, String reply, float audioLevel) {
                if ("IDLE".equals(state) && (reply == null || reply.isEmpty())) {
                    voiceFloatingOverlay.setVisibility(View.GONE);
                    return;
                }
                voiceFloatingOverlay.setVisibility(View.VISIBLE);
                voiceTranscriptText.setText((transcript != null && !transcript.isEmpty()) ? ("\"" + transcript + "\"") : "🎙 SkyVoice");
                voiceReplyText.setText(reply != null ? reply : "Dinliyorum...");
                if ("DONE".equals(state)) {
                    mainHandler.postDelayed(() -> voiceFloatingOverlay.setVisibility(View.GONE), 7000);
                }
            }

            @Override
            public void onUiAction(String actionType, String target, String param) {
                if ("OPEN_MEDIA".equals(actionType)) {
                    if ("YOUTUBE".equals(target)) {
                        switchRightTab(2);
                        if (param != null && !param.isEmpty()) {
                            youtubeSearchInput.setText(param);
                            try {
                                youtubeWebView.loadUrl("https://m.youtube.com/results?search_query=" + URLEncoder.encode(param, "UTF-8"));
                            } catch (Exception ignored) {}
                        }
                    } else if ("SPOTIFY".equals(target)) {
                        switchRightTab(1);
                        if (param != null && !param.isEmpty()) {
                            spotifySearchInput.setText(param);
                            playOrSearchSpotify(param);
                        }
                    }
                } else if ("SEARCH_MAP".equals(actionType) && param != null && !param.isEmpty()) {
                    switchRightTab(0);
                    searchAndRouteOnMap(param);
                }
            }
        });
    }

    private void searchAndRouteOnMap(final String query) {
        switchRightTab(0);
        Toast.makeText(this, "\"" + query + "\" için rota hesaplanıyor...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String nomUrl = "https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=tr&q="
                        + URLEncoder.encode(query, "UTF-8");
                conn = (HttpURLConnection) new URL(nomUrl).openConnection();
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(7000);
                conn.setRequestProperty("User-Agent", "SkyOS-ET5/3.0");
                if (conn.getResponseCode() != 200) return;

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                conn.disconnect();

                JSONArray results = new JSONArray(sb.toString());
                if (results.length() == 0) {
                    mainHandler.post(() -> Toast.makeText(this, "Konum bulunamadı: " + query, Toast.LENGTH_SHORT).show());
                    return;
                }
                JSONObject first = results.getJSONObject(0);
                final double destLat = Double.parseDouble(first.getString("lat"));
                final double destLon = Double.parseDouble(first.getString("lon"));
                final String dispName = first.optString("display_name", query).split(",")[0];

                String osrmUrl = String.format(Locale.US,
                        "https://router.project-osrm.org/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=full&geometries=geojson",
                        currentLon, currentLat, destLon, destLat);
                conn = (HttpURLConnection) new URL(osrmUrl).openConnection();
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(8000);
                conn.setRequestProperty("User-Agent", "SkyOS-ET5/3.0");

                final JSONArray latLonArray = new JSONArray();
                double distKm = 0;
                int durMin = 0;
                if (conn.getResponseCode() == 200) {
                    BufferedReader r2 = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder sb2 = new StringBuilder();
                    String l2;
                    while ((l2 = r2.readLine()) != null) sb2.append(l2);
                    JSONObject osrmRoot = new JSONObject(sb2.toString());
                    JSONArray routes = osrmRoot.optJSONArray("routes");
                    if (routes != null && routes.length() > 0) {
                        JSONObject rt = routes.getJSONObject(0);
                        distKm = rt.optDouble("distance", 0) / 1000.0;
                        durMin = (int) Math.round(rt.optDouble("duration", 0) / 60.0);
                        JSONObject geom = rt.optJSONObject("geometry");
                        if (geom != null) {
                            JSONArray coords = geom.optJSONArray("coordinates");
                            if (coords != null) {
                                for (int i = 0; i < coords.length(); i++) {
                                    JSONArray pt = coords.getJSONArray(i);
                                    JSONArray latLon = new JSONArray();
                                    latLon.put(pt.getDouble(1));
                                    latLon.put(pt.getDouble(0));
                                    latLonArray.put(latLon);
                                }
                            }
                        }
                    }
                }
                final double fDistKm = distKm;
                final int fDurMin = durMin;
                final String etaTime = new SimpleDateFormat("HH:mm", Locale.getDefault())
                        .format(new Date(System.currentTimeMillis() + fDurMin * 60000L));

                mainHandler.post(() -> {
                    navTurnCard.setVisibility(View.VISIBLE);
                    navTurnDistText.setText("250 m");
                    navTurnStreetText.setText(dispName + " yönünde ilerleyin");

                    navBottomEtaBar.setVisibility(View.VISIBLE);
                    navEtaText.setText(String.format(Locale.getDefault(),
                            "%s   %d dk · %.1f km", etaTime, fDurMin, fDistKm).replace('.', ','));

                    if (mapLiteReady && mapLiteWebView != null && latLonArray.length() > 0) {
                        mapLiteWebView.evaluateJavascript("window.LITE && window.LITE.setRoute(" + latLonArray + ");", null);
                    }
                });
            } catch (Throwable ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
        }, "Et5-MapRoute").start();
    }

    private void cancelNavigationRoute() {
        navTurnCard.setVisibility(View.GONE);
        navBottomEtaBar.setVisibility(View.GONE);
        if (mapLiteReady && mapLiteWebView != null) {
            mapLiteWebView.evaluateJavascript("window.LITE && window.LITE.setRoute([]);", null);
        }
    }

    public void openSetupWizard() {
        if (activeSetupDialog != null && activeSetupDialog.isShowing()) return;
        activeSetupDialog = new SetupWizardDialog(this, vehicleController, () ->
                onVehicleStateChanged(vehicleController.getState()));
        activeSetupDialog.show();
    }

    private FrameLayout buildReverseCameraOverlay() {
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.BLACK);
        overlay.setVisibility(View.GONE);

        cameraSurfaceView = new SurfaceView(this);
        overlay.addView(cameraSurfaceView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        cameraHelper = new Et5ReverseCameraHelper(this);
        cameraHelper.attachToSurfaceView(cameraSurfaceView);

        cameraRadarText = new TextView(this);
        cameraRadarText.setText("Arka kamera");
        cameraRadarText.setTextColor(Color.WHITE);
        cameraRadarText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        cameraRadarText.setTypeface(Typeface.DEFAULT_BOLD);
        cameraRadarText.setBackground(makeBox("#AA111318", null, 10));
        cameraRadarText.setPadding(dp(16), dp(8), dp(16), dp(8));
        FrameLayout.LayoutParams radarLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.START);
        radarLp.topMargin = dp(18);
        radarLp.leftMargin = dp(18);
        overlay.addView(cameraRadarText, radarLp);

        Button closeCamBtn = new Button(this);
        closeCamBtn.setText("✕");
        closeCamBtn.setTextColor(Color.WHITE);
        closeCamBtn.setBackground(makeBox("#AA1E222B", null, 24));
        FrameLayout.LayoutParams closeLp = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP | Gravity.END);
        closeLp.topMargin = dp(18);
        closeLp.rightMargin = dp(18);
        closeCamBtn.setOnClickListener(v -> showReverseCameraOverlay(false));
        overlay.addView(closeCamBtn, closeLp);

        return overlay;
    }

    public void showReverseCameraOverlay(final boolean show) {
        mainHandler.post(() -> {
            if (cameraOverlay == null) return;
            if (show) {
                AdbRootBridge.stopSkyworthEvsService(this);
                cameraOverlay.setVisibility(View.VISIBLE);
            } else {
                cameraOverlay.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onReverseGearChanged(boolean inReverse) {
        showReverseCameraOverlay(inReverse);
    }

    @Override
    public void onSteeringVoiceButtonPressed() {
        voiceAssistant.startMicrophoneVadListening(null);
    }

    private void pushStateToCar3d(VehicleState st) {
        if (!car3dReady || car3dWebView == null) return;
        String json = st.toCar3dStateJson().toString();
        if (json.equals(lastCar3dJson)) return;
        lastCar3dJson = json;
        car3dWebView.evaluateJavascript("window.CAR && window.CAR.state(" + json + ");", null);
    }

    @SuppressLint("MissingPermission")
    private void startRealGpsTracking() {
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return;
            LocationListener listener = new LocationListener() {
                @Override
                public void onLocationChanged(Location loc) {
                    if (loc == null) return;
                    hasRealGpsFix = true;
                    currentLat = loc.getLatitude();
                    currentLon = loc.getLongitude();
                    if (loc.hasBearing()) currentBearing = loc.getBearing();
                    if (mapLiteReady && mapLiteWebView != null) {
                        final String js = String.format(Locale.US,
                                "window.LITE && window.LITE.setFix(%.6f,%.6f,%.1f,'#3e6ae1',null);",
                                currentLat, currentLon, currentBearing);
                        mainHandler.post(() -> mapLiteWebView.evaluateJavascript(js, null));
                    }
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            };
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1.0f, listener);
                Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last != null) listener.onLocationChanged(last);
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2500L, 5.0f, listener);
                if (!hasRealGpsFix) {
                    Location lastNet = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (lastNet != null) listener.onLocationChanged(lastNet);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureAssetWebView(WebView wv, Object jsBridge, String jsName, Runnable onPageFinished) {
        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ws.setUserAgentString("Mozilla/5.0 (Linux; Android 12; Skywell ET5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
        wv.addJavascriptInterface(jsBridge, jsName);
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                String prefix = "https://" + ASSET_HOST + "/assets/";
                if (url.startsWith(prefix)) {
                    String assetPath = url.substring(prefix.length());
                    int qIdx = assetPath.indexOf('?');
                    if (qIdx >= 0) assetPath = assetPath.substring(0, qIdx);
                    try {
                        InputStream is = getAssets().open(assetPath);
                        String mime = guessMimeType(assetPath);
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Access-Control-Allow-Origin", "*");
                        return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, is);
                    } catch (Exception ignored) {
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (onPageFinished != null) onPageFinished.run();
            }
        });
    }

    public final class Car3dBridge {
        @JavascriptInterface
        public void onPart(String part) {
            mainHandler.post(() -> {
                VehicleState st = vehicleController.getState();
                if ("trunk".equals(part)) vehicleController.setPowerTrunk(!st.trunkOpen);
                else if ("charge".equals(part)) vehicleController.setChargePort(!st.chargePortOpen);
                else if (part != null && part.startsWith("d")) vehicleController.setDoorLocks(!st.locked);
            });
        }

        @JavascriptInterface
        public void onLabel(String side, float x, float y, float dist) {
        }

        @JavascriptInterface
        public void ready() {
            car3dReady = true;
            mainHandler.post(() -> pushStateToCar3d(vehicleController.getState()));
        }
    }

    public final class MapLiteBridge {
        @JavascriptInterface
        public void onUserMove() {
        }

        @JavascriptInterface
        public void ready() {
            mapLiteReady = true;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST
                || keyCode == KeyEvent.KEYCODE_SEARCH
                || keyCode == 231) {
            long now = System.currentTimeMillis();
            if (now - lastVoiceKeyTimeMs < 1500L) {
                voiceKeyBurstCount++;
            } else {
                voiceKeyBurstCount = 1;
            }
            lastVoiceKeyTimeMs = now;
            if (voiceKeyBurstCount >= 6) {
                voiceKeyBurstCount = 0;
                AdbRootBridge.restoreStockLauncher(this);
                return true;
            }
            voiceAssistant.startMicrophoneVadListening(null);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        enableImmersiveFullscreen();
        mainHandler.removeCallbacks(clockAndMediaTicker);
        mainHandler.post(clockAndMediaTicker);
    }

    @Override
    protected void onPause() {
        mainHandler.removeCallbacks(clockAndMediaTicker);
        vehicleController.getState().saveRealCache(this);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        vehicleController.removeListener(this);
        if (cameraHelper != null) cameraHelper.closeCamera();
        super.onDestroy();
    }

    private void enableImmersiveFullscreen() {
        try {
            Window w = getWindow();
            if (w == null) return;
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            View decor = w.getDecorView();
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        } catch (Throwable ignored) {
        }
    }

    // UI Helper Builders
    private TextView makeLeftQuickPill(String text, Runnable onClick) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor(COL_TEXT));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(makeBox(COL_CARD, null, 11));
        if (onClick != null) {
            tv.setOnClickListener(v -> onClick.run());
        }
        return tv;
    }

    private LinearLayout.LayoutParams makeWeightedPillLp(float weight, int rightMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.rightMargin = dp(rightMarginDp);
        return lp;
    }

    private TextView makeTransportIcon(String symbol, Runnable onClick) {
        TextView tv = new TextView(this);
        tv.setText(symbol);
        tv.setTextColor(Color.parseColor(COL_TEXT));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(8), dp(6), dp(8), dp(6));
        tv.setOnClickListener(v -> onClick.run());
        return tv;
    }

    private TextView makeDockIcon(String icon, Runnable onClick) {
        TextView tv = new TextView(this);
        tv.setText(icon);
        tv.setTextColor(Color.parseColor(COL_TEXT));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(38));
        lp.leftMargin = dp(3);
        lp.rightMargin = dp(3);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(v -> onClick.run());
        return tv;
    }

    private TextView makeDockStepArrow(String arrow, Runnable onClick) {
        TextView tv = new TextView(this);
        tv.setText(arrow);
        tv.setTextColor(Color.parseColor(COL_TEXT2));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        tv.setPadding(dp(8), dp(2), dp(8), dp(2));
        tv.setOnClickListener(v -> onClick.run());
        return tv;
    }

    private TextView makeTopBarButton(String text, String bgHex, Runnable onClick) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(makeBox(bgHex, null, 8));
        tv.setPadding(dp(12), dp(6), dp(12), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.rightMargin = dp(6);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(v -> onClick.run());
        return tv;
    }

    private GradientDrawable makeBox(String fillHex, String strokeHex, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        if ("transparent".equalsIgnoreCase(fillHex)) {
            gd.setColor(Color.TRANSPARENT);
        } else {
            gd.setColor(Color.parseColor(fillHex));
        }
        gd.setCornerRadius(dp(radiusDp));
        if (strokeHex != null) {
            gd.setStroke(Math.max(1, dp(1)), Color.parseColor(strokeHex));
        }
        return gd;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static String guessMimeType(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js") || path.endsWith(".mjs")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".json")) return "application/json";
        if (path.endsWith(".glb")) return "model/gltf-binary";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }
}
