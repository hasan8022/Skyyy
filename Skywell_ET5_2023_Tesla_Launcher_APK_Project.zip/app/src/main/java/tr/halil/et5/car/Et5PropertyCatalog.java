package tr.halil.et5.car;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 2023 Skywell ET5 (Skyworth EV6) Complete CarPropertyManager ID & Area Catalog.
 * Extracted from SkyOS 2.82 (Mg0, d4, C1328f8, C0227Hf, OC, PC).
 */
public final class Et5PropertyCatalog {
    public static final int PROP_SUNSHADE_CMD = 557850774;
    public static final int PROP_CENTRAL_LOCK = 557850756;

    private Et5PropertyCatalog() {}

    // ======================== DRIVE, GEAR, SPEED & BATTERY ========================
    public static final int PROP_GEAR_ALT              = 0x11400400; // 289408000 (area 0: 2 = R)
    public static final int PROP_GEAR_SELECTION        = 0x11400460; // 289408096 (area 0: 1=N, 2=R, 3=D, 4=D+Hold, 5=P)
    public static final int PROP_TURN_SIGNAL           = 0x11400408; // 289408008 (area 0/8: 0=Off, 1=Right, 2=Left, 3=Hazard)
    public static final int PROP_HAZARD_LIGHTS         = 0x11400e03; // 289410563 (area 0: !=0 on)
    public static final int PROP_BRAKE_LIGHT           = 0x11400e05; // 289410565 (area 0/8: 1=Braking)
    public static final int PROP_LOW_BEAM              = 0x11400e00; // 289410560 (area 0: 1=On, also 1..4 headlight height)
    public static final int PROP_HIGH_BEAM             = 0x11400e01; // 289410561 (area 0: 1=On)
    public static final int PROP_FOG_LIGHT             = 0x11400e02; // 289410562 (area 0: 1=On)
    public static final int PROP_SPEED_KMH             = 0x11600470; // 291505264 (area 5: float km/h)
    public static final int PROP_SPEED_MS              = 0x11600207; // 291504647 (area 2: float m/s -> * 3.6f)
    public static final int PROP_BATTERY_SOC           = 0x1160031b; // 291504923 (area 0: float 0..100%)
    public static final int PROP_RANGE_KM              = 0x1160049e; // 291505310 (area 0: float km)
    public static final int PROP_RANGE_KM_ALT          = 0x11600333; // 291504947 (area 0: float km fallback)
    public static final int PROP_ODOMETER_KM           = 0x1160049a; // 291505306 (area 0: float total km)
    public static final int PROP_TRIP_KM               = 0x1160049b; // 291505307 (area 0: float trip km)
    public static final int PROP_AVG_CONSUMPTION       = 0x11600331; // 291504945 (area 0: float kWh/100km)
    public static final int PROP_HV_VOLTAGE            = 0x1160031c; // 291504924 (area 1: float V)
    public static final int PROP_HV_CURRENT            = 0x1160031d; // 291504925 (area 5: float A)
    public static final int PROP_BATTERY_12V           = 0x11400d2d; // 289410349 (area 0: int)
    public static final int PROP_TIRE_PRESSURES        = 0x11610497; // 291570839 (area 0: float[4] bar)
    public static final int PROP_IGNITION_STATE        = 0x21400620; // 557844000 (area 0: !=0 ready)
    public static final int PROP_VIN                   = 0x11100e43; // 286264899 (area 0: String VIN)

    // ======================== PARKING RADAR SENSORS ========================
    public static final int PROP_RADAR_FRONT           = 0x11610449; // 291570761 (area 8: float[4] meters)
    public static final int PROP_RADAR_REAR            = 0x1161044a; // 291570762 (area 8: float[4] meters)
    public static final int PROP_RADAR_SIDE            = 0x1161044b; // 291570763 (area 8: float[4] meters)

    // ======================== CHARGING & SCHEDULED CHARGING ========================
    public static final int PROP_CHARGE_LIMIT          = 0x11600319; // 291504921 (area 0: float 50..100)
    public static final int PROP_CHARGE_CABLE          = 0x11400317; // 289407767 (area 0: int !=0 connected)
    public static final int PROP_CHARGE_INDICATOR      = 0x11400551; // 289408337 (area 0: int !=0 charging)
    public static final int PROP_CHARGE_STATUS         = 0x11400330; // 289407792 (area 0: int 1=charging, 0=stopped)
    public static final int PROP_CHARGE_START_STOP     = 0x11400334; // 289407796 (area 0/1: int 0/1)
    public static final int PROP_CHARGE_REMAINING_MIN  = 0x11400562; // 289408354 (area 0: int minutes)
    public static final int PROP_SCHED_CHARGE_START    = 0x11410314; // 289473300 (area 0: int[] Y,M,D,h,m)
    public static final int PROP_SCHED_CHARGE_END      = 0x11410318; // 289473304 (area 0: int[] Y,M,D,h,m)
    public static final int PROP_SCHED_CHARGE_SWITCH   = 0x11400311; // 289407761 (area 0: int 0/1)

    // ======================== HVAC / CLIMATE CONTROL ========================
    public static final int PROP_HVAC_POWER            = 0x15200510; // 354419984 (area 0: boolean)
    public static final int PROP_HVAC_TARGET_TEMP      = 0x15600503; // 358614275 (area 0: float 18.0..32.0)
    public static final int PROP_HVAC_FAN_SPEED        = 0x15400500; // 356517120 (area 0: int 1..7)
    public static final int PROP_HVAC_AC               = 0x15200505; // 354419973 (area 0: boolean)
    public static final int PROP_HVAC_AUTO             = 0x1520050a; // 354419978 (area 0: boolean)
    public static final int PROP_HVAC_AUTO_ALT         = 0x11400520; // 289408288 (area 0: int)
    public static final int PROP_HVAC_RECIRC           = 0x15200512; // 354419986 (area 0: boolean)
    public static final int PROP_HVAC_DEFROST          = 0x13200504; // 320865540 (area 1=Front, 2=Rear: boolean)
    public static final int PROP_HVAC_CABIN_TEMP       = 0x11600517; // 291505431 (area 0: float C)
    public static final int PROP_HVAC_OUTSIDE_TEMP     = 0x11600518; // 291505432 (area 0: float C)
    public static final int PROP_HVAC_ECO_MUTE         = 0x11200e52; // 287313490 (area 0..6: boolean)

    // ======================== SEATS & MIRRORS ========================
    public static final int PROP_SEAT_HEAT             = 0x15400b9c; // 356518812 (area 1=Driver, 4=Passenger: int 0..3)
    public static final int PROP_SEAT_VENT             = 0x15400b9b; // 356518811 (area 1=Driver, 4=Passenger: int 0..3)
    public static final int PROP_SEAT_FORE_AFT         = 0x15400b85; // 356518789 (area 1: int)
    public static final int PROP_SEAT_HEIGHT           = 0x15400b8b; // 356518795 (area 1: int)
    public static final int PROP_SEAT_TILT             = 0x15400b8f; // 356518799 (area 1: int)
    public static final int PROP_SEAT_FOOTREST         = 0x15400ba5; // 356518821 (area 1: int)
    public static final int PROP_SEAT_MEMORY_PACKET    = 0x11410ba0; // 289475488 (area 1: int[8])
    public static final int PROP_MIRROR_HORIZ          = 0x14400b42; // 339741506 (area 1=Left, 2=Right: int)
    public static final int PROP_MIRROR_VERT           = 0x14400b40; // 339741504 (area 1=Left, 2=Right: int)
    public static final int PROP_MIRROR_FOLD_CMD       = 0x14400b45; // 339741509 (area 0: 1=Unfold, 4=Fold)

    // ======================== DOORS, TRUNK, HOOD, WINDOWS & SUNROOF ========================
    public static final int PROP_DOOR_TRUNK_HOOD_STATE = 0x16400b06; // 373295878 (areas: 1,4,16,64=Doors, 0x10000000=Hood, 0x20000000=Trunk)
    public static final int PROP_TRUNK_ACTION          = 0x16400b03; // 373295875 (area 0x20000000 = 536870912: 1=Open, 2=Close)
    public static final int PROP_LOCK_STATE            = 0x11200402; // 287310850 (area 0: boolean)
    public static final int PROP_WINDOW_POS            = 0x13400bc0; // 322964416 (areas: 16=FL, 64=FR, 256=RL, 1024=RR: 0=Close, 10=Open)
    public static final int PROP_WINDOW_CMD            = 0x13400bc5; // 322964421 (area 65536 or 0x550: 1=Close, 2=Open, 3=Vent)
    public static final int PROP_SUNROOF_CMD           = 0x13400bd0; // 322964432 (area 0: 1=Close, 2=Open)

    public static final int AREA_TRUNK                 = 0x20000000; // 536870912
    public static final int AREA_HOOD                  = 0x10000000; // 268435456
    public static final int[] AREAS_DOORS              = {1, 4, 16, 64}; // FL, FR, RL, RR
    public static final int[] AREAS_WINDOWS            = {16, 64, 256, 1024}; // FL, FR, RL, RR
    public static final int AREA_ALL_WINDOWS_POS       = 0x550;      // 1360
    public static final int AREA_ALL_WINDOWS_CMD       = 0x10000;    // 65536

    // ======================== AUDIO & FM RADIO ========================
    public static final int PROP_AUDIO_CHANNEL         = 0x11400e50; // 289410640 (area 0: int)
    public static final int PROP_AUDIO_VOLUME          = 0x11400e51; // 289410641 (area channel: int 0..40)
    public static final int PROP_AUDIO_BALANCE_FADE    = 0x11410e55; // 289476181 (area 0: int[2] -15..15)
    public static final int PROP_AUDIO_EQ_PRESET       = 0x11400e52; // 289410642 (area 0: int 1..6)
    public static final int PROP_AUDIO_EQ_BAND         = 0x11400e53; // 289410643 (area 1..5: int -10..10)
    public static final int PROP_AUDIO_STAGE_MODE      = 0x11400e54; // 289410644 (area 0: int 1..4)
    public static final int PROP_AUDIO_SPEED_VOL       = 0x11400e56; // 289410646 (area 0: int 0..3)
    public static final int PROP_RADIO_POWER           = 0x11200801; // 287311873 (area 0: boolean)
    public static final int PROP_RADIO_FREQ            = 0x11600804; // 291506180 (area 0/1: float)
    public static final int PROP_RADIO_CTRL            = 0x11400802; // 289409026 (area 0: int)
    public static final int PROP_RADIO_MODEL           = 0x11400803; // 289409027 (area 0: int)
    public static final int PROP_RADIO_REGION          = 0x11400807; // 289409031 (area 0: int)
    public static final int PROP_RADIO_LIST_1          = 0x11610804; // 291571716 (area 0: float[])
    public static final int PROP_RADIO_LIST_2          = 0x11610805; // 291571717 (area 0: float[])

    // ======================== WATCHED PROPERTIES LIST (Mg0.E) ========================
    public static final List<String> WATCHED_SPEC_LIST;
    static {
        List<String> list = new ArrayList<>();
        int[][] pairs = {
            {PROP_TURN_SIGNAL, 8},
            {PROP_HAZARD_LIGHTS, 0},
            {PROP_BRAKE_LIGHT, 8},
            {PROP_RADAR_FRONT, 8},
            {PROP_RADAR_REAR, 8},
            {PROP_RADAR_SIDE, 8},
            {PROP_GEAR_SELECTION, 0},
            {PROP_GEAR_ALT, 0},
            {PROP_HVAC_FAN_SPEED, 0},
            {PROP_HVAC_TARGET_TEMP, 0},
            {PROP_HVAC_POWER, 0},
            {PROP_HVAC_AC, 0},
            {PROP_SEAT_HEAT, 0},
            {PROP_SEAT_VENT, 0},
            {PROP_SPEED_MS, 2},
            {PROP_SPEED_KMH, 5},
            {PROP_RANGE_KM_ALT, 0},
            {PROP_RANGE_KM, 0},
            {PROP_BATTERY_SOC, 0},
            {PROP_HVAC_DEFROST, 0},
            {PROP_HVAC_RECIRC, 0},
            {PROP_HVAC_AUTO, 0},
            {PROP_HVAC_AUTO_ALT, 0},
            {PROP_HVAC_CABIN_TEMP, 0},
            {PROP_HVAC_OUTSIDE_TEMP, 0},
            {PROP_DOOR_TRUNK_HOOD_STATE, 0},
            {PROP_LOCK_STATE, 0},
            {PROP_CHARGE_CABLE, 0},
            {PROP_CHARGE_INDICATOR, 0},
            {PROP_CHARGE_STATUS, 0},
            {0x11400412, 0},
            {PROP_CHARGE_REMAINING_MIN, 0},
            {PROP_SEAT_FORE_AFT, 0},
            {PROP_SEAT_HEIGHT, 0},
            {PROP_SEAT_TILT, 0},
            {PROP_SEAT_FOOTREST, 0},
            {PROP_MIRROR_HORIZ, 0},
            {PROP_MIRROR_VERT, 0},
            {PROP_BATTERY_12V, 0},
            {PROP_TIRE_PRESSURES, 0},
            {0x11400414, 0},
            {PROP_ODOMETER_KM, 0},
            {PROP_TRIP_KM, 0},
            {PROP_AVG_CONSUMPTION, 0},
            {PROP_HV_VOLTAGE, 1},
            {PROP_HV_CURRENT, 5},
            {PROP_IGNITION_STATE, 0},
            {PROP_WINDOW_POS, 0},
            {PROP_LOW_BEAM, 0},
            {PROP_HIGH_BEAM, 0},
            {PROP_FOG_LIGHT, 0}
        };
        for (int[] p : pairs) {
            list.add("0x" + Integer.toHexString(p[0]) + ":" + p[1]);
        }
        WATCHED_SPEC_LIST = Collections.unmodifiableList(list);
    }

    // ======================== VEHICLE SETTINGS CATALOG (C1328f8) ========================
    public static final class SettingSpec {
        public final String key;
        public final String titleTr;
        public final String category;
        public final int propId;
        public final int areaId;
        public final String type; // "b" or "i"
        public final boolean isBool;
        public final boolean invertBool;
        public final int offset;
        public final int minVal;
        public final int maxVal;
        public final boolean parkOnly;

        public SettingSpec(String key, String titleTr, String category, int propId, int areaId,
                           String type, boolean isBool, boolean invertBool, int offset,
                           int minVal, int maxVal, boolean parkOnly) {
            this.key = key;
            this.titleTr = titleTr;
            this.category = category;
            this.propId = propId;
            this.areaId = areaId;
            this.type = type;
            this.isBool = isBool;
            this.invertBool = invertBool;
            this.offset = offset;
            this.minVal = minVal;
            this.maxVal = maxVal;
            this.parkOnly = parkOnly;
        }

        public String toCarValue(Object uiVal) {
            if (isBool) {
                boolean b = (uiVal instanceof Boolean) ? (Boolean) uiVal : "true".equalsIgnoreCase(String.valueOf(uiVal)) || "1".equals(String.valueOf(uiVal));
                if ("kilit_acma".equals(key)) {
                    int idx = (uiVal instanceof Number) ? ((Number) uiVal).intValue() : (b ? 1 : 0);
                    return idx == 0 ? "1" : "2";
                }
                if ("ayna_katla".equals(key)) {
                    return b ? "1" : "2";
                }
                boolean out = invertBool ? !b : b;
                return "b".equals(type) ? String.valueOf(out) : (out ? "1" : "0");
            } else {
                int v = (uiVal instanceof Number) ? ((Number) uiVal).intValue() : Integer.parseInt(String.valueOf(uiVal));
                if (v < minVal) v = minVal;
                if (v > maxVal) v = maxVal;
                return String.valueOf(v + offset);
            }
        }
    }

    public static final Map<String, SettingSpec> SETTINGS_MAP;
    static {
        Map<String, SettingSpec> m = new LinkedHashMap<>();
        // Sürüş & Şasi
        m.put("surus_modu",       new SettingSpec("surus_modu", "Sürüş Modu (Normal/Eco/Spor)", "surus", 289408052, 0, "i", false, false, 0, 0, 2, false));
        m.put("direksiyon_modu",  new SettingSpec("direksiyon_modu", "Direksiyon Modu (Konfor/Standart/Spor)", "surus", 289408051, 0, "i", false, false, 1, 0, 2, false));
        m.put("fren_modu",        new SettingSpec("fren_modu", "Fren Modu (Konfor/Spor)", "surus", 289408049, 0, "i", false, false, 0, 0, 1, false));
        m.put("geri_kazanim",     new SettingSpec("geri_kazanim", "Enerji Geri Kazanımı (%0-%100)", "surus", 289408050, 0, "i", false, false, 0, 0, 100, false));
        m.put("rolanti",          new SettingSpec("rolanti", "Rölanti Sürünme (Creep Modu)", "surus", 289408053, 0, "i", true, true, 0, 0, 1, false));
        m.put("yokus_inis",       new SettingSpec("yokus_inis", "Yokuş İniş Desteği (HDC)", "surus", 289408019, 0, "i", true, false, 0, 0, 1, false));
        m.put("esc",              new SettingSpec("esc", "ESC Elektronik Denge Kontrolü", "surus", 289408018, 0, "i", true, false, 0, 0, 1, false));

        // ADAS & Güvenlik
        m.put("lka",              new SettingSpec("lka", "Şerit Takip Asistanı (LKA)", "adas", 289408031, 0, "i", true, false, 0, 0, 1, false));
        m.put("ldw",              new SettingSpec("ldw", "Şerit Çıkış Uyarısı (LDW)", "adas", 289408025, 0, "i", true, false, 0, 0, 1, false));
        m.put("aeb",              new SettingSpec("aeb", "Otomatik Acil Fren (AEB)", "adas", 289408016, 0, "i", true, false, 0, 0, 1, true));
        m.put("fcw",              new SettingSpec("fcw", "Ön Çarpışma Uyarısı (FCW)", "adas", 289408017, 0, "i", true, false, 0, 0, 1, true));
        m.put("bsd",              new SettingSpec("bsd", "Kör Nokta Algılama (BSD)", "adas", 289408032, 0, "i", true, false, 0, 0, 1, false));
        m.put("tsr",              new SettingSpec("tsr", "Trafik İşareti Tanıma (TSR)", "adas", 289408021, 0, "i", true, false, 0, 0, 1, false));
        m.put("hba",              new SettingSpec("hba", "Otomatik Uzun Far Asistanı (HBA)", "adas", 289408028, 0, "i", true, false, 0, 0, 1, false));
        m.put("on_radar",         new SettingSpec("on_radar", "Ön Park Radarı", "adas", 289408020, 0, "i", true, false, 0, 0, 1, false));
        m.put("yaya_uyari",       new SettingSpec("yaya_uyari", "Düşük Hız Yaya Uyarı Sesi (AVAS)", "adas", 289408029, 0, "i", true, false, 0, 0, 1, false));

        // Aydınlatma & Ambiyans
        m.put("far_yukseklik",    new SettingSpec("far_yukseklik", "Far Yükseklik Seviyesi (0-3)", "isik", 289410560, 0, "i", false, false, 1, 0, 3, false));
        m.put("follow_me",        new SettingSpec("follow_me", "Refakatçi Aydınlatma (Follow Me Home)", "isik", 289410564, 0, "i", false, false, 1, 0, 4, false));
        m.put("karsilama_isik",   new SettingSpec("karsilama_isik", "Karşılama Aydınlatması", "isik", 289410587, 0, "i", true, false, 0, 0, 1, false));
        m.put("logo_isik",        new SettingSpec("logo_isik", "Arka Skywell Logo Işığı", "isik", 289410593, 0, "i", true, false, 0, 0, 1, false));
        m.put("dugme_isik",       new SettingSpec("dugme_isik", "İç Tuş Aydınlatma Parlaklığı (1-5)", "isik", 289410584, 0, "i", false, false, 0, 1, 5, false));
        m.put("ambiyans",         new SettingSpec("ambiyans", "Ambiyans Aydınlatma Modu (0-3)", "isik", 289410580, 0, "i", false, false, 0, 0, 3, false));
        m.put("ambiyans_renk",    new SettingSpec("ambiyans_renk", "Ambiyans Renk Seçimi (1-128)", "isik", 289410582, 0, "i", false, false, 1, 0, 127, false));
        m.put("ambiyans_parlak",  new SettingSpec("ambiyans_parlak", "Ambiyans Parlaklığı (1-5)", "isik", 289410584, 0, "i", false, false, 0, 1, 5, false));

        // Kilitler, Aynalar & Koltuklar
        m.put("kilit_acma",       new SettingSpec("kilit_acma", "Kilit Açma (0:Tüm Kapılar, 1:Sürücü)", "kilit", 373295877, 0, "i", true, false, 1, 0, 1, false));
        m.put("ayna_katla",       new SettingSpec("ayna_katla", "Kilitleyince Yan Aynaları Katla", "kilit", 289408352, 0, "i", true, false, 0, 0, 1, false));
        m.put("cam_kapat",        new SettingSpec("cam_kapat", "Kilitleyince Camları Otomatik Kapat", "kilit", 289408336, 0, "i", true, false, 0, 0, 1, false));
        m.put("ayna_indir",       new SettingSpec("ayna_indir", "Geri Viteste Yan Aynaları İndir", "kilit", 339741511, 0, "i", true, false, 0, 0, 1, false));
        m.put("kolay_giris",      new SettingSpec("kolay_giris", "Kolay Giriş / Karşılama Koltuğu", "kilit", 289408056, 0, "i", true, false, 0, 0, 1, false));

        // Şarj & Batarya Koruma
        m.put("priz_220",         new SettingSpec("priz_220", "220V V2L İç/Dış Priz Gücü", "sarj", 289407762, 0, "i", true, false, 0, 0, 1, true));
        m.put("kablosuz_sarj",    new SettingSpec("kablosuz_sarj", "Kablosuz Telefon Şarj Pedi", "sarj", 289407760, 0, "i", true, false, 0, 0, 1, false));
        m.put("batarya_isitma",   new SettingSpec("batarya_isitma", "Batarya Kış Ön Isıtma Sistemi", "sarj", 289408055, 0, "i", true, false, 0, 0, 1, false));
        m.put("uzun_omur",        new SettingSpec("uzun_omur", "Batarya Uzun Ömür Modu", "sarj", 289408057, 0, "i", true, false, 0, 0, 1, false));
        m.put("derin_desarj",     new SettingSpec("derin_desarj", "Derin Deşarj Koruması", "sarj", 289408566, 0, "i", true, false, 0, 0, 1, false));

        // Ses & Ekolayzer
        m.put("ses_modu",         new SettingSpec("ses_modu", "Ses Sahnesi Modu (0-3)", "ses", 289410644, 0, "i", false, false, 1, 0, 3, false));
        m.put("ekolayzer",        new SettingSpec("ekolayzer", "Ekolayzer Ön Ayarı (0-5)", "ses", 289410642, 0, "i", false, false, 1, 0, 5, false));
        m.put("hiza_duyarli_ses", new SettingSpec("hiza_duyarli_ses", "Hıza Duyarlı Ses Seviyesi (0-3)", "ses", 289410646, 0, "i", false, false, 0, 0, 3, false));

        SETTINGS_MAP = Collections.unmodifiableMap(m);
    }
}
