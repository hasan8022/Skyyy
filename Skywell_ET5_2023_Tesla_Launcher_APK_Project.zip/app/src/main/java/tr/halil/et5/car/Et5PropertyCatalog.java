package tr.halil.et5.car;

/**
 * Complete 2023 Skywell ET5 (Skyworth EV6) Hardware Property Catalog.
 * Extracted 1:1 from Mg0.java, C0227Hf.java, d4.smali, C1328f8.java, and qg0.smali.
 */
public final class Et5PropertyCatalog {

    private Et5PropertyCatalog() {}

    // Area IDs
    public static final int AREA_GLOBAL = 0;
    public static final int AREA_SEAT_DRIVER = 1;
    public static final int AREA_SEAT_PASSENGER = 4;
    public static final int AREA_WINDOW_FL = 16;
    public static final int AREA_WINDOW_FR = 64;
    public static final int AREA_HVAC_ALL = 117;

    // Powertrain, Speed, Gear, Battery, Charging (0x2140xxxx / 0x2160xxxx / 0x2170xxxx)
    public static final int PROP_DRIVER_SEAT_VENT = 0x21401001; // 557846529
    public static final int PROP_RADAR_REAR_DIST = 0x21401009; // 557846537
    public static final int PROP_RADAR_FRONT_DIST = 0x2140100A; // 557846538
    public static final int PROP_DOOR_LOCK = 0x2140100E; // 557846542
    public static final int PROP_TRUNK_COMMAND = 0x2140100F; // 557846543
    public static final int PROP_CHARGE_PORT = 0x21401012; // 557846546
    public static final int PROP_CHARGING_ACTIVE = 0x21401017; // 557846551
    public static final int PROP_CHARGE_GUN_STATE = 0x21401018; // 557846552
    public static final int PROP_DRIVE_MODE = 0x21401019; // 557846553 (0=Norm,1=Eco,2=Sport)
    public static final int PROP_SUNROOF_POS = 0x2140101A; // 557846554
    public static final int PROP_LOW_BEAM = 0x2140101F; // 557846559
    public static final int PROP_HIGH_BEAM = 0x21401020; // 557846560
    public static final int PROP_REAR_FOG = 0x21401022; // 557846562
    public static final int PROP_BRAKE_PEDAL = 0x21401028; // 557846568
    public static final int PROP_SPEED_KMH = 0x21401029; // 557846569
    public static final int PROP_RANGE_KM = 0x2140102A; // 557846570
    public static final int PROP_GEAR_SELECTION = 0x21401031; // 557846577 (1=R, 2=N, 3=D, 4=P)
    public static final int PROP_PARKING_BRAKE = 0x21401032; // 557846578
    public static final int PROP_TRUNK_OPEN_PERCENT = 0x21401053; // 557846611
    public static final int PROP_AUTO_HOLD = 0x21401054; // 557846612
    public static final int PROP_ESC_OFF = 0x2140105E; // 557846622
    public static final int PROP_CHARGE_REMAIN_MIN = 0x214010B5; // 557846709
    public static final int PROP_HEADLIGHT_HEIGHT = 0x214010B8; // 557846712
    public static final int PROP_SCHED_CHARGE_START = 0x214010BA; // 557846714
    public static final int PROP_SCHED_CHARGE_END = 0x214010BB; // 557846715
    public static final int PROP_SCHED_CHARGE_CMD = 0x214010BC; // 557846716
    public static final int PROP_SOC_PERCENT = 0x21401134; // 557846836
    public static final int PROP_SUNSHADE = 0x21401146; // 557846854
    public static final int PROP_SEAT_REST_MODE = 0x21401148; // 557846856
    public static final int PROP_PASSENGER_SEAT_VENT = 0x21401151; // 557846865
    public static final int PROP_HAZARD_LIGHTS = 0x21401152; // 557846866
    public static final int PROP_BATTERY_POWER_KW = 0x21401164; // 557846884 (raw*0.1 - 1000)
    public static final int PROP_CONSUMPTION_KWH = 0x21401166; // 557846886 (raw*0.1)
    public static final int PROP_DISCHARGE_LIMIT = 0x21401189; // 557846921
    public static final int PROP_AMBIENT_COLOR = 0x214011A0; // 557846944
    public static final int PROP_AMBIENT_BRIGHTNESS = 0x214011A1; // 557846945
    public static final int PROP_CAMP_MODE = 0x214011AF; // 557846959
    public static final int PROP_PARTY_MODE = 0x214011B0; // 557846960
    public static final int PROP_ACC_CONTROL = 0x21401201; // 557847041
    public static final int PROP_DRIVER_SEAT_MEM = 0x21401389; // 557847433
    public static final int PROP_HVAC_IONIZER = 0x2140138D; // 557847437

    // Standard Android Automotive HVAC & Exterior Properties
    public static final int PROP_HVAC_FAN_SPEED = 0x12400500; // 306185472
    public static final int PROP_HVAC_FAN_DIRECTION = 0x12400501; // 306185473
    public static final int PROP_HVAC_TEMP_CURRENT = 0x12600502; // 308282626
    public static final int PROP_HVAC_TEMP_SET = 0x12600503; // 308282627
    public static final int PROP_HVAC_DEFROSTER = 0x13200504; // 320865540
    public static final int PROP_HVAC_AC_ON = 0x12200505; // 354419973
    public static final int PROP_HVAC_MAX_AC_ON = 0x12200506; // 354419974
    public static final int PROP_HVAC_MAX_DEFROST_ON = 0x12200507; // 354419975
    public static final int PROP_HVAC_RECIRC_ON = 0x12200508; // 354419976
    public static final int PROP_HVAC_DUAL_ON = 0x12200509; // 354419977
    public static final int PROP_HVAC_AUTO_ON = 0x1220050A; // 354419978
    public static final int PROP_HVAC_SEAT_TEMPERATURE = 0x1540050B; // 356517131
    public static final int PROP_HVAC_POWER_ON = 0x12200510; // 354419984
    public static final int PROP_TURN_SIGNAL_STATE = 0x11400408; // 289408008
    public static final int PROP_ENV_OUTSIDE_TEMP = 0x11600703; // 291505923

    // Float & Array Vendor Properties (0x2160xxxx / 0x2141xxxx / 0x2170xxxx)
    public static final int PROP_SOC_FLOAT = 0x2160116B; // 559944043
    public static final int PROP_TOTAL_DISCHARGE_KWH = 0x216011B3; // 559944115
    public static final int PROP_ODOMETER_KM = 0x216011B4; // 559944116
    public static final int PROP_DOOR_STATES_ARRAY = 0x21410306; // 557908742
    public static final int PROP_WINDOW_POS_ARRAY = 0x21415025; // 557928485
    public static final int PROP_TIRE_PRESSURE_TEMP = 0x2141502F; // 557928495
    public static final int PROP_SEAT_POS_4D = 0x21415035; // 557928501
    public static final int PROP_MIRROR_POS_4D = 0x21415036; // 557928502
    public static final int PROP_CHARGE_LIMIT_ARRAY = 0x21415037; // 557928503
    public static final int PROP_EXT_LIGHTS_ARRAY = 0x21415038; // 557928504
    public static final int PROP_STEERING_WHEEL_KEY = 0x21700399; // 560989081

    // All 46 Watched Property IDs (Subscribed via WATCH on 127.0.0.1:8724, identical to Mg0.java)
    public static final int[] WATCHED_PROPERTY_IDS = new int[]{
            PROP_SPEED_KMH,
            PROP_GEAR_SELECTION,
            PROP_SOC_PERCENT,
            PROP_RANGE_KM,
            PROP_HVAC_TEMP_CURRENT,
            PROP_ENV_OUTSIDE_TEMP,
            PROP_HVAC_POWER_ON,
            PROP_HVAC_TEMP_SET,
            PROP_HVAC_FAN_SPEED,
            PROP_HVAC_AC_ON,
            PROP_HVAC_AUTO_ON,
            PROP_HVAC_RECIRC_ON,
            PROP_HVAC_DEFROSTER,
            PROP_HVAC_SEAT_TEMPERATURE,
            PROP_DRIVER_SEAT_VENT,
            PROP_PASSENGER_SEAT_VENT,
            PROP_DOOR_LOCK,
            PROP_TRUNK_OPEN_PERCENT,
            PROP_PARKING_BRAKE,
            PROP_DRIVE_MODE,
            PROP_CHARGING_ACTIVE,
            PROP_CHARGE_GUN_STATE,
            PROP_CHARGE_REMAIN_MIN,
            PROP_AUTO_HOLD,
            PROP_ESC_OFF,
            PROP_HAZARD_LIGHTS,
            PROP_LOW_BEAM,
            PROP_HIGH_BEAM,
            PROP_REAR_FOG,
            PROP_DOOR_STATES_ARRAY,
            PROP_EXT_LIGHTS_ARRAY,
            PROP_BRAKE_PEDAL,
            PROP_TURN_SIGNAL_STATE,
            PROP_RADAR_FRONT_DIST,
            PROP_RADAR_REAR_DIST,
            PROP_SEAT_POS_4D,
            PROP_MIRROR_POS_4D,
            PROP_STEERING_WHEEL_KEY,
            PROP_TIRE_PRESSURE_TEMP,
            PROP_ODOMETER_KM,
            PROP_TOTAL_DISCHARGE_KWH,
            PROP_CONSUMPTION_KWH,
            PROP_BATTERY_POWER_KW,
            PROP_SOC_FLOAT,
            PROP_WINDOW_POS_ARRAY,
            PROP_SUNROOF_POS
    };

    // ContentProvider URIs (from C0227Hf.java and d4.smali)
    public static final String URI_SKYHVAC_TEMP = "content://com.coolwell.ai.skyhvac.database/airconditioner/temperature";
    public static final String URI_AISETTINGS_BASE = "content://com.skyworth.car.aisettings.vehiclecontrol.database/";
}
