# Skywell ET5 (2023) — Gerçek Araç Köprüsü, Kurulum Sihirbazı ve 60 FPS Native Tesla Launcher (V3)

Bu proje, **2023 Skywell ET5 (Skyworth EV6 - Android 9 API 28 & Android 12 API 31/32, Google Play Servisleri / GMS Olmayan Coocaa OS)** multimedya ünitesi için sıfır sahte/demo veri, sıfır WebView arayüz kasması ve %100 gerçek CAN-Bus / ADB bağlantısıyla kodlanmış **Tesla Split-Screen Başlatıcı (Launcher)** projesidir.

---

## 1. Neler Düzeltildi ve Yenilendi?

1. **Zorunlu Kurulum Sihirbazı & Coocaa OS Geliştirici Şifre Üreticisi (`SetupWizardDialog` + `AdbRootBridge`)**:
   - Araçta Geliştirici Modu (`adb`) açılmadan hiçbir harici başlatıcı `CarPropertyManager` veya sistem yetkilerine erişemez.
   - Uygulama ilk açıldığında **Skywell ET5 Kurulum Sihirbazı** otomatik açılır:
     - **Ayarlar -> Sistem -> Coocaa OS** logosuna 20 kez dokunulduğunda çıkan `"Lütfen Parolanı Girin"` ekranının şifresini (`persist.tbox.vin.name` son 3 karakteri + `ro.build.skylinkversion` 3. parça Base64) **otomatik hesaplar** ve 28sp büyük fontla + harf harf okunuşuyla (`0 (sıfır)`, `O (büyük o harfi)`, `l (küçük L harfi)`) ekranda gösterir.
     - **Geliştirme Modu -> Aç adb** yapıldığında `127.0.0.1:5555` üzerinden **524-byte Android `RSAPublicKey` binary struct (`SkyOS@arac`)** göndererek araç ekranında `"Her zaman bu bilgisayardan izin ver"` penceresini tetikler.
     - Onay verildiğinde 5 adımlı kurulumu (`adb_keys` kalıcı kayıt, `pm grant` tüm izinler, `uid=1000` `AracYardimci` CAN-Bus sunucusu, `HomeGate` varsayılan ana ekran rolü ve `iptables` dış port 5555 koruması) otomatik tamamlar.

2. **Sıfır Demo Veri (`VehicleState` + `VehicleController` + `AracYardimci` `127.0.0.1:8724`)**:
   - Tüm sahte başlangıç değerleri (`%82`, `425 km`, `22.5°C`, `2.45 bar`, `18420 km`) tamamen kaldırıldı.
   - CAN-Bus (`127.0.0.1:8724` üzerinde `uid=1000` `system` yetkisiyle çalışan `AracYardimci`) verisi gelene kadar ekranda yalnızca `--%`, `-- km`, `--.-°C`, `-- bar` gösterilir; bağlantı kurulduğu anda aracın gerçek sensör değerleri (`0x21401029` Hız, `0x21401031` Vites, `0x21401134` Batarya, `0x2140102A` Menzil, `0x2141502F` TPMS Lastik Basınç/Sıcaklık, `0x21410306` Kapı/Bagaj/Kaput, `content://com.coolwell.ai.skyhvac.database/airconditioner/temperature` Klima) canlı akar.

3. **Sıfır Kasma — 60 FPS Native Android Donanım Hızlandırmalı Arayüz (`MainActivity` + `NativeDialogs`)**:
   - Kasan tam ekran HTML WebView kabuğu tamamen kaldırıldı; tüm Tesla Split-Screen düzeni, üst durum çubuğu, vites ve hız göstergesi, alt dock, klima paneli, araç/ADAS kontrol merkezi, telefon rehberi ve uygulama mağazası **%100 Native Android Donanım Hızlandırmalı View (`android:hardwareAccelerated="true"`)** olarak kodlandı.
   - Sol sahnede hafifletilmiş GPU modunda (`lite: true`, `et5-hafif.glb`) çalışan etkileşimli 3D Skywell ET5 modeli (`assets/car/`), sağ sahnede ise gerçek GPS (`LocationManager.GPS_PROVIDER`) + Nominatim + OSRM destekli `Leaflet` haritası (`assets/map-lite/`) yer alır.

4. **Gerçek Spotify, Gerçek YouTube (`SmartTube` / `NewPipe`), Gerçek YT Music (`Metrolist`) ve OEM Radyo**:
   - Sahte web iframe oynatıcıları kaldırıldı.
   - Sağ alttaki medya kartı ve **Uygulamalar & APK** merkezi; yüklü `Spotify`, `SmartTube`, `NewPipe`, `Metrolist`, `OEM FM Radyo`, `OEM USB Müzik` ve `Bluetooth Müzik` uygulamalarını doğrudan başlatır, `MediaSessionManager` üzerinden gerçek çalan şarkı/sanatçı bilgisini okur ve gösterge paneline (`CDSManager`) yazar. Yüklü olmayan GMS-Free araç uygulamalarını ise tek dokunuşla indirip ADB üzerinden (`pm install -r`) sessizce kurar.
