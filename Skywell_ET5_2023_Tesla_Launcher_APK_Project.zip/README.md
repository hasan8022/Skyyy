# 2023 Skywell ET5 (Skyworth EV6) — Tesla V12 Edition Android Launcher

Bu proje, **2023 Skywell ET5 (Skyworth EV6)** elektrikli aracın multimedya ekranı (Android 9/10/11 IVI) için sıfırdan geliştirilmiş, **sıfır lisans/sunucu kilidine sahip**, **Tesla V12 / Highland bölünmüş ekran (Split-Screen)** tasarımlı tam donanımlı Android Studio & GitHub Actions APK projesidir.

## Öne Çıkan Özellikler

1. **Çift Katmanlı Araç İletişim Motoru (`VehicleController` + `AracYardimci` + `AdbRootBridge`)**:
   - **Doğrudan `android.car.Car` (`CarPropertyManager`)** ve **`127.0.0.1:8724` `AracYardimci` (`UID 1000` sistem servisi)** üzerinden tüm araç verilerini okur ve yazar.
   - `content://com.coolwell.ai.skyhvac.database/airconditioner` ve `content://com.skyworth.car.aisettings.vehiclecontrol.database/recovery` `ContentProvider` veritabanlarıyla senkronize çalışır.
   - Herhangi bir dış sunucu doğrulaması (`skyos.tr`) veya şifreli `arac.bin` gerektirmez; tamamen çevrimdışı ve bağımsız çalışır.
2. **Gerçek Zamanlı 3B Skywell ET5 Görselleştirme (`Three.js` + `et5-hafif.glb`)**:
   - Ekranın sol bölmesinde interaktif 3B Skywell ET5 modeli, P/R/N/D vites seçici, hız, anlık güç/rejenerasyon çubuğu, batarya `%` ve menzil, 4 kapı, kaput, elektrikli bagaj, 4 cam, sunroof, sinyaller, fren lambaları ve 12 sensörlü ultrasonik park radarı yaylarını canlı gösterir.
3. **10 Sekmeli Tesla Araç Kontrol Merkezi (37+ Skywell ET5 Ayarı)**:
   - **Hızlı Kontroller**: Bagaj, Kilit, Yan Aynalar, 4 Cam (Aç / Kapat / Havalandır), Sunroof, 360° Kamera, Şarj Başlat/Durdur.
   - **Sürüş & Pedallar**: Sürüş Modu (`Normal`/`Eco`/`Spor`), Direksiyon Modu (`Konfor`/`Standart`/`Spor`), Fren Modu (`Konfor`/`Spor`), Enerji Geri Kazanımı (`%0-%100`), Rölanti (`Creep`), Yokuş İniş Desteği (`HDC`), `ESC`.
   - **Şarj & Enerji**: Şarj Üst Sınırı (`%50-%100`), 6 Adımlı Akıllı Şarj Durdurma (`Mg0.M`), Randevulu Şarj, `220V V2L Priz`, Kablosuz Şarj, Batarya Ön Isıtma, Uzun Ömür ve Derin Deşarj Koruması.
   - **Otopilot & ADAS**: `LKA`, `LDW`, `AEB`, `FCW`, `BSD`, `TSR`, `HBA`, Ön Park Radarı, `AVAS` Yaya Uyarısı.
   - **Koltuk & Hafıza**: Sürücü/Yolcu 3 kademeli Koltuk Isıtma ve Soğutma, 8'li Hafıza Paketi (`0x11410ba0`) ile Sürücü 1, Sürücü 2 ve **Kamp/Uyku Modu** koltuk pozisyonları, Kolay Giriş.
   - **Aydınlatma & Ambiyans**: Far Yüksekliği (`0-3`), `Follow Me Home`, Karşılama Işığı, Skywell Bagaj Logo Işığı, Ambiyans Modu ve 128 Renk Seçimi.
   - **Kadran (`CDSManager`) & Ses**: Kadran Parlaklığı, Teması (`Klasik`/`Spor`), Uyarı Tonu, Kadranda Şarkı/Sanatçı Gösterimi (`MUSIC`), Ana Ses (`0-40`), Ses Sahnesi ve Ekolayzer.
4. **360° AVM / Geri Görüş Kamerası (`Et5ReverseCameraHelper`)**:
   - Vites **R** konumuna geçtiğinde veya kamera tuşuna basıldığında `com.skyworth.car.evs.EvsStrategyService` servisini durdurur ve `Camera2` ID `"0"` üzerinden `1280x960` **UYVY yarı-yükseklik düzeltmeli (`FE0.b`)** canlı kamera görüntüsünü ultrasonik radar mesafeleriyle birlikte açar.
5. **OBD2 / CAN-Bus (`ObdElm327Manager`)**:
   - Bluetooth `ELM327` / `vLinker MS` adaptörüyle 6 ECU (`VCU 7E0`, `BMS 711`, `Gösterge 722`, `Motor 710`, `ABS 723`, `OBC/DCDC 713`) üzerinden paket gerilimi, akımı, `SoH %`, hücre gerilim farkı (`mV`), batarya/motor/invertör/OBC sıcaklıkları, izolasyon direnci (`kΩ`) ve **DTC Arıza Kodu (`1902FF`)** taraması yapar.

## GitHub Actions ile Otomatik APK Derleme

1. Bu proje klasörünü yeni bir GitHub deposuna (repository) yükleyin (`git push`).
2. GitHub deponuzdaki **Actions** sekmesine tıklayın.
3. **`Build Skywell ET5 (2023) Tesla Launcher APK`** iş akışı otomatik olarak çalışacak ve hem `app-debug.apk` hem de imzalı `app-release.apk` dosyasını **Artifacts (`Skywell-ET5-2023-Tesla-Launcher-APK`)** bölümünde indirmeye hazır hale getirecektir.
